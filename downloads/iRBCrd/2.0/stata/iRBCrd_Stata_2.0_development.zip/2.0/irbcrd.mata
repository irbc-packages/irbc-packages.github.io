version 16.0
mata:

// iRBCrd 2.0: native Stata port of the R 2.0 numerical specification.
// Development build: compilation and execution in Stata remain unverified.

struct irbc_options {
    real scalar cutoff, p, alpha, bwcheck, pooled, fast, gloo, fuzzy
    real scalar bootstrap, reps, keep
    real rowvector h
    string rowvector kernel
    string scalar residuals, qmethod, wild, fuzzyweights
}

struct irbc_localfit {
    real scalar h, nh
    real colvector weight, leverage
    real matrix coefficient_weights
}

struct irbc_side {
    real scalar h, hfit, Q, nh
    real colvector a, omega, omega_us
    real rowvector point, bias
    real matrix residuals, fitted, cov_irbc, cov_us
    real scalar fast_variance
}

struct irbc_result {
    real scalar n, estimate, uncorrected, bias, se, se_us, first_stage
    real scalar mhat, boot_success
    real rowvector h, hfit, Q, nh, ci, ci_boot, probs, weights
    real rowvector components, component_bias
    real matrix gamma, cov_irbc, cov_us, residuals, fitted
    real colvector boot_t, boot_first_stage
    real matrix boot_components
    string scalar design
}

real scalar irbc_st_version()
{
    return(200)
}

void irbc_fail(string scalar message)
{
    errprintf("irbcrd: %s\n", message)
    _error(498)
}

real matrix irbc_inverse(real matrix A)
{
    real matrix out
    out = cholinv((A+A')/2)
    if (hasmissing(out)) irbc_fail("A local regression is singular or numerically ill-conditioned.")
    return(out)
}

real scalar irbc_h(real colvector x, real scalar x0,
                   real scalar h, real scalar bwcheck)
{
    real colvector distance
    real scalar j
    if (bwcheck == 0) return(h)
    distance = sort(abs(x:-x0), 1)
    j = min((rows(x), bwcheck))
    if (j == 0) irbc_fail("Observations are required on both sides of the cutoff.")
    return(max((h, distance[j])))
}

real colvector irbc_kernel(real colvector u, string scalar kernel)
{
    real colvector w, at
    w = J(rows(u), 1, 0)
    at = selectindex(abs(u):<=1)
    if (kernel == "tri") w[at] = 1:-abs(u[at])
    else if (kernel == "epa") w[at] = 0.75:*(1:-u[at]:^2)
    else if (kernel == "uni") w[at] = J(rows(at), 1, 0.5)
    else irbc_fail("Unknown kernel.")
    return(w)
}

real matrix irbc_basis(real colvector u, real scalar p)
{
    real matrix R
    real scalar j
    R = J(rows(u), p+1, 1)
    for (j=1; j<=p; j++) R[.,j+1] = u:^j
    return(R)
}

struct irbc_localfit scalar irbc_local(real colvector x, real scalar x0,
    real scalar h, real scalar p, string scalar kernel, real scalar bwcheck)
{
    struct irbc_localfit scalar f
    real matrix R, G
    real colvector w
    f.h = irbc_h(x, x0, h, bwcheck)
    if (f.h <= 0 | f.h >= .) irbc_fail("A local bandwidth is not positive and finite.")
    R = irbc_basis((x:-x0)/f.h, p)
    w = irbc_kernel((x:-x0)/f.h, kernel)/f.h
    f.nh = sum(w:>0)
    if (f.nh < p+1) irbc_fail("Too few positive-kernel observations for a local regression.")
    G = irbc_inverse(cross(R, w, R))
    f.coefficient_weights = (w:*R)*G
    f.weight = f.coefficient_weights[.,1]
    f.leverage = rowsum((R*G):*(w:*R))
    if (hasmissing(f.weight)) irbc_fail("Nonfinite local-polynomial weights.")
    return(f)
}

real scalar irbc_Q(string scalar kernel)
{
    if (kernel == "tri") return(1.4082)
    if (kernel == "epa") return(1.3571)
    return(1.2)
}

real matrix irbc_hc(real matrix raw, real colvector leverage,
                    real colvector nh, real scalar df, real scalar hc)
{
    real colvector adjust
    if (hc == 0) return(raw)
    if (hc == 1) adjust = (nh:-df):/nh
    else adjust = 1:-leverage
    if (hasmissing(adjust) | min(adjust)<=0) {
        irbc_fail("HC adjustment is undefined: insufficient support or leverage at least one.")
    }
    if (hc == 1 | hc == 2) adjust = sqrt(adjust)
    return(raw:/adjust)
}

struct irbc_side scalar irbc_build_side(real colvector x, real matrix Y,
    real scalar h, string scalar kernel, struct irbc_options scalar o)
{
    struct irbc_side scalar s
    struct irbc_localfit scalar f0, fi, fq
    real scalar n, k, j, hc, denominator, factor
    real colvector bias_active, residual_active, needed, at, keep
    real colvector C, lev, nh, rbc_weight
    real matrix bias_fitted, loo_fitted, weighted

    n = rows(x)
    k = cols(Y)
    s.h = h
    f0 = irbc_local(x, o.cutoff, h, o.p, kernel, o.bwcheck)
    s.hfit = f0.h
    s.a = f0.weight
    s.nh = f0.nh
    s.point = s.a'*Y
    s.fitted = J(n,k,0)
    C = J(n,1,0)
    lev = nh = J(n,1,.)
    bias_active = abs(x:-o.cutoff):<2*h
    residual_active = abs(x:-o.cutoff):<=2*s.hfit
    needed = bias_active :| (abs(x:-o.cutoff):<=s.hfit)
    if (substr(o.residuals,1,5) == "irbc-") needed = needed :| residual_active
    at = selectindex(needed)
    loo_fitted = J(n,k,0)

    for (j=1; j<=rows(at); j++) {
        fi = irbc_local(x, x[at[j]], h, o.p, kernel, o.bwcheck)
        s.fitted[at[j],.] = fi.weight'*Y
        lev[at[j]] = fi.weight[at[j]]
        nh[at[j]] = fi.nh
        if (bias_active[at[j]]) {
            if (o.qmethod == "sample") {
                C[at[j]] = fi.weight'*(((x:-x[at[j]])/h):^(o.p+1))
            }
            if (o.gloo) {
                keep = selectindex((1::n):!=at[j])
                fi = irbc_local(x[keep], x[at[j]], h, o.p, kernel, o.bwcheck)
                loo_fitted[at[j],.] = fi.weight'*Y[keep,.]
            }
        }
    }

    if (o.qmethod == "sample") {
        denominator = s.a'*C
        if (denominator == 0 | denominator >= .) irbc_fail("The sample Q denominator is zero or nonfinite.")
        s.Q = (s.a'*(((x:-o.cutoff)/h):^(o.p+1)))/denominator
    }
    else s.Q = irbc_Q(kernel)
    if (missing(s.Q)) irbc_fail("The Q adjustment is not finite.")

    bias_fitted = s.fitted:*bias_active
    if (o.gloo) bias_fitted = loo_fitted
    s.bias = s.Q*(s.a'*(bias_fitted:-s.point))

    if (o.residuals == "loo") s.residuals = Y-bias_fitted
    else {
        hc = strtoreal(substr(o.residuals,strlen(o.residuals),1))
        if (substr(o.residuals,1,4) == "cct-") {
            // CCT residuals use the reported cutoff h, without another enlargement.
            fq = irbc_local(x, o.cutoff, h, o.p+1, kernel, 0)
            weighted = irbc_basis((x:-o.cutoff)/h,o.p+1)*(fq.coefficient_weights'*Y)
            s.residuals = irbc_hc(Y-weighted, fq.leverage,
                                  J(n,1,fq.nh),o.p+2,hc)
        }
        else {
            s.residuals = J(n,k,0)
            at = selectindex(residual_active)
            s.residuals[at,.] = irbc_hc(Y[at,.]-s.fitted[at,.],
                                       lev[at],nh[at],o.p+1,hc)
        }
    }
    if (hasmissing(s.residuals)) irbc_fail("Nonfinite residuals.")

    // Preserve R 2.0's auxiliary-bandwidth scaling in the variance weights.
    s.omega = (1+s.Q)*s.a
    at = selectindex(abs(x:-o.cutoff):<=s.hfit)
    for (j=1; j<=rows(at); j++) {
        fi = irbc_local(x, x[at[j]], s.hfit, o.p, kernel, o.bwcheck)
        s.omega = s.omega-s.Q*s.a[at[j]]*(fi.h/s.hfit)*fi.weight
    }
    s.omega = s.omega:*(abs(x:-o.cutoff):<=2*s.hfit)
    s.omega_us = s.Q*s.a
    weighted = s.residuals:*s.omega
    s.cov_irbc = cross(weighted,weighted)
    weighted = s.residuals:*s.omega_us
    s.cov_us = cross(weighted,weighted)
    s.fast_variance = .
    if (o.fast & k == 1) {
        fq = irbc_local(x,o.cutoff,s.hfit,o.p+1,kernel,0)
        rbc_weight = s.a-(s.a'*(((x:-o.cutoff)/s.hfit):^(o.p+1)))*
                     fq.coefficient_weights[.,o.p+2]
        factor = 0.86
        if (kernel == "tri") factor = 0.84
        if (kernel == "epa") factor = 0.83
        s.fast_variance = factor^2*sum((rbc_weight:*s.residuals):^2)
    }
    return(s)
}

real matrix irbc_gamma_terms(real colvector x, real matrix Y, real matrix Z,
    real scalar h, string scalar kernel, struct irbc_options scalar o)
{
    real colvector w, at
    real matrix R, G, UZ, UY, zz, zy
    w = irbc_kernel((x:-o.cutoff)/h,kernel)/h
    at = selectindex(w:>0)
    if (rows(at)<=o.p+1) irbc_fail("Insufficient support for common-slope covariate adjustment.")
    R = irbc_basis((x[at]:-o.cutoff)/h,o.p)
    G = irbc_inverse(cross(R,w[at],R))
    UZ = cross(R,w[at],Z[at,.])
    UY = cross(R,w[at],Y[at,.])
    zz = cross(Z[at,.],w[at],Z[at,.])-UZ'*G*UZ
    zy = cross(Z[at,.],w[at],Y[at,.])-UZ'*G*UY
    return((zz,zy))
}

real scalar irbc_se(real matrix V, real rowvector w)
{
    real scalar v
    v = w*V*w'
    if (v<0 & v > -1e-12) v = 0
    if (v<0 | v>=.) irbc_fail("A variance could not be computed.")
    return(sqrt(v))
}

real scalar irbc_quantile(real colvector values, real scalar probability)
{
    real colvector v
    real scalar index, lo, hi
    v = sort(select(values,values:<.),1)
    if (rows(v)<2) return(.)
    index = 1+(rows(v)-1)*probability
    lo = max((1,floor(index)))
    hi = min((rows(v),lo+1))
    return(v[lo]+(index-lo)*(v[hi]-v[lo]))
}

real colvector irbc_wild(real scalar n, string scalar wild)
{
    real scalar a, b, pa
    if (wild == "normal") return(rnormal(n,1,0,1))
    if (wild == "rademacher") return(2*(runiform(n,1):>=0.5):-1)
    a = (1-sqrt(5))/2
    b = (1+sqrt(5))/2
    pa = (sqrt(5)+1)/(2*sqrt(5))
    return(a:+(b-a)*(runiform(n,1):>=pa))
}

struct irbc_result scalar irbc_compute(real colvector x, real matrix Y,
    struct irbc_options scalar o, real matrix drawmatrix)
{
    struct irbc_result scalar r
    struct irbc_side scalar L, R
    real colvector il, ir, local, at, multipliers
    real matrix Z, U, A, gamma_terms, delta, centered
    real rowvector t, w, td, wy, wd
    real scalar n, k, nz, nf, hl, hr, bb, yl, dl, dboot, critical

    n = rows(x)
    k = cols(Y)
    nf = 1+o.fuzzy
    nz = k-nf
    if (n<1 | rows(Y)!=n | k<nf | hasmissing(x) | hasmissing(Y)) {
        irbc_fail("Data must be conformable, finite, and nonempty.")
    }
    if (o.gloo & (sum(x:==0)>0 | sum(Y:==0)>0)) {
        irbc_fail("gloo with zero-valued data is unsupported because R 2.0 drops zeros inconsistently; omit gloo.")
    }
    il = selectindex(x:<o.cutoff)
    ir = selectindex(x:>=o.cutoff)
    if (!rows(il) | !rows(ir)) irbc_fail("Observations are required on both sides of the cutoff.")
    if (o.pooled) hl = hr = irbc_h(x,o.cutoff,o.h[1],o.bwcheck)
    else {
        hl = irbc_h(x[il],o.cutoff,o.h[1],o.bwcheck)
        hr = irbc_h(x[ir],o.cutoff,o.h[2],o.bwcheck)
    }
    L = irbc_build_side(x[il],Y[il,.],hl,o.kernel[1],o)
    R = irbc_build_side(x[ir],Y[ir,.],hr,o.kernel[2],o)
    r.n = n
    r.h = (hl,hr)
    r.hfit = (L.hfit,R.hfit)
    r.Q = (L.Q,R.Q)
    r.nh = (L.nh,R.nh)
    r.components = R.point-L.point
    r.component_bias = R.bias-L.bias
    r.gamma = J(0,nf,.)
    wy = (1,J(1,k-1,0))
    wd = J(1,k,0)
    if (o.fuzzy) wd[2] = 1
    if (nz>0) {
        Z = Y[.,(nf+1)..k]
        U = Y[.,1..nf]
        gamma_terms = irbc_gamma_terms(x[il],U[il,.],Z[il,.],hl,o.kernel[1],o)+
                      irbc_gamma_terms(x[ir],U[ir,.],Z[ir,.],hr,o.kernel[2],o)
        A = gamma_terms[.,1..nz]
        r.gamma = irbc_inverse(A)*gamma_terms[.,(nz+1)..(nz+nf)]
        wy[(nf+1)..k] = -r.gamma[.,1]'
        if (o.fuzzy) wd[(nf+1)..k] = -r.gamma[.,2]'
    }
    yl = wy*r.components'
    r.first_stage = .
    if (o.fuzzy) {
        dl = wd*r.components'
        if (abs(dl)<=1.4901161193847656e-8 | dl>=.) {
            irbc_fail("The adjusted first-stage discontinuity is too close to zero.")
        }
        r.first_stage = dl
        r.uncorrected = yl/dl
        w = wy/dl-yl*wd/(dl^2)
        r.design = "fuzzy"
        if (nz>0) r.design = "covariate-adjusted fuzzy"
    }
    else {
        r.uncorrected = yl
        w = wy
        r.design = "sharp"
        if (nz>0) r.design = "covariate-adjusted sharp"
    }
    r.weights = w
    r.bias = w*r.component_bias'
    r.estimate = r.uncorrected-r.bias
    r.cov_irbc = L.cov_irbc+R.cov_irbc
    r.cov_us = L.cov_us+R.cov_us
    r.se = irbc_se(r.cov_irbc,w)
    // Sharp R 2.0 divides by reported h after viRBC rechecks the side h.
    if (!o.fast & k==1) r.se = sqrt(L.cov_irbc[1,1]*L.hfit/hl+R.cov_irbc[1,1]*R.hfit/hr)
    if (o.fast & k==1) r.se = sqrt(L.fast_variance+R.fast_variance)
    r.se_us = irbc_se(r.cov_us,w)
    critical = invnormal(1-o.alpha/2)
    r.ci = r.estimate:+(-critical,critical)*r.se
    r.residuals = r.fitted = J(n,k,0)
    r.residuals[il,.] = L.residuals
    r.residuals[ir,.] = R.residuals
    r.fitted[il,.] = L.fitted
    r.fitted[ir,.] = R.fitted
    r.boot_t = r.boot_first_stage = J(0,1,.)
    r.boot_components = J(0,k,.)
    r.ci_boot = r.probs = J(1,2,.)
    r.mhat = .
    r.boot_success = 0
    if (!o.bootstrap) return(r)

    if (r.se_us<=0 | r.se_us>=. | r.se<=0 | r.se>=.) {
        irbc_fail("Bootstrap calibration requires positive finite standard errors.")
    }
    r.mhat = r.se/r.se_us
    r.probs = normal(r.mhat*(-critical,critical))
    // The R sharp routine rechecks side bandwidths; joint routines use reported h.
    local = J(n,1,0)
    if (k==1) {
        local[il] = abs(x[il]:-o.cutoff):<=L.hfit
        local[ir] = abs(x[ir]:-o.cutoff):<=R.hfit
    }
    else {
        local[il] = abs(x[il]:-o.cutoff):<=hl
        local[ir] = abs(x[ir]:-o.cutoff):<=hr
    }
    if (!sum(local[il]) | !sum(local[ir])) irbc_fail("No bootstrap observations on one side.")
    at = selectindex(local)
    if (rows(drawmatrix)>0) {
        if (rows(drawmatrix)!=n | cols(drawmatrix)!=o.reps | hasmissing(drawmatrix)) {
            irbc_fail("drawmatrix must have one row per selected observation and reps columns, all finite.")
        }
    }
    r.boot_t = r.boot_first_stage = J(o.reps,1,.)
    r.boot_components = J(o.reps,k,.)
    centered = r.fitted-Y
    for (bb=1; bb<=o.reps; bb++) {
        if (rows(drawmatrix)>0) multipliers = drawmatrix[at,bb]
        else multipliers = irbc_wild(rows(at),o.wild)
        delta = J(n,k,0)
        delta[at,.] = centered[at,.]+r.residuals[at,.]:*multipliers
        td = R.a'*delta[ir,.]-L.a'*delta[il,.]
        t = R.Q*(R.a'*delta[ir,.])-L.Q*(L.a'*delta[il,.])
        r.boot_components[bb,.] = t
        if (o.fuzzy) r.boot_first_stage[bb] = wd*(r.components+td)'
        if (o.fuzzyweights == "bootstrap") {
            dboot = r.components[2]+td[2]
            if (abs(dboot)<=1.4901161193847656e-8 | dboot>=.) continue
            r.boot_t[bb] = t[1]/dboot-t[2]*r.components[1]/(r.components[2]*dboot)
        }
        else r.boot_t[bb] = t*w'
    }
    r.boot_success = sum(r.boot_t:<.)
    if (r.boot_success>=2) {
        r.ci_boot = (r.uncorrected-irbc_quantile(r.boot_t,r.probs[2]),
                     r.uncorrected-irbc_quantile(r.boot_t,r.probs[1]))
    }
    if (!o.keep) {
        r.boot_t = r.boot_first_stage = J(0,1,.)
        r.boot_components = J(0,k,.)
    }
    return(r)
}

struct irbc_result scalar irbc_last

void irbc_stata(string scalar yname, string scalar xname,
    string scalar dname, string scalar znames, string scalar touse,
    string scalar bname, string scalar vname)
{
    external struct irbc_result scalar irbc_last
    struct irbc_options scalar o
    real colvector x
    real matrix Y, D
    string rowvector names
    o.cutoff = strtoreal(st_local("c"))
    o.p = strtoreal(st_local("p"))
    o.alpha = 1-strtoreal(st_local("level"))/100
    o.bwcheck = strtoreal(st_local("bwcheck"))
    o.pooled = strtoreal(st_local("pooled"))
    o.fast = st_local("fast")!=""
    o.gloo = st_local("gloo")!=""
    o.fuzzy = dname!=""
    o.bootstrap = st_local("bootstrap")!=""
    o.reps = strtoreal(st_local("reps"))
    o.keep = st_local("nokeep")==""
    o.h = (strtoreal(st_local("hl")),strtoreal(st_local("hr")))
    o.kernel = (st_local("kl"),st_local("kr"))
    o.residuals = st_local("residuals")
    o.qmethod = st_local("qmethod")
    o.wild = st_local("wild")
    o.fuzzyweights = st_local("fuzzyweights")
    names = tokens(yname+" "+dname+" "+znames)
    x = st_data(.,xname,touse)
    Y = st_data(.,names,touse)
    D = J(0,0,.)
    if (st_local("drawmatrix")!="") D = st_matrix(st_local("drawmatrix"))
    irbc_last = irbc_compute(x,Y,o,D)
    st_matrix(bname,irbc_last.estimate)
    st_matrix(vname,irbc_last.se^2)
}

void irbc_post()
{
    external struct irbc_result scalar irbc_last
    real matrix table
    string colvector rn
    st_numscalar("e(estimate_irbc)",irbc_last.estimate)
    st_numscalar("e(tau_uncorrected)",irbc_last.uncorrected)
    st_numscalar("e(bias_irbc)",irbc_last.bias)
    st_numscalar("e(se_irbc)",irbc_last.se)
    st_numscalar("e(se_us)",irbc_last.se_us)
    st_numscalar("e(first_stage)",irbc_last.first_stage)
    st_matrix("e(ci_irbc)",irbc_last.ci)
    st_matrix("e(h)",irbc_last.h)
    st_matrix("e(h_fit)",irbc_last.hfit)
    st_matrix("e(Q)",irbc_last.Q)
    st_matrix("e(N_h)",irbc_last.nh)
    st_matrix("e(components)",irbc_last.components)
    st_matrix("e(component_bias)",irbc_last.component_bias)
    st_matrix("e(component_estimates)",irbc_last.components-irbc_last.component_bias)
    st_matrix("e(linear_weights)",irbc_last.weights)
    st_matrix("e(cov_irbc)",irbc_last.cov_irbc)
    st_matrix("e(cov_us)",irbc_last.cov_us)
    if (rows(irbc_last.gamma)) st_matrix("e(gamma)",irbc_last.gamma)
    st_global("e(design)",irbc_last.design)
    table = (irbc_last.estimate,irbc_last.se,irbc_last.ci)
    rn = "iRBC"
    if (st_local("bootstrap")!="") {
        st_numscalar("e(estimate_irbc_boot)",irbc_last.estimate)
        st_numscalar("e(boot_success)",irbc_last.boot_success)
        st_numscalar("e(boot_mhat)",irbc_last.mhat)
        st_matrix("e(ci_irbc_boot)",irbc_last.ci_boot)
        st_matrix("e(boot_probs)",irbc_last.probs)
        table = table \ (irbc_last.estimate,.,irbc_last.ci_boot)
        rn = rn \ "iRBC_boot"
    }
    st_matrix("e(table_irbc)",table)
    st_matrixrowstripe("e(table_irbc)",(J(rows(rn),1,""),rn))
    st_matrixcolstripe("e(table_irbc)",(J(4,1,""),("Estimate"\"Analytic_SE"\"CI_lower"\"CI_upper")))
}

end
