{smcl}
{* *! 2.0 development 22oct2026}{...}
{title:irbcrd -- Improved robust bias correction for RD designs}

{p 4 4 2}
{bf:Development build. Native Stata/Mata compilation and execution have NOT
been validated.} Target: Stata 16 or later. No R dependency for estimation.
Do not use for reported research results until the included Stata tests pass.

{title:Syntax}
{p 8 12 2}
{cmd:irbcrd} {it:y x} {ifin}, {opt h(# [#])}
[{opt fuzzy(d)} {opt covs(varlist)} {opt c(#)} {opt p(#)}
{opt kernel(name [name])} {opt residuals(name)} {opt qmethod(name)}
{opt level(#)} {opt bwcheck(#)} {opt noregularize} {opt fast} {opt gloo}
{opt bootstrap} {opt reps(#)} {opt seed(#)} {opt wild(name)}
{opt fuzzyweights(name)} {opt gammaweights(fixed)}
{opt hleft(#)} {opt hright(#)} {opt kleft(name)} {opt kright(name)}
{opt nokeep} {opt nodisplay} {opt drawmatrix(matname)}]

{title:Description}
{p 4 4 2}
One command covers sharp RD, fuzzy RD, covariate-adjusted sharp RD, and
covariate-adjusted fuzzy RD. In fuzzy designs with covariates, both the outcome
and treatment equations are adjusted. Bandwidths must be supplied externally.

{title:Main options}
{p 4 8 2}{opt h(# [#])} specifies one bandwidth or a left/right pair.
{p 4 8 2}{opt fuzzy(d)} supplies treatment; omit for sharp RD.
{p 4 8 2}{opt covs(varlist)} supplies numeric covariates; omit for no adjustment.
{p 4 8 2}{opt c(#)} defaults to 0. Observations at the cutoff are on the right.
{p 4 8 2}{opt p(#)} defaults to 1. Asymptotic Q requires p(1).
{p 4 8 2}{opt kernel(name [name])} accepts tri, epa, or uni, or their full names.
One name applies to both sides; two names are ordered left, right.
{p 4 8 2}{opt residuals(name)} accepts irbc-hc0 through irbc-hc3 (pointwise
order-p fits), cct-hc0 through cct-hc3 (order-p+1 cutoff fits), or loo.
Default: irbc-hc3. Residuals are shared by variance and bootstrap calculations.
{p 4 8 2}{opt qmethod(sample)} is the default finite-sample adjustment.
{opt qmethod(asymptotic)} replaces Qn by kernel constants without fast SEs.
{p 4 8 2}{opt fast} uses asymptotic Q and the R fast-SE convention. It cannot
be combined with qmethod(sample). Joint designs retain full covariance matrices.
{p 4 8 2}{opt bwcheck(#)} defaults to 21 observations (not unique x values).
{opt noregularize} or bwcheck(0) disables enlargement. A scalar h uses pooled
cutoff regularization; a pair or side override uses separate regularization.
{p 4 8 2}{opt gloo} uses leave-one-out auxiliary bias fits. For compatibility
with R 2.0, this port rejects zero-valued x or components when gloo is requested.
The default does not have this restriction; see README.txt.

{title:Bootstrap options}
{p 4 8 2}{opt bootstrap} adds the plug-in interval; {opt reps(#)} defaults to 999.
{p 4 8 2}{opt wild(name)} accepts rademacher (default), mammen, or normal.
{p 4 8 2}{opt seed(#)} sets Stata's RNG. Identical R/Stata seeds do not generate
identical draws. One multiplier per observation is shared across all components.
{p 4 8 2}{opt fuzzyweights(fixed)} is the default. bootstrap is allowed only
for fuzzy RD without covariates. Covariate-adjusted fuzzy RD uses fixed fuzzy
weights and fixed covariate coefficients; gammaweights(fixed) is optional.
{p 4 8 2}{opt nokeep} discards saved draws, but not the reported interval.
{p 4 8 2}{opt drawmatrix(matname)} supplies N-by-reps multipliers for testing;
rows follow the complete selected sample's order. It cannot be combined with seed().

{p 4 4 2}
The bootstrap estimate equals the analytic bias-corrected estimate. Bootstrap
intervals invert type-7 empirical quantiles around the uncorrected jump or
ratio, after prepivoting. They need not be centered on the displayed estimate.
The running variable, bandwidths, and Q are fixed during bootstrap resampling.
Observations outside the working window are unchanged.

{title:Examples}
{phang2}{cmd:. irbcrd y x, h(.6)}
{phang2}{cmd:. irbcrd y x, h(.6) fuzzy(d)}
{phang2}{cmd:. irbcrd y x, h(.6) covs(z1 z2)}
{phang2}{cmd:. irbcrd y x, h(.5 .7) fuzzy(d) covs(z1 z2) bootstrap reps(999) seed(17041998)}
{phang2}{cmd:. irbcrd y x, h(.6) residuals(cct-hc3) qmethod(asymptotic) bootstrap wild(mammen)}
{p 4 4 2}These are illustrative bandwidths, not estimated optima.

{title:Stored results}
{p 4 4 2}
e(b) and e(V) contain the analytic corrected estimate and variance.
e(ci_irbc) is the analytic interval; e(ci_irbc_boot) is present with bootstrap.
e(estimate_irbc_boot) equals e(estimate_irbc). See also e(table_irbc),
e(tau_uncorrected), e(bias_irbc), e(se_irbc), e(se_us), e(first_stage),
e(h_requested), e(h), e(h_fit), e(Q), e(N_h), e(components),
e(component_bias), e(component_estimates), e(linear_weights), e(gamma),
e(cov_irbc), e(cov_us), e(boot_probs), e(boot_mhat), e(boot_success), and e(boot_B).
Side pairs are ordered left, right. e(h_fit) records cutoff fits after the
side-specific bandwidth recheck; it can differ from e(h) under regularization.

{p 4 4 2}
Mata structure {cmd:irbc_last} retains diagnostics from the last successful call:
{cmd:irbc_last.boot_t}, {cmd:irbc_last.boot_components},
{cmd:irbc_last.boot_first_stage}, and {cmd:irbc_last.residuals}.
Draws are absent with nokeep. These objects are not saved by estimates store.

{p 4 4 2}
Missing analysis variables are excluded from the if/in sample.
e(N_selected), e(N_omitted), and e(N) report the counts. e(sample) marks all
complete selected observations, not just those inside h. Do not pretrim to h.

{title:Validation and limitations}
{p 4 4 2}
Run {cmd:do tests/run_tests.do} from the extracted development folder in a
fresh Stata session. This replaces the current data. Fixtures compare native
results with unchanged R 2.0 output using identical multiplier matrices.
The R formula audit is not a substitute for this native test.

{p 4 4 2}
No clustering, regression kink effects, internal bandwidth selection,
weak-first-stage-robust inference, direct/debiased bootstrap, or factor-variable
expansion. Singular local fits fail explicitly. Full details: README.txt.

{title:Authors}
{p 4 4 2}
Giuseppe Cavaliere, Silvia Goncalves, Morten Orregaard Nielsen, and Edoardo Zanelli.

{title:References}
{p 4 4 2}
Cavaliere, Goncalves, Nielsen, and Zanelli, Improved Inference for Regression
Discontinuity Designs (current manuscript).
{p 4 4 2}
Calonico, Cattaneo, Farrell, and Titiunik (2019), Regression Discontinuity Designs
Using Covariates, Review of Economics and Statistics 101(3), 442-451.
