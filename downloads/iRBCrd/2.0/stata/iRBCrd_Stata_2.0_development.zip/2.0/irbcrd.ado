*! irbcrd 2.0 development build, 22oct2026; native Stata validation pending
program define irbcrd, eclass
    version 16.0
    if replay() {
        if "`e(cmd)'" != "irbcrd" error 301
        syntax [, Level(real 0)]
        if `level' != 0 & `level' != e(level) {
            di as error "Refit with level() to change the confidence level, including bootstrap quantiles."
            exit 198
        }
        _irbcrd_display
        exit
    }
    local cmdline `"irbcrd `0'"'
    syntax varlist(min=2 max=2 numeric) [if] [in], H(numlist min=1 max=2 >0) ///
        [FUZZY(varname numeric) COVS(varlist numeric) C(real 0) P(integer 1) ///
         KERnel(string) RESiduals(string) QMethod(string) Level(cilevel) ///
         BWCHECK(integer 21) NOREGularize FAST GLOO BOOTstrap REPS(integer 999) ///
         SEED(string) WILD(string) FUZZYWeights(string) GAMMAWeights(string) ///
         HLeft(real .) HRight(real .) KLeft(string) KRight(string) ///
         NOKEEP NODISplay DRAWMATRIX(name)]

    gettoken y x : varlist
    if missing(`c') | missing(`p') | `p' < 0 {
        di as error "c() must be finite and p() must be a nonnegative integer."
        exit 198
    }
    if missing(`bwcheck') | `bwcheck' < 0 {
        di as error "Use bwcheck(0) or noregularize to disable regularization."
        exit 198
    }
    if "`noregularize'" != "" local bwcheck 0
    if missing(`reps') | `reps' < 1 {
        di as error "reps() must be a positive integer."
        exit 198
    }
    local nh : word count `h'
    local hl : word 1 of `h'
    local hr `hl'
    local pooled = (`nh' == 1 & missing(`hleft') & missing(`hright'))
    if `nh' == 2 local hr : word 2 of `h'
    if !missing(`hleft') local hl `hleft'
    if !missing(`hright') local hr `hright'
    if missing(`hl') | missing(`hr') | `hl' <= 0 | `hr' <= 0 {
        di as error "All supplied bandwidths must be positive and finite."
        exit 198
    }
    if "`kernel'" == "" local kernel tri
    local kernel = lower(strtrim("`kernel'"))
    local nk : word count `kernel'
    if `nk' > 2 {
        di as error "kernel() accepts one kernel or two kernels ordered left, right."
        exit 198
    }
    local kl : word 1 of `kernel'
    local kr `kl'
    if `nk' == 2 local kr : word 2 of `kernel'
    if "`kleft'" != "" local kl = lower(strtrim("`kleft'"))
    if "`kright'" != "" local kr = lower(strtrim("`kright'"))
    foreach side in l r {
        if "`k`side''" == "triangular" local k`side' tri
        if "`k`side''" == "epanechnikov" local k`side' epa
        if "`k`side''" == "uniform" local k`side' uni
        if !inlist("`k`side''", "tri", "epa", "uni") {
            di as error "Unknown kernel; use triangular, epanechnikov, or uniform."
            exit 198
        }
    }
    if "`residuals'" == "" local residuals irbc-hc3
    local residuals = lower(strtrim("`residuals'"))
    if inlist("`residuals'", "hc0", "hc1", "hc2", "hc3") local residuals irbc-`residuals'
    if substr("`residuals'",1,4) == "rbc-" local residuals = "cct-" + substr("`residuals'",5,.)
    if !inlist("`residuals'", "irbc-hc0", "irbc-hc1", "irbc-hc2", "irbc-hc3", ///
               "cct-hc0", "cct-hc1", "cct-hc2", "cct-hc3", "loo") {
        di as error "residuals() must be irbc-hc0..irbc-hc3, cct-hc0..cct-hc3, or loo."
        exit 198
    }
    if "`qmethod'" == "" {
        local qmethod sample
        if "`fast'" != "" local qmethod asymptotic
    }
    local qmethod = lower(strtrim("`qmethod'"))
    if inlist("`qmethod'", "qn", "finite", "finitesample") local qmethod sample
    if inlist("`qmethod'", "q", "asym", "population") local qmethod asymptotic
    if !inlist("`qmethod'", "sample", "asymptotic") {
        di as error "qmethod() must be sample or asymptotic."
        exit 198
    }
    if ("`qmethod'" == "asymptotic" & `p' != 1) | ///
       ("`fast'" != "" & "`qmethod'" != "asymptotic") {
        di as error "Asymptotic Q requires p(1); fast also requires qmethod(asymptotic)."
        exit 198
    }
    if "`wild'" == "" local wild rademacher
    local wild = lower(strtrim("`wild'"))
    if "`wild'" == "rad" local wild rademacher
    if "`wild'" == "gaussian" local wild normal
    if !inlist("`wild'", "rademacher", "mammen", "normal") {
        di as error "wild() must be rademacher, mammen, or normal."
        exit 198
    }
    if "`fuzzyweights'" != "" & "`fuzzy'" == "" {
        di as error "fuzzyweights() requires fuzzy()."
        exit 198
    }
    if "`fuzzyweights'" == "" local fuzzyweights fixed
    local fuzzyweights = lower(strtrim("`fuzzyweights'"))
    if !inlist("`fuzzyweights'", "fixed", "bootstrap") {
        di as error "fuzzyweights() must be fixed or bootstrap."
        exit 198
    }
    if "`covs'" != "" & "`fuzzyweights'" != "fixed" {
        di as error "Covariate-adjusted fuzzy RD supports fixed fuzzy weights only."
        exit 198
    }
    if "`gammaweights'" != "" {
        if "`fuzzy'" == "" | "`covs'" == "" | lower("`gammaweights'") != "fixed" {
            di as error "gammaweights(fixed) is the only choice, for covariate-adjusted fuzzy RD."
            exit 198
        }
    }
    if "`drawmatrix'" != "" {
        if "`bootstrap'" == "" {
            di as error "drawmatrix() requires bootstrap."
            exit 198
        }
        confirm matrix `drawmatrix'
        if "`seed'" != "" {
            di as error "Do not combine seed() with a supplied drawmatrix()."
            exit 198
        }
    }
    if "`seed'" != "" {
        confirm integer number `seed'
        if "`bootstrap'" == "" {
            di as error "seed() requires bootstrap."
            exit 198
        }
    }

    marksample touse
    markout `touse' `fuzzy' `covs'
    quietly count `if' `in'
    local selected = r(N)
    quietly count if `touse'
    local N = r(N)
    if `N' == 0 error 2000
    local omitted = `selected' - `N'

    capture mata: st_local("irbc_loaded", strofreal(irbc_st_version()))
    if _rc {
        quietly findfile irbcrd.mata
        quietly do `"`r(fn)'"'
    }
    else if "`irbc_loaded'" != "200" {
        di as error "A different iRBC Mata version is loaded; restart Stata before using this release."
        exit 498
    }
    tempname b V H
    if "`seed'" != "" set seed `seed'
    mata: irbc_stata("`y'", "`x'", "`fuzzy'", "`covs'", "`touse'", "`b'", "`V'")
    matrix colnames `b' = tau
    matrix colnames `V' = tau
    matrix rownames `V' = tau
    matrix `H' = (`hl', `hr')
    ereturn post `b' `V', esample(`touse') obs(`N') depname(`y')
    mata: irbc_post()
    ereturn scalar N_selected = `selected'
    ereturn scalar N_omitted = `omitted'
    ereturn scalar c = `c'
    ereturn scalar p = `p'
    ereturn scalar level = `level'
    ereturn scalar bwcheck = `bwcheck'
    ereturn scalar pooled_regularization = `pooled'
    ereturn scalar fast = ("`fast'" != "")
    ereturn scalar gloo = ("`gloo'" != "")
    ereturn matrix h_requested = `H'
    ereturn local kernel_left "`kl'"
    ereturn local kernel_right "`kr'"
    ereturn local residuals "`residuals'"
    ereturn local qmethod "`qmethod'"
    ereturn local covs "`covs'"
    ereturn local fuzzy "`fuzzy'"
    ereturn local runningvar "`x'"
    ereturn local vce "robust"
    ereturn local vcetype "iRBC"
    ereturn local validation "development: Stata execution pending"
    ereturn local version "2.0-dev"
    ereturn local cmdline `"`cmdline'"'
    ereturn local cmd "irbcrd"
    if "`bootstrap'" != "" {
        ereturn scalar boot_B = `reps'
        ereturn local boot_impl "plug-in"
        ereturn local wild "`wild'"
        if "`drawmatrix'" != "" ereturn local wild "supplied"
        ereturn local fuzzyweights "`fuzzyweights'"
        if "`fuzzy'" != "" & "`covs'" != "" ereturn local gammaweights "fixed"
        if "`seed'" != "" ereturn scalar boot_seed = `seed'
        if e(boot_success) < 2 di as error "Warning: fewer than two finite bootstrap draws; bootstrap CI is missing."
    }
    if "`nodisplay'" == "" _irbcrd_display
end

program define _irbcrd_display
    version 16.0
    di as text _newline "iRBCrd: `e(design)' regression discontinuity"
    di as text "Development build: native Stata execution has not yet been validated."
    di as text "Observations = " as result e(N) as text "    Confidence level = " as result e(level) as text "%"
    di as text "Residuals: `e(residuals)'    Q: `e(qmethod)'"
    matlist e(table_irbc), format(%12.6g) names(all) border(rows)
    if "`e(boot_impl)'" != "" {
        di as text "Bootstrap: `e(wild)', " as result e(boot_success) as text "/" as result e(boot_B) as text " finite draws."
        di as text "Bootstrap estimate equals analytic iRBC; bootstrap intervals need not be centered on it."
    }
    if e(N_omitted)>0 di as text "Excluded " as result e(N_omitted) as text " observations with missing analysis variables."
end
