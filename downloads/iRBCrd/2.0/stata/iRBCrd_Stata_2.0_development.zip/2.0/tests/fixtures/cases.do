* Generated from R 2.0. Run via tests/run_tests.do, from the package folder.
import delimited using "tests/fixtures/case_001_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_001_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_001")
import delimited using "tests/fixtures/case_002_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc1) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_002_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_002")
import delimited using "tests/fixtures/case_003_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc2) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_003_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_003")
import delimited using "tests/fixtures/case_004_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_004_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_004")
import delimited using "tests/fixtures/case_005_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_005_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_005")
import delimited using "tests/fixtures/case_006_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc1) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_006_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_006")
import delimited using "tests/fixtures/case_007_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc2) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_007_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_007")
import delimited using "tests/fixtures/case_008_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_008_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_008")
import delimited using "tests/fixtures/case_009_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc0) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_009_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_009")
import delimited using "tests/fixtures/case_010_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc1) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_010_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_010")
import delimited using "tests/fixtures/case_011_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc2) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_011_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_011")
import delimited using "tests/fixtures/case_012_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_012_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_012")
import delimited using "tests/fixtures/case_013_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc0) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_013_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_013")
import delimited using "tests/fixtures/case_014_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc1) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_014_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_014")
import delimited using "tests/fixtures/case_015_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc2) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_015_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_015")
import delimited using "tests/fixtures/case_016_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_016_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_016")
import delimited using "tests/fixtures/case_017_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_017_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_017")
import delimited using "tests/fixtures/case_018_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc1) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_018_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_018")
import delimited using "tests/fixtures/case_019_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc2) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_019_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_019")
import delimited using "tests/fixtures/case_020_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_020_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_020")
import delimited using "tests/fixtures/case_021_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_021_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_021")
import delimited using "tests/fixtures/case_022_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc1) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_022_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_022")
import delimited using "tests/fixtures/case_023_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc2) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_023_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_023")
import delimited using "tests/fixtures/case_024_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_024_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_024")
import delimited using "tests/fixtures/case_025_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc0) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_025_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_025")
import delimited using "tests/fixtures/case_026_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc1) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_026_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_026")
import delimited using "tests/fixtures/case_027_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc2) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_027_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_027")
import delimited using "tests/fixtures/case_028_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_028_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_028")
import delimited using "tests/fixtures/case_029_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc0) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_029_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_029")
import delimited using "tests/fixtures/case_030_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc1) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_030_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_030")
import delimited using "tests/fixtures/case_031_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc2) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_031_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_031")
import delimited using "tests/fixtures/case_032_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_032_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_032")
import delimited using "tests/fixtures/case_033_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_033_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_033")
import delimited using "tests/fixtures/case_034_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc1) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_034_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_034")
import delimited using "tests/fixtures/case_035_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc2) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_035_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_035")
import delimited using "tests/fixtures/case_036_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_036_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_036")
import delimited using "tests/fixtures/case_037_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_037_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_037")
import delimited using "tests/fixtures/case_038_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc1) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_038_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_038")
import delimited using "tests/fixtures/case_039_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc2) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_039_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_039")
import delimited using "tests/fixtures/case_040_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_040_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_040")
import delimited using "tests/fixtures/case_041_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc0) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_041_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_041")
import delimited using "tests/fixtures/case_042_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc1) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_042_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_042")
import delimited using "tests/fixtures/case_043_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc2) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_043_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_043")
import delimited using "tests/fixtures/case_044_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_044_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_044")
import delimited using "tests/fixtures/case_045_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc0) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_045_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_045")
import delimited using "tests/fixtures/case_046_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc1) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_046_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_046")
import delimited using "tests/fixtures/case_047_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc2) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_047_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_047")
import delimited using "tests/fixtures/case_048_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_048_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_048")
import delimited using "tests/fixtures/case_049_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_049_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_049")
import delimited using "tests/fixtures/case_050_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc1) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_050_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_050")
import delimited using "tests/fixtures/case_051_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc2) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_051_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_051")
import delimited using "tests/fixtures/case_052_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_052_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_052")
import delimited using "tests/fixtures/case_053_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_053_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_053")
import delimited using "tests/fixtures/case_054_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc1) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_054_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_054")
import delimited using "tests/fixtures/case_055_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc2) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_055_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_055")
import delimited using "tests/fixtures/case_056_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_056_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_056")
import delimited using "tests/fixtures/case_057_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc0) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_057_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_057")
import delimited using "tests/fixtures/case_058_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc1) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_058_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_058")
import delimited using "tests/fixtures/case_059_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc2) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_059_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_059")
import delimited using "tests/fixtures/case_060_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_060_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_060")
import delimited using "tests/fixtures/case_061_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc0) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_061_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_061")
import delimited using "tests/fixtures/case_062_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc1) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_062_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_062")
import delimited using "tests/fixtures/case_063_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc2) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_063_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_063")
import delimited using "tests/fixtures/case_064_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_064_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_064")
import delimited using "tests/fixtures/case_065_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(1) kernel(epa) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_065_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_065")
import delimited using "tests/fixtures/case_066_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(1) kernel(uni) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_066_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_066")
import delimited using "tests/fixtures/case_067_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(99) bootstrap reps(39) wild(mammen) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_067_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_067")
import delimited using "tests/fixtures/case_068_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(99) bootstrap reps(39) wild(normal) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_068_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_068")
import delimited using "tests/fixtures/case_069_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.55 0.75) c(0) p(1) kernel(tri epa) residuals(irbc-hc3) qmethod(sample) bwcheck(0) level(90) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_069_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_069")
import delimited using "tests/fixtures/case_070_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(2) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_070_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_070")
import delimited using "tests/fixtures/case_071_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(0) kernel(tri) residuals(cct-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_071_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_071")
import delimited using "tests/fixtures/case_072_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fast
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_072_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_072")
import delimited using "tests/fixtures/case_073_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(loo) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_073_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_073")
import delimited using "tests/fixtures/case_074_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(loo) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay gloo
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_074_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_074")
import delimited using "tests/fixtures/case_075_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay gloo
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_075_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_075")
import delimited using "tests/fixtures/case_076_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/binary.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_076_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_076")
import delimited using "tests/fixtures/case_077_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/sparse.csv", varnames(1) asdouble clear
irbcrd y x, h(0.04) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_077_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_077")
import delimited using "tests/fixtures/case_078_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/sparse.csv", varnames(1) asdouble clear
irbcrd y x, h(0.04 0.06) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(30) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_078_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_078")
import delimited using "tests/fixtures/case_079_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/shifted.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0.25) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_079_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_079")
import delimited using "tests/fixtures/case_080_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/tied.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.7) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_080_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_080")
import delimited using "tests/fixtures/case_081_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(1) kernel(epa) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_081_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_081")
import delimited using "tests/fixtures/case_082_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(1) kernel(uni) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_082_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_082")
import delimited using "tests/fixtures/case_083_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(99) bootstrap reps(39) wild(mammen) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_083_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_083")
import delimited using "tests/fixtures/case_084_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(99) bootstrap reps(39) wild(normal) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_084_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_084")
import delimited using "tests/fixtures/case_085_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.55 0.75) c(0) p(1) kernel(tri epa) residuals(irbc-hc3) qmethod(sample) bwcheck(0) level(90) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_085_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_085")
import delimited using "tests/fixtures/case_086_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(2) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_086_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_086")
import delimited using "tests/fixtures/case_087_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(0) kernel(tri) residuals(cct-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_087_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_087")
import delimited using "tests/fixtures/case_088_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fast fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_088_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_088")
import delimited using "tests/fixtures/case_089_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(loo) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_089_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_089")
import delimited using "tests/fixtures/case_090_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(loo) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay gloo fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_090_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_090")
import delimited using "tests/fixtures/case_091_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay gloo fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_091_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_091")
import delimited using "tests/fixtures/case_092_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/binary.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_092_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_092")
import delimited using "tests/fixtures/case_093_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/sparse.csv", varnames(1) asdouble clear
irbcrd y x, h(0.04) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_093_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_093")
import delimited using "tests/fixtures/case_094_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/sparse.csv", varnames(1) asdouble clear
irbcrd y x, h(0.04 0.06) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(30) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_094_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_094")
import delimited using "tests/fixtures/case_095_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/shifted.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0.25) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_095_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_095")
import delimited using "tests/fixtures/case_096_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/tied.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.7) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_096_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_096")
import delimited using "tests/fixtures/case_097_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(1) kernel(epa) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_097_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_097")
import delimited using "tests/fixtures/case_098_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(1) kernel(uni) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_098_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_098")
import delimited using "tests/fixtures/case_099_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(99) bootstrap reps(39) wild(mammen) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_099_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_099")
import delimited using "tests/fixtures/case_100_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(99) bootstrap reps(39) wild(normal) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_100_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_100")
import delimited using "tests/fixtures/case_101_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.55 0.75) c(0) p(1) kernel(tri epa) residuals(irbc-hc3) qmethod(sample) bwcheck(0) level(90) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_101_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_101")
import delimited using "tests/fixtures/case_102_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(2) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_102_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_102")
import delimited using "tests/fixtures/case_103_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(0) kernel(tri) residuals(cct-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_103_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_103")
import delimited using "tests/fixtures/case_104_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fast covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_104_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_104")
import delimited using "tests/fixtures/case_105_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(loo) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_105_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_105")
import delimited using "tests/fixtures/case_106_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(loo) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay gloo covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_106_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_106")
import delimited using "tests/fixtures/case_107_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay gloo covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_107_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_107")
import delimited using "tests/fixtures/case_108_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/binary.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_108_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_108")
import delimited using "tests/fixtures/case_109_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/sparse.csv", varnames(1) asdouble clear
irbcrd y x, h(0.04) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_109_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_109")
import delimited using "tests/fixtures/case_110_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/sparse.csv", varnames(1) asdouble clear
irbcrd y x, h(0.04 0.06) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(30) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_110_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_110")
import delimited using "tests/fixtures/case_111_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/shifted.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0.25) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_111_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_111")
import delimited using "tests/fixtures/case_112_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/tied.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.7) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_112_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_112")
import delimited using "tests/fixtures/case_113_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(1) kernel(epa) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_113_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_113")
import delimited using "tests/fixtures/case_114_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(1) kernel(uni) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_114_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_114")
import delimited using "tests/fixtures/case_115_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(99) bootstrap reps(39) wild(mammen) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_115_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_115")
import delimited using "tests/fixtures/case_116_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(99) bootstrap reps(39) wild(normal) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_116_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_116")
import delimited using "tests/fixtures/case_117_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.55 0.75) c(0) p(1) kernel(tri epa) residuals(irbc-hc3) qmethod(sample) bwcheck(0) level(90) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_117_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_117")
import delimited using "tests/fixtures/case_118_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.75) c(0) p(2) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_118_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_118")
import delimited using "tests/fixtures/case_119_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(0) kernel(tri) residuals(cct-hc0) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_119_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_119")
import delimited using "tests/fixtures/case_120_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fast fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_120_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_120")
import delimited using "tests/fixtures/case_121_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(loo) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_121_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_121")
import delimited using "tests/fixtures/case_122_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(loo) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay gloo fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_122_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_122")
import delimited using "tests/fixtures/case_123_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay gloo fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_123_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_123")
import delimited using "tests/fixtures/case_124_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/binary.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_124_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_124")
import delimited using "tests/fixtures/case_125_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/sparse.csv", varnames(1) asdouble clear
irbcrd y x, h(0.04) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_125_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_125")
import delimited using "tests/fixtures/case_126_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/sparse.csv", varnames(1) asdouble clear
irbcrd y x, h(0.04 0.06) c(0) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(30) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_126_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_126")
import delimited using "tests/fixtures/case_127_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/shifted.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0.25) p(1) kernel(tri) residuals(irbc-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_127_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_127")
import delimited using "tests/fixtures/case_128_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/tied.csv", varnames(1) asdouble clear
irbcrd y x, h(0.6 0.7) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(fixed) covs(z1 z2)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_128_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_128")
import delimited using "tests/fixtures/case_129_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(bootstrap)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_129_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_129")
import delimited using "tests/fixtures/case_130_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(sample) bwcheck(21) level(95) bootstrap reps(39) wild(mammen) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(bootstrap)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_130_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_130")
import delimited using "tests/fixtures/case_131_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(bootstrap)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_131_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_131")
import delimited using "tests/fixtures/case_132_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(tri) residuals(cct-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(mammen) drawmatrix(__irbc_test_W) nodisplay fuzzy(d) fuzzyweights(bootstrap)
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_132_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_132")
import delimited using "tests/fixtures/case_133_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(epa) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fast
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_133_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_133")
import delimited using "tests/fixtures/case_134_weights.csv", varnames(1) asdouble clear
mkmat _all, matrix(__irbc_test_W)
import delimited using "tests/fixtures/balanced.csv", varnames(1) asdouble clear
irbcrd y x, h(0.65) c(0) p(1) kernel(uni) residuals(irbc-hc3) qmethod(asymptotic) bwcheck(21) level(95) bootstrap reps(39) wild(rademacher) drawmatrix(__irbc_test_W) nodisplay fast
assert e(estimate_irbc_boot) == e(estimate_irbc)
import delimited using "tests/fixtures/case_134_expected.csv", varnames(1) asdouble clear
mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "case_134")
