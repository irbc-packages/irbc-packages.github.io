# Portable integrity checks only; this is not a Mata compiler or Stata runtime.
args <- commandArgs(trailingOnly = FALSE)
file <- sub("^--file=", "", args[grepl("^--file=", args)])
if (length(file) != 1L) stop("Run with Rscript tests/check_bundle.R")
here <- dirname(normalizePath(file, mustWork = TRUE))
root <- dirname(here)

manifest <- readLines(file.path(root, "irbcrd.pkg"), warn = FALSE)
required <- sub("^f +", "", manifest[grepl("^f +", manifest)])
stopifnot(length(required) > 0L, all(file.exists(file.path(root, required))))

# Check delimiters outside Mata strings/comments. Apostrophes are transposes.
check_mata <- function(path) {
  source <- paste(readLines(path, warn = FALSE), collapse = "\n")
  chars <- strsplit(source, "", fixed = TRUE)[[1]]
  state <- "code"
  stack <- character()
  pairs <- c(")" = "(", "]" = "[", "}" = "{")
  i <- 1L
  while (i <= length(chars)) {
    a <- chars[i]
    b <- if (i < length(chars)) chars[i + 1L] else ""
    if (state == "line") {
      if (a == "\n") state <- "code"
    } else if (state == "block") {
      if (a == "*" && b == "/") {
        state <- "code"
        i <- i + 1L
      }
    } else if (state == "string") {
      if (a == '"') state <- "code"
    } else if (a == "/" && b == "/") {
      state <- "line"
      i <- i + 1L
    } else if (a == "/" && b == "*") {
      state <- "block"
      i <- i + 1L
    } else if (a == '"') {
      state <- "string"
    } else if (a %in% c("(", "[", "{")) {
      stack <- c(stack, a)
    } else if (a %in% names(pairs)) {
      if (!length(stack) || tail(stack, 1) != pairs[[a]]) {
        stop("Unbalanced delimiter in ", basename(path), " at character ", i)
      }
      stack <- head(stack, -1L)
    }
    i <- i + 1L
  }
  stopifnot(!length(stack), state %in% c("code", "line"))
}
check_mata(file.path(root, "irbcrd.mata"))
check_mata(file.path(here, "assertions.mata"))

fixtures <- file.path(here, "fixtures")
cases <- read.csv(file.path(fixtures, "manifest.csv"))
stopifnot(nrow(cases) == 134L, all(is.finite(cases$max_scaled_error)),
          max(cases$max_scaled_error) < 1e-8)
for (i in seq_len(nrow(cases))) {
  row <- cases[i, ]
  expected <- read.csv(file.path(fixtures, paste0(row$case, "_expected.csv")), na.strings = ".")
  weights <- as.matrix(read.csv(file.path(fixtures, paste0(row$case, "_weights.csv"))))
  data <- read.csv(file.path(fixtures, paste0(row$dataset, ".csv")))
  stopifnot(nrow(expected) == row$compared_values, is.numeric(expected$value),
            !anyDuplicated(expected$field), nrow(weights) == nrow(data),
            ncol(weights) == 39L, all(is.finite(weights)))
}

reference <- file.path(here, "reference_R_2.0", c("iRBC_functions.R", "iRBCrd.R"))
expected_md5 <- c("d10cc49c84a826f39661a82e138b1ed7", "b60c35a37d2d8fc02ef78054d006ea82")
stopifnot(identical(unname(tools::md5sum(reference)), expected_md5))
report <- c("Bundle integrity: PASS", paste("Fixture cases:", nrow(cases)),
            paste("Expected numeric values:", sum(cases$compared_values)),
            "Manifest, Mata delimiters, fixture dimensions, and reference hashes checked.",
            "These are static integrity checks, NOT native Stata validation.")
writeLines(report, file.path(here, "BUNDLE_CHECK.txt"))
cat(paste(report, collapse = "\n"), "\n")
