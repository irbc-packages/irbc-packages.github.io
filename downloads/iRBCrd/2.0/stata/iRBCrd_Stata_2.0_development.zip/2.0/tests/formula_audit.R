# Independent R evaluation of the matrix formulas used in irbcrd.mata.
# This tests the algebra, not Mata syntax or Stata execution.
audit_h <- function(x, x0, h, bw) {
  if (!bw) return(h)
  max(h, sort(abs(x - x0))[min(length(x), bw)])
}
audit_kernel <- function(u, k) {
  w <- numeric(length(u))
  a <- abs(u) <= 1
  w[a] <- switch(k, tri = 1 - abs(u[a]), epa = .75 * (1 - u[a]^2), uni = .5)
  w
}
audit_basis <- function(u, p) outer(u, 0:p, `^`)
audit_local <- function(x, x0, h, p, k, bw) {
  h <- audit_h(x, x0, h, bw)
  R <- audit_basis((x - x0) / h, p)
  w <- audit_kernel((x - x0) / h, k) / h
  G <- chol2inv(chol(crossprod(R * sqrt(w))))
  A <- (w * R) %*% G
  list(h = h, nh = sum(w > 0), a = A[, 1], A = A,
       lev = rowSums((R %*% G) * (w * R)))
}
audit_hc <- function(raw, lev, nh, df, hc) {
  if (!hc) return(raw)
  adj <- if (hc == 1) (nh - df) / nh else 1 - lev
  stopifnot(all(is.finite(adj)), all(adj > 0))
  if (hc %in% 1:2) adj <- sqrt(adj)
  raw / adj
}
audit_side <- function(x, Y, h, k, o) {
  n <- length(x)
  p <- o$p
  f0 <- audit_local(x, o$c, h, p, k, o$bw)
  point <- drop(crossprod(f0$a, Y))
  bias_active <- abs(x - o$c) < 2 * h
  res_active <- abs(x - o$c) <= 2 * f0$h
  needed <- bias_active | abs(x - o$c) <= f0$h
  if (startsWith(o$res, "irbc-")) needed <- needed | res_active
  fitted <- loo_fitted <- matrix(0, n, ncol(Y))
  Ci <- numeric(n)
  lev <- nh <- rep(NA_real_, n)
  for (j in which(needed)) {
    f <- audit_local(x, x[j], h, p, k, o$bw)
    fitted[j, ] <- crossprod(f$a, Y)
    lev[j] <- f$a[j]
    nh[j] <- f$nh
    if (bias_active[j]) {
      if (o$q == "sample") Ci[j] <- sum(f$a * ((x - x[j]) / h)^(p + 1))
      if (o$gloo) {
        f <- audit_local(x[-j], x[j], h, p, k, o$bw)
        loo_fitted[j, ] <- crossprod(f$a, Y[-j, , drop = FALSE])
      }
    }
  }
  Q <- if (o$q == "sample") {
    sum(f0$a * ((x - o$c) / h)^(p + 1)) / sum(f0$a * Ci)
  } else c(tri = 1.4082, epa = 1.3571, uni = 1.2)[[k]]
  gb <- if (o$gloo) loo_fitted else fitted * bias_active
  bias <- Q * drop(crossprod(f0$a, sweep(gb, 2, point)))
  if (o$res == "loo") eps <- Y - gb else {
    hc <- as.integer(substr(o$res, nchar(o$res), nchar(o$res)))
    if (startsWith(o$res, "cct-")) {
      f <- audit_local(x, o$c, h, p + 1, k, 0)
      fit <- audit_basis((x - o$c) / h, p + 1) %*% crossprod(f$A, Y)
      eps <- audit_hc(Y - fit, f$lev, rep(f$nh, n), p + 2, hc)
    } else {
      eps <- matrix(0, n, ncol(Y))
      a <- which(res_active)
      eps[a, ] <- audit_hc(Y[a, , drop = FALSE] - fitted[a, , drop = FALSE],
                           lev[a], nh[a], p + 1, hc)
    }
  }
  omega <- (1 + Q) * f0$a
  for (j in which(abs(x - o$c) <= f0$h)) {
    f <- audit_local(x, x[j], f0$h, p, k, o$bw)
    omega <- omega - Q * f0$a[j] * (f$h / f0$h) * f$a
  }
  omega <- omega * (abs(x - o$c) <= 2 * f0$h)
  fastv <- NA_real_
  if (o$fast && ncol(Y) == 1) {
    f <- audit_local(x, o$c, f0$h, p + 1, k, 0)
    wrbc <- f0$a - sum(f0$a * ((x - o$c) / f0$h)^(p + 1)) * f$A[, p + 2]
    fastv <- c(tri = .84, epa = .83, uni = .86)[[k]]^2 * sum((wrbc * eps)^2)
  }
  list(h = h, hfit = f0$h, a = f0$a, Q = Q, nh = f0$nh, point = point,
       bias = bias, eps = eps, fitted = fitted, V = crossprod(eps * omega),
       Vus = crossprod(eps * Q * f0$a), fastv = fastv)
}
audit_gamma <- function(x, U, Z, h, k, o) {
  R <- audit_basis((x - o$c) / h, o$p)
  w <- audit_kernel((x - o$c) / h, k) / h
  G <- chol2inv(chol(crossprod(R * sqrt(w))))
  uz <- crossprod(R * w, Z)
  uy <- crossprod(R * w, U)
  list(zz = crossprod(Z * w, Z) - crossprod(uz, G %*% uz),
       zy = crossprod(Z * w, U) - crossprod(uz, G %*% uy))
}
audit_compute <- function(data, o, draws) {
  x <- data$x
  nc <- if (o$design %in% c("crd", "cfrd")) 2L else 0L
  fuzzy <- o$design %in% c("frd", "cfrd")
  cols <- c("y", if (fuzzy) "d", if (nc) c("z1", "z2"))
  Y <- as.matrix(data[cols])
  nf <- 1L + fuzzy
  k <- ncol(Y)
  right <- x >= o$c
  left <- !right
  hs <- if (length(o$h) == 1) {
    rep(audit_h(x, o$c, o$h, o$bw), 2)
  } else c(audit_h(x[left], o$c, o$h[1], o$bw),
           audit_h(x[right], o$c, o$h[2], o$bw))
  ks <- rep(o$kernel, length.out = 2)
  L <- audit_side(x[left], Y[left, , drop = FALSE], hs[1], ks[1], o)
  R <- audit_side(x[right], Y[right, , drop = FALSE], hs[2], ks[2], o)
  tau <- R$point - L$point
  B <- R$bias - L$bias
  gamma <- matrix(numeric(0), 0, nf)
  wy <- c(1, rep(0, k - 1))
  wd <- rep(0, k)
  if (fuzzy) wd[2] <- 1
  if (nc) {
    Z <- Y[, (nf + 1):k, drop = FALSE]
    U <- Y[, seq_len(nf), drop = FALSE]
    a <- audit_gamma(x[left], U[left, , drop = FALSE], Z[left, , drop = FALSE], hs[1], ks[1], o)
    b <- audit_gamma(x[right], U[right, , drop = FALSE], Z[right, , drop = FALSE], hs[2], ks[2], o)
    A <- a$zz + b$zz
    gamma <- chol2inv(chol((A + t(A)) / 2)) %*% (a$zy + b$zy)
    wy[(nf + 1):k] <- -gamma[, 1]
    if (fuzzy) wd[(nf + 1):k] <- -gamma[, 2]
  }
  ty <- sum(wy * tau)
  td <- if (fuzzy) sum(wd * tau) else NA_real_
  unc <- if (fuzzy) ty / td else ty
  weights <- if (fuzzy) wy / td - ty * wd / td^2 else wy
  bias <- sum(weights * B)
  V <- L$V + R$V
  Vus <- L$Vus + R$Vus
  se <- sqrt(drop(weights %*% V %*% weights))
  if (!o$fast && k == 1) se <- sqrt(L$V[1,1] * L$hfit / hs[1] + R$V[1,1] * R$hfit / hs[2])
  if (o$fast && k == 1) se <- sqrt(L$fastv + R$fastv)
  seus <- sqrt(drop(weights %*% Vus %*% weights))
  eps <- mean <- matrix(0, nrow(Y), k)
  eps[left, ] <- L$eps
  eps[right, ] <- R$eps
  mean[left, ] <- L$fitted
  mean[right, ] <- R$fitted
  hboot <- if (k == 1) c(L$hfit, R$hfit) else hs
  local <- ifelse(right, abs(x - o$c) <= hboot[2], abs(x - o$c) <= hboot[1])
  bc <- matrix(NA_real_, ncol(draws), k)
  bt <- bfs <- rep(NA_real_, ncol(draws))
  for (b in seq_len(ncol(draws))) {
    delta <- matrix(0, nrow(Y), k)
    delta[local, ] <- (mean - Y)[local, , drop = FALSE] +
      eps[local, , drop = FALSE] * draws[local, b]
    dl <- drop(crossprod(L$a, delta[left, , drop = FALSE]))
    dr <- drop(crossprod(R$a, delta[right, , drop = FALSE]))
    bc[b, ] <- R$Q * dr - L$Q * dl
    if (fuzzy) bfs[b] <- sum(wd * (tau + dr - dl))
    if (o$fw == "bootstrap") {
      db <- tau[2] + dr[2] - dl[2]
      if (abs(db) <= sqrt(.Machine$double.eps)) next
      bt[b] <- bc[b, 1] / db - bc[b, 2] * tau[1] / (tau[2] * db)
    } else bt[b] <- sum(bc[b, ] * weights)
  }
  probs <- pnorm((se / seus) * qnorm(c(o$alpha / 2, 1 - o$alpha / 2)))
  list(estimate = unc - bias, uncorrected = unc, bias = bias, se = se, se_us = seus,
       first_stage = td, h = hs, hfit = c(L$hfit, R$hfit), Q = c(L$Q, R$Q),
       nh = c(L$nh, R$nh), ci = unc - bias + qnorm(c(o$alpha / 2, 1 - o$alpha / 2)) * se,
       ci_boot = unc - rev(quantile(bt, probs, type = 7, names = FALSE, na.rm = TRUE)),
       probs = probs, weights = weights, components = tau, component_bias = B,
       gamma = gamma, cov_irbc = V, cov_us = Vus, residuals = eps,
       boot_t = bt, boot_components = bc, boot_first_stage = bfs,
       mhat = se / seus, boot_success = sum(is.finite(bt)))
}
