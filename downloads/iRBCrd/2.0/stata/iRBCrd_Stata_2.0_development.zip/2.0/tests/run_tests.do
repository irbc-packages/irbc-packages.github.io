* Run in a NEW Stata session, with the package folder as the working directory.
* This script replaces the data in memory and writes tests/stata_validation.log.
version 16.0
clear all
set more off
set matsize 400
capture log close irbc_tests
log using "tests/stata_validation.log", name(irbc_tests) text replace
adopath ++ "."
do "irbcrd.mata"
do "tests/assertions.mata"
do "tests/fixtures/cases.do"

* Native RNG reproducibility, all three wild-weight distributions, and nokeep.
import delimited using "tests/fixtures/binary.csv", varnames(1) asdouble clear
foreach wild in rademacher mammen normal {
    quietly irbcrd y x, h(.65) fuzzy(d) covs(z1 z2) bootstrap reps(39) seed(17041998) wild(`wild')
    mata: irbc_test_saved = irbc_last.boot_t
    matrix __irbc_test_ci = e(ci_irbc_boot)
    quietly irbcrd y x, h(.65) fuzzy(d) covs(z1 z2) bootstrap reps(39) seed(17041998) wild(`wild')
    mata: assert(all(irbc_test_saved:==irbc_last.boot_t))
    quietly irbcrd y x, h(.65) fuzzy(d) covs(z1 z2) bootstrap reps(39) seed(17041998) wild(`wild') nokeep
    mata: assert(rows(irbc_last.boot_t)==0)
    mata: assert(all(st_matrix("__irbc_test_ci"):==st_matrix("e(ci_irbc_boot)")))
}

* R type-7 interpolation and the single-draw/no-bootstrap return paths.
mata: assert(abs(irbc_quantile((0\10\20\30),.25)-7.5)<1e-12)
quietly irbcrd y x, h(.65) bootstrap reps(1) seed(17041998)
assert e(boot_success)==1
mata: assert(all(st_matrix("e(ci_irbc_boot)"):>=.))
quietly irbcrd y x, h(.65)
assert "`e(boot_impl)'"==""
mata: assert(rows(irbc_last.boot_t)==0)

* Public entry point: missing data, if/in, sample marking, replay, and estimates.
replace y = . in 1
replace z1 = . in 2
quietly count if !missing(y,x,d,z1,z2) & _n<=150
local wanted = r(N)
quietly datasignature
local signature `"`r(datasignature)'"'
quietly irbcrd y x if _n<=150, h(.65) fuzzy(d) covs(z1 z2)
assert e(N)==`wanted'
assert e(N_omitted)==2
quietly count if e(sample)
assert r(N)==`wanted'
assert e(estimate_irbc)==_b[tau]
assert abs(e(se_irbc)-_se[tau])<1e-12
quietly datasignature
assert `"`signature'"'==`"`r(datasignature)'"'
irbcrd
quietly irbcrd y x in 3/160, h(.65) level(90)
irbcrd
capture irbcrd, level(95)
assert _rc==198
quietly irbcrd y x, h(.6 .7) kernel(triangular epanechnikov) residuals(rbc-hc3)
assert "`e(residuals)'"=="cct-hc3"
quietly irbcrd y x, h(.6) hright(.7) kernel(tri) kright(epa) residuals(hc3)
assert "`e(residuals)'"=="irbc-hc3"

* Invalid specifications must fail instead of silently selecting another method.
capture irbcrd y x, h(.6) qmethod(asymptotic) p(2)
assert _rc==198
capture irbcrd y x, h(.6) qmethod(sample) fast
assert _rc==198
capture irbcrd y x, h(.6) fuzzyweights(bootstrap)
assert _rc==198
capture irbcrd y x, h(.6) fuzzy(d) covs(z1) fuzzyweights(bootstrap)
assert _rc==198
capture irbcrd y x, h(.6) gammaweights(bootstrap)
assert _rc==198
capture irbcrd y x, h(.6) bootstrap reps(0)
assert _rc==198
capture irbcrd y x, h(.6) residuals(unknown)
assert _rc==198
capture irbcrd y x, h(.6) fuzzy(d) gloo
assert _rc==498
generate double __zero = 0
capture irbcrd y x, h(.6) fuzzy(__zero)
assert _rc==498
capture irbcrd y x, h(.6) covs(__zero)
assert _rc==498

* Reload the numerical routines after mata clear, without dropping other programs.
mata clear
quietly irbcrd y x, h(.65) res(cct-hc3)
assert !missing(e(estimate_irbc))
di as result "PASS: all native Stata/R fixture comparisons and interface tests."
log close irbc_tests
