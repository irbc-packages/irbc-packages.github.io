# Developer tool only. Stata users do not need R to use the command or tests.
main <- function() {
  arg <- grep("^--file=", commandArgs(), value = TRUE)
  here <- if (length(arg)) dirname(normalizePath(sub("^--file=", "", arg[1]))) else normalizePath("tests")
  root <- dirname(here)
  output <- file.path(here, "fixtures")
  dir.create(output, recursive = TRUE, showWarnings = FALSE)
  snapshot <- file.path(here, "reference_R_2.0")
  dir.create(snapshot, showWarnings = FALSE)
  reference <- file.path(root, "../../R/2.0")
  if (!dir.exists(reference)) reference <- snapshot
  reference <- normalizePath(reference, mustWork = TRUE)
  sources <- file.path(reference, c("iRBC_functions.R", "iRBCrd.R"))
  expected_md5 <- c("d10cc49c84a826f39661a82e138b1ed7", "b60c35a37d2d8fc02ef78054d006ea82")
  stopifnot(identical(unname(tools::md5sum(sources)), expected_md5))
  if (reference != normalizePath(snapshot)) {
    stopifnot(all(file.copy(sources, snapshot, overwrite = TRUE)))
  }
  E <- new.env(parent = globalenv())
  for (f in basename(sources)) sys.source(file.path(snapshot, f), E)
  sys.source(file.path(here, "formula_audit.R"), environment())
  old_options <- options(digits = 17)
  on.exit(options(old_options), add = TRUE)
  csv <- function(x, path) write.table(x, path, sep = ",", row.names = FALSE,
                                     col.names = TRUE, quote = FALSE, na = ".")
  set.seed(17041998)
  make_data <- function(x, binary = FALSE) {
    n <- length(x)
    z1 <- .3 * x + rnorm(n)
    z2 <- -.2 * x + rnorm(n)
    d <- if (binary) rbinom(n, 1, .15 + .7 * (x >= 0)) else
      1 + 1.5 * (x >= 0) + .2 * x + .2 * z1 + rnorm(n, sd = .3)
    y <- 1 + .8 * d + x + .6 * x^2 + .2 * x^3 + .4 * z1 - .25 * z2 + rnorm(n)
    data.frame(y, x, d, z1, z2)
  }
  balanced <- make_data(sample(seq(-.99, .99, length.out = 160)))
  binary <- make_data(c(0, sample(seq(-.98, .98, length.out = 159))), TRUE)
  sparse <- make_data(sample(c(seq(-1, -.02, length.out = 24), seq(.01, .9, length.out = 96))))
  shifted <- balanced
  shifted$x <- shifted$x + .25
  tied <- make_data(rep(seq(-1, 1, length.out = 41), each = 4))
  datasets <- list(balanced = balanced, binary = binary, sparse = sparse,
                   shifted = shifted, tied = tied)
  for (nm in names(datasets)) csv(datasets[[nm]], file.path(output, paste0(nm, ".csv")))

  cases <- list()
  add <- function(design, ...) {
    o <- modifyList(list(design = design, dataset = "balanced", h = .65, c = 0,
                         p = 1L, kernel = "tri", res = "irbc-hc3", q = "sample",
                         bw = 21L, fast = FALSE, gloo = FALSE, fw = "fixed",
                         alpha = .05, wild = "rademacher", B = 39L), list(...))
    cases[[length(cases) + 1L]] <<- o
  }
  designs <- c("srd", "frd", "crd", "cfrd")
  for (d in designs) for (q in c("sample", "asymptotic")) {
    for (res in c(paste0("irbc-hc", 0:3), paste0("cct-hc", 0:3))) add(d, q = q, res = res)
  }
  for (d in designs) {
    for (ker in c("epa", "uni")) add(d, kernel = ker, h = c(.6, .75))
    for (wild in c("mammen", "normal")) add(d, wild = wild, alpha = .01)
    add(d, h = c(.55, .75), kernel = c("tri", "epa"), alpha = .1, bw = 0L)
    add(d, h = c(.6, .75), res = "cct-hc3", p = 2L)
    add(d, p = 0L, res = "cct-hc0")
    add(d, q = "asymptotic", fast = TRUE)
    add(d, res = "loo")
    add(d, res = "loo", gloo = TRUE)
    add(d, gloo = TRUE, res = "cct-hc3")
    add(d, dataset = "binary", res = "cct-hc3")
    add(d, dataset = "sparse", h = .04)
    add(d, dataset = "sparse", h = c(.04, .06), bw = 30L)
    add(d, dataset = "shifted", c = .25)
    add(d, dataset = "tied", h = c(.6, .7), res = "cct-hc3")
  }
  for (q in c("sample", "asymptotic")) for (wild in c("rademacher", "mammen")) {
    add("frd", q = q, wild = wild, fw = "bootstrap", res = "cct-hc3")
  }
  for (ker in c("epa", "uni")) add("srd", kernel = ker, q = "asymptotic", fast = TRUE)

  fields <- c("estimate", "uncorrected", "bias", "se", "se_us", "first_stage",
              "h", "hfit", "Q", "nh", "ci", "ci_boot", "probs", "weights",
              "components", "component_bias", "gamma", "cov_irbc", "cov_us",
              "residuals", "boot_t", "boot_components", "boot_first_stage", "mhat", "boot_success")
  flatten <- function(x) unlist(lapply(x[fields], as.numeric), use.names = FALSE)
  get_reference <- function(data, o, W) {
    x <- data$x
    right <- x >= o$c
    left <- !right
    fuzzy <- o$design %in% c("frd", "cfrd")
    adjusted <- o$design %in% c("crd", "cfrd")
    columns <- c("y", if (fuzzy) "d", if (adjusted) c("z1", "z2"))
    Y <- as.matrix(data[columns])
    bw <- if (o$bw == 0) NULL else o$bw
    hs <- if (length(o$h) == 1) rep(E$.regularize_h(x,o$c,o$h,bw),2) else
      c(E$.regularize_h(x[left],o$c,o$h[1],bw),E$.regularize_h(x[right],o$c,o$h[2],bw))
    hfit <- c(E$.regularize_h(x[left],o$c,hs[1],bw),E$.regularize_h(x[right],o$c,hs[2],bw))
    hb <- if (o$design == "srd") hfit else hs
    local <- which(ifelse(right, abs(x-o$c)<=hb[2], abs(x-o$c)<=hb[1]))
    original <- E$.irbcrd_wild_draws
    bb <- 0L
    E$.irbcrd_wild_draws <- function(n, wild) {
      bb <<- bb + 1L
      stopifnot(n == length(local), bb <= ncol(W))
      W[local, bb]
    }
    on.exit(E$.irbcrd_wild_draws <- original, add = TRUE)
    args <- list(y = data$y, x = x, h = o$h, c = o$c, p = o$p,
                 kersel = o$kernel, res = o$res, alpha = o$alpha,
                 q.method = o$q, bwcheck = bw, fast = o$fast, g.loo = o$gloo,
                 boot.ci = TRUE, boot.B = o$B, boot.wild = o$wild)
    if (fuzzy) {
      args$fuzzy <- data$d
      args$fuzzy.boot.weights <- o$fw
    }
    if (adjusted) args$covs <- as.matrix(data[c("z1", "z2")])
    fit <- do.call(E$iRBCrd, args)
    stopifnot(bb == o$B)
    fits <- switch(o$design, srd = list(fit), frd = list(fit$sharp.outcome,fit$sharp.treatment),
                   crd = c(list(fit$sharp.outcome),fit$sharp.covariates),
                   cfrd = c(list(fit$sharp.outcome,fit$sharp.treatment),fit$sharp.covariates))
    tau <- vapply(fits,function(f) as.numeric(f$tau.hat), numeric(1))
    B <- vapply(fits,function(f) as.numeric(f$Bhat.irbc),numeric(1))
    eps <- matrix(0,nrow(Y),ncol(Y))
    for (j in seq_along(fits)) {
      eps[right,j] <- fits[[j]]$epshat.plus
      eps[left,j] <- fits[[j]]$epshat.minus
    }
    gamma <- if (!adjusted) matrix(numeric(0),0,1L+fuzzy) else if (fuzzy)
      cbind(fit$gamma.y.hat,fit$gamma.d.hat) else matrix(fit$gamma.hat,ncol=1)
    weights <- switch(o$design,srd=1,frd=fit$frd.weights,crd=fit$crd.weights,cfrd=fit$cfrd.weights)
    covariance <- function(kind) E$.irbcrd_joint_sandwich(
      x.plus=x[right],x.minus=x[left],x0=o$c,h.plus=hs[2],h.minus=hs[1],p=o$p,
      kersel.plus=fit$kersel.plus,kersel.minus=fit$kersel.minus,
      Q.plus=fit$Q.plus,Q.minus=fit$Q.minus,
      eps.plus=eps[right,,drop=FALSE],eps.minus=eps[left,,drop=FALSE],weights=kind,bwcheck=bw)
    ap <- E$.irbcrd_lp_component_weights(x[right],o$c,hs[2],o$p,fit$kersel.plus,bw)
    am <- E$.irbcrd_lp_component_weights(x[left],o$c,hs[1],o$p,fit$kersel.minus,bw)
    g <- matrix(0,nrow(Y),ncol(Y))
    for (i in local) {
      side <- if (right[i]) right else left
      j <- if (right[i]) 2 else 1
      ker <- if (right[i]) fit$kersel.plus else fit$kersel.minus
      g[i,] <- E$.irbcrd_lp_component_estimate(Y[side,,drop=FALSE],x[side],x[i],hs[j],o$p,ker,bw)
    }
    bc <- matrix(NA_real_,o$B,ncol(Y))
    bfs <- rep(NA_real_,o$B)
    for (b in seq_len(o$B)) {
      delta <- matrix(0,nrow(Y),ncol(Y))
      delta[local,] <- g[local,,drop=FALSE]-Y[local,,drop=FALSE]+eps[local,,drop=FALSE]*W[local,b]
      dp <- drop(crossprod(ap,delta[right,,drop=FALSE]))
      dm <- drop(crossprod(am,delta[left,,drop=FALSE]))
      bc[b,] <- as.numeric(fit$Q.plus)*dp-as.numeric(fit$Q.minus)*dm
      if (fuzzy) {
        tb <- tau+dp-dm
        bfs[b] <- tb[2]
        if (adjusted) bfs[b] <- bfs[b]-sum(gamma[,2]*tb[-c(1,2)])
      }
    }
    uncorrected <- if (fuzzy) fit$zeta.hat else fit$tau.hat
    first <- if (!fuzzy) NA_real_ else if (adjusted) fit$tau.d.adj.hat else fit$tau.d.hat
    list(estimate=fit$estimate_irbc,uncorrected=uncorrected,bias=uncorrected-fit$estimate_irbc,
         se=fit$se_irbc,se_us=fit$se_us,first_stage=first,h=hs,hfit=hfit,
         Q=c(fit$Q.minus,fit$Q.plus),nh=c(sum(am!=0),sum(ap!=0)),
         ci=fit$ci_irbc,ci_boot=fit$ci_irbc_boot,probs=fit$boot.probs,weights=weights,
         components=tau,component_bias=B,gamma=gamma,cov_irbc=covariance("irbc"),cov_us=covariance("lp"),
         residuals=eps,boot_t=fit$boot.t,boot_components=bc,boot_first_stage=bfs,
         mhat=fit$boot.mhat,boot_success=fit$boot.success)
  }
  commands <- c("* Generated from R 2.0. Run via tests/run_tests.do, from the package folder.")
  report <- list()
  for (i in seq_along(cases)) {
    o <- cases[[i]]
    data <- datasets[[o$dataset]]
    W <- matrix(E$.irbcrd_wild_draws(nrow(data)*o$B,o$wild),nrow(data),o$B)
    expected <- get_reference(data,o,W)
    audited <- audit_compute(data,o,W)
    a <- flatten(audited)
    b <- flatten(expected)
    stopifnot(length(a)==length(b), identical(is.na(a),is.na(b)))
    err <- max(abs(a-b)/(1+abs(b)),na.rm=TRUE)
    if (!is.finite(err) || err>1e-8) {
      print(vapply(fields,function(nm) max(abs(as.numeric(audited[[nm]])-as.numeric(expected[[nm]])),0,na.rm=TRUE),numeric(1)))
      stop("Formula audit failed in case ",i,": ",format(err))
    }
    id <- sprintf("case_%03d",i)
    csv(as.data.frame(W),file.path(output,paste0(id,"_weights.csv")))
    labels <- unlist(Map(function(nm,v) if (length(v)) paste0(nm,"[",seq_along(v),"]") else character(0),
                         fields,expected[fields]),use.names=FALSE)
    csv(data.frame(field=labels,value=b),file.path(output,paste0(id,"_expected.csv")))
    opts <- c(paste0("h(",paste(o$h,collapse=" "),")"),paste0("c(",o$c,")"),paste0("p(",o$p,")"),
              paste0("kernel(",paste(o$kernel,collapse=" "),")"),paste0("residuals(",o$res,")"),
              paste0("qmethod(",o$q,")"),paste0("bwcheck(",o$bw,")"),paste0("level(",100*(1-o$alpha),")"),
              "bootstrap",paste0("reps(",o$B,")"),paste0("wild(",o$wild,")"),"drawmatrix(__irbc_test_W)","nodisplay")
    if (o$fast) opts <- c(opts,"fast")
    if (o$gloo) opts <- c(opts,"gloo")
    if (o$design %in% c("frd","cfrd")) opts <- c(opts,"fuzzy(d)",paste0("fuzzyweights(",o$fw,")"))
    if (o$design %in% c("crd","cfrd")) opts <- c(opts,"covs(z1 z2)")
    commands <- c(commands,
      sprintf('import delimited using "tests/fixtures/%s_weights.csv", varnames(1) asdouble clear',id),
      "mkmat _all, matrix(__irbc_test_W)",
      sprintf('import delimited using "tests/fixtures/%s.csv", varnames(1) asdouble clear',o$dataset),
      paste("irbcrd y x,",paste(opts,collapse=" ")),
      "assert e(estimate_irbc_boot) == e(estimate_irbc)",
      sprintf('import delimited using "tests/fixtures/%s_expected.csv", varnames(1) asdouble clear',id),
      sprintf('mata: irbc_test_compare(irbc_test_flat(irbc_last), st_data(.,"value"), "%s")',id))
    report[[i]] <- data.frame(case=id,design=o$design,dataset=o$dataset,res=o$res,q=o$q,
                             kernel=paste(o$kernel,collapse="/"),h=paste(o$h,collapse="/"),
                             wild=o$wild,fast=o$fast,gloo=o$gloo,fw=o$fw,alpha=o$alpha,
                             compared_values=length(b),max_scaled_error=err)
    cat(id,o$design,o$res,o$q,"max scaled error:",format(err,digits=3),"\n")
  }
  writeLines(commands,file.path(output,"cases.do"))
  report <- do.call(rbind,report)
  csv(report,file.path(output,"manifest.csv"))
  writeLines(c("Formula audit: PASS",paste("Cases:",nrow(report)),
               paste("Compared numeric values:",sum(report$compared_values)),
               paste("Maximum scaled error:",format(max(report$max_scaled_error),digits=8)),
               "This ran two R implementations. It did NOT compile or execute Stata/Mata.",
               "Run tests/run_tests.do in a licensed Stata installation to complete validation.",
               R.version.string,paste(basename(sources),tools::md5sum(sources))),
             file.path(here,"FORMULA_AUDIT.txt"))
}
main()
