version 16.0
mata:
real colvector irbc_test_flat(struct irbc_result scalar r)
{
    return((r.estimate \ r.uncorrected \ r.bias \ r.se \ r.se_us \ r.first_stage \
        vec(r.h) \ vec(r.hfit) \ vec(r.Q) \ vec(r.nh) \ vec(r.ci) \ vec(r.ci_boot) \
        vec(r.probs) \ vec(r.weights) \ vec(r.components) \ vec(r.component_bias) \
        vec(r.gamma) \ vec(r.cov_irbc) \ vec(r.cov_us) \ vec(r.residuals) \
        vec(r.boot_t) \ vec(r.boot_components) \ vec(r.boot_first_stage) \
        r.mhat \ r.boot_success))
}

void irbc_test_compare(real colvector actual, real colvector expected,
                       string scalar label)
{
    real colvector valid
    real scalar difference
    if (rows(actual)!=rows(expected)) irbc_fail(label+": result size differs from R.")
    if (sum((actual:>=.):!=(expected:>=.))) irbc_fail(label+": missing-value pattern differs from R.")
    valid = selectindex(expected:<.)
    difference = max(abs(actual[valid]-expected[valid]):/(1:+abs(expected[valid])))
    if (difference > 1e-7 | difference >= .) {
        errprintf("%s maximum scaled difference: %21.14g\n",label,difference)
        irbc_fail("Native Stata/R numerical agreement failed.")
    }
    printf("PASS %s: %g values, maximum scaled difference %10.3g\n",label,rows(actual),difference)
}
end
