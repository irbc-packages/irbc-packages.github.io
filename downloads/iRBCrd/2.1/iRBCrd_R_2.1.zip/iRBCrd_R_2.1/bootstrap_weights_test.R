# Independent bootstrap reconstruction and full-regression covariate refits.
local({
  env <- new.env(parent = globalenv())
  sys.source("iRBC_functions.R", env)
  sys.source("iRBCrd.R", env)
  checks <- 0L
  close <- function(actual, expected, tolerance = 2e-7) {
    stopifnot(length(actual) == length(expected), all(is.finite(actual)),
              all(is.finite(expected)))
    stopifnot(max(abs(as.numeric(actual) - as.numeric(expected))) <
                tolerance * max(1, max(abs(expected))))
    checks <<- checks + 1L
  }
  kernel <- function(u, k) switch(k, tri = pmax(1 - abs(u), 0),
    epa = .75 * pmax(1 - u^2, 0), uni = .5 * (abs(u) <= 1))
  wls <- function(x, center, h, p, k) {
    R <- outer((x - center) / h, 0:p, "^")
    w <- kernel((x - center) / h, k)
    map <- solve(crossprod(R, R * w), t(R * w))
    list(R = R, map = map, leverage = rowSums(R * t(map)))
  }
  side <- function(x, values, h, p, k, nu, res, q) {
    local <- which(abs(x) <= h)
    n <- length(x)
    cutoff <- wls(x, 0, h, p, k)
    a <- cutoff$map[nu + 1L, ] / h^nu
    S <- matrix(0, n, n)
    C <- numeric(n)
    for (i in local) {
      S[i, ] <- wls(x, x[i], h, p, k)$map[1L, ]
      C[i] <- sum(S[i, ] * ((x - x[i]) / h)^(p + 1L))
    }
    Q <- if (q == "sample") sum(a * (x / h)^(p + 1L)) / sum(a * C) else {
      # Population constants have separate quadrature tests in kink_test.R.
      if (nu == 1L) env$.irbcrd_kink_constants(k, p)$Q else env$.irbcrd_Q_fast(k, p)
    }
    means <- S %*% values
    eps <- matrix(0, n, ncol(values))
    if (res == "cct-hc3") {
      fit <- wls(x, 0, h, p + 1L, k)
      raw <- values - fit$R %*% fit$map %*% values
      eps[local, ] <- raw[local, , drop = FALSE] / (1 - fit$leverage[local])
    } else {
      eps[local, ] <- (values[local, , drop = FALSE] - means[local, , drop = FALSE]) /
        (1 - diag(S)[local])
    }
    list(a = a, Q = Q, local = local, means = means, eps = eps,
         raw = as.numeric(a %*% values))
  }
  set.seed(17041998)
  n <- 160L
  x <- sample(seq(-1.2, 1.2, length.out = n))
  Z <- cbind(z1 = .3 * x + rnorm(n), z2 = x^2 + rnorm(n))
  d <- 2 * (x >= 0) + 3 * pmax(x, 0) + .5 * Z[, 1] + rnorm(n, sd = .3)
  y <- 1 + x + x^2 + .7 * d + .6 * Z[, 1] - .3 * Z[, 2] + rnorm(n, sd = .4)
  im <- which(x < 0)
  ip <- which(x >= 0)
  B <- 11L
  seed <- 31415L
  designs <- list(fuzzy = list(fuzzy = d), adjusted = list(covs = Z),
                  adjusted_fuzzy = list(fuzzy = d, covs = Z))
  fits.checked <- 0L
  for (nu in 0:1) for (res in c("cct-hc3", "irbc-hc3")) {
    for (q in c("sample", "asymptotic")) for (wild in c("rademacher", "mammen", "normal")) {
      p <- nu + 1L
      h <- if (res == "cct-hc3") c(.73, .91) else c(.83, .83)
      kernels <- if (res == "cct-hc3") c("tri", "epa") else c("tri", "tri")
      for (design in designs) {
        fuzzy <- !is.null(design$fuzzy)
        adjusted <- !is.null(design$covs)
        values <- cbind(outcome = y)
        if (fuzzy) values <- cbind(values, treatment = d)
        if (adjusted) values <- cbind(values, Z)
        nz <- if (adjusted) ncol(Z) else 0L
        zi <- if (adjusted) seq.int(2L + as.integer(fuzzy), ncol(values)) else integer()
        left <- side(x[im], values[im, , drop = FALSE], h[1], p, kernels[1], nu, res, q)
        right <- side(x[ip], values[ip, , drop = FALSE], h[2], p, kernels[2], nu, res, q)
        active <- sort(c(im[left$local], ip[right$local]))
        means <- eps <- matrix(0, n, ncol(values))
        means[im, ] <- left$means
        means[ip, ] <- right$means
        eps[im, ] <- left$eps
        eps[ip, ] <- right$eps
        tau <- right$raw - left$raw
        # Full joint WLS, rather than the package's partialled-out equations.
        gamma_ref <- function(star, response) {
          R <- outer(x, 0:p, "^")
          A <- cbind(R * (x < 0), R * (x >= 0), star[, zi, drop = FALSE])
          w <- ifelse(x < 0, kernel(x / h[1], kernels[1]) / h[1],
                       kernel(x / h[2], kernels[2]) / h[2])
          tail(as.numeric(solve(crossprod(A, A * w), crossprod(A * w, star[, response]))), nz)
        }
        gy <- if (adjusted) gamma_ref(values, 1L) else numeric()
        gd <- if (adjusted && fuzzy) gamma_ref(values, 2L) else numeric()
        ty <- tau[1L] - if (adjusted) sum(gy * tau[zi]) else 0
        td <- if (fuzzy) tau[2L] - if (adjusted) sum(gd * tau[zi]) else 0 else NA_real_
        raw <- if (fuzzy) ty / td else ty
        baseline <- NULL
        for (fw in if (fuzzy) c("fixed", "bootstrap") else "fixed") {
          for (gw in if (adjusted) c("fixed", "bootstrap") else "fixed") {
            args <- c(list(y = y, x = x, h = h, kernel = kernels, deriv = nu,
              p = p, res = res, q.method = q, bwcheck = NULL, boot.ci = TRUE,
              boot.B = B, boot.seed = seed, boot.wild = wild, boot.keep = TRUE), design)
            if (fuzzy) args$fuzzy.boot.weights <- fw
            if (adjusted) args$gamma.boot.weights <- gw
            fit <- do.call(env$iRBCrd, args)
            expected <- numeric(B)
            expected.components <- matrix(0, B, ncol(values))
            expected.weights <- matrix(0, B, ncol(values))
            expected.gy <- expected.gd <- matrix(0, B, nz)
            expected.fw <- matrix(0, B, 2L)
            expected.first <- numeric(B)
            set.seed(seed)
            for (b in seq_len(B)) {
              # Draw order and Mammen's two-point probabilities match the API.
              e <- if (wild == "rademacher") sample(c(-1, 1), length(active), TRUE) else if (wild == "normal") {
                rnorm(length(active))
              } else {
                s <- sqrt(5)
                sample(c((1 - s) / 2, (1 + s) / 2), length(active), TRUE,
                       prob = c((s + 1) / (2 * s), (s - 1) / (2 * s)))
              }
              star <- values
              star[active, ] <- means[active, , drop = FALSE] + eps[active, , drop = FALSE] * e
              gp <- as.numeric(right$a %*% star[ip, , drop = FALSE])
              gm <- as.numeric(left$a %*% star[im, , drop = FALSE])
              ts <- gp - gm
              T <- right$Q * (gp - right$raw) - left$Q * (gm - left$raw)
              gys <- if (adjusted && gw == "bootstrap") gamma_ref(star, 1L) else gy
              gds <- if (adjusted && fuzzy && gw == "bootstrap") gamma_ref(star, 2L) else gd
              wy <- c(1, if (fuzzy) 0, if (adjusted) -gys)
              weights <- wy
              if (fuzzy) {
                wd <- c(0, 1, if (adjusted) -gds)
                td.star <- sum(wd * ts)
                denominator <- if (fw == "bootstrap") td.star else td
                weights <- wy / denominator - ty * wd / (td * denominator)
                expected.fw[b, ] <- c(1 / denominator, -ty / (td * denominator))
                expected.first[b] <- td.star
              }
              expected[b] <- sum(weights * T)
              expected.components[b, ] <- T
              expected.weights[b, ] <- weights
              if (adjusted) expected.gy[b, ] <- gys
              if (adjusted && fuzzy) expected.gd[b, ] <- gds
            }
            close(fit$boot.t, expected)
            if (adjusted || nu == 1L) close(fit$boot.t.components, expected.components)
            if (adjusted) {
              close(fit$boot.linear.weights, expected.weights)
              close(if (fuzzy) fit$boot.gamma.y else fit$boot.gamma, expected.gy)
              stopifnot(fit$gamma.boot.weights == gw)
              if (fuzzy) {
                close(fit$boot.gamma.d, expected.gd)
                close(fit$boot.fuzzy.weights, expected.fw)
                close(fit$boot.adjusted.first.stage, expected.first)
              }
              if (gw == "bootstrap") stopifnot(any(apply(expected.gy, 2L, sd) > 1e-5))
            }
            probs <- pnorm(fit$se_irbc / fit$se_us * qnorm(c(.025, .975)))
            close(fit$ci_irbc_boot, raw - rev(as.numeric(quantile(expected, probs, type = 7))))
            analytic <- fit[c("estimate_irbc", "se_irbc", "ci_irbc")]
            if (is.null(baseline)) baseline <- analytic else stopifnot(identical(analytic, baseline))
            # Keeping draws must not affect inference, and FALSE is the default.
            args$boot.keep <- NULL
            compact <- do.call(env$iRBCrd, args)
            draw.fields <- c("boot.t", "boot.t.components", "boot.linear.weights", "boot.fuzzy.weights",
                             "boot.gamma", "boot.gamma.y", "boot.gamma.d", "boot.adjusted.first.stage")
            stopifnot(!any(draw.fields %in% names(compact)),
                      identical(compact, fit[setdiff(names(fit), draw.fields)]))
            fits.checked <- fits.checked + 1L
          }
        }
      }
    }
  }
  # Singular common-slope bootstrap regressions return an omitted draw.
  singular <- cbind(y, Z[, 1L], Z[, 1L])
  stopifnot(is.null(env$.irbcrd_boot_covariate_slopes(
    singular, 1L, 2:3, x, 0, .9, .7, 1, "tri", "tri")))
  original <- env$.irbcrd_boot_covariate_slopes
  for (is_kink in c(FALSE, TRUE)) for (is_fuzzy in c(FALSE, TRUE)) {
    args <- list(y = y, x = x, h = c(.73, .91), covs = Z, deriv = as.integer(is_kink),
      gamma.boot.weights = "bootstrap", boot.ci = TRUE, boot.B = B,
      boot.seed = seed, boot.keep = TRUE)
    if (is_fuzzy) {
      args$fuzzy <- d
      args$fuzzy.boot.weights <- "bootstrap"
    }
    full <- do.call(env$iRBCrd, args)
    calls <- 0L
    env$.irbcrd_boot_covariate_slopes <- function(...) {
      calls <<- calls + 1L
      if (calls == 1L) NULL else original(...)
    }
    partial <- do.call(env$iRBCrd, args)
    env$.irbcrd_boot_covariate_slopes <- original
    stopifnot(is.na(partial$boot.t[1L]), identical(partial$boot.t[-1L], full$boot.t[-1L]))
    raw <- if (is_fuzzy) partial$zeta.hat else partial$tau.hat
    probs <- pnorm(partial$se_irbc / partial$se_us * qnorm(c(.025, .975)))
    close(partial$ci_irbc_boot, raw - rev(as.numeric(quantile(partial$boot.t[-1L], probs))))
  }
  cat("PASS:", fits.checked, "bootstrap weighting configurations and default draw omission.\n")
  cat("PASS:", checks, "independent regression-refit, statistic, weight, and interval comparisons.\n")
  cat("PASS: singular covariate refits omit the affected draw without aborting valid draws.\n")
})
