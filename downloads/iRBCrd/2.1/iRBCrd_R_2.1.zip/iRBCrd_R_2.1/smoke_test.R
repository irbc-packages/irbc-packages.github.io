# Run from the extracted release folder with source() or Rscript.
local({
  env <- new.env(parent = globalenv())
  attached <- search()
  sys.source("iRBC_functions.R", envir = env)
  sys.source("iRBCrd.R", envir = env)
  stopifnot(identical(attached, search()))
  set.seed(17041998)
  n <- 180
  x <- sort(runif(n, -1, 1))
  Z <- cbind(z = .3 * x + rnorm(n))
  d <- 1.5 * (x >= 0) + .4 * x + .2 * Z[, 1] + rnorm(n, sd = .3)
  y <- 1 + .8 * d + x + x^2 + .5 * Z[, 1] + rnorm(n)
  designs <- list(sharp = list(), fuzzy = list(fuzzy = d),
    adjusted_sharp = list(covs = Z), adjusted_fuzzy = list(fuzzy = d, covs = Z))
  expect_error <- function(expr, pattern) {
    caught <- tryCatch({ force(expr); NULL }, error = identity)
    stopifnot(inherits(caught, "error"),
              grepl(pattern, conditionMessage(caught), fixed = TRUE))
  }
  checks <- 0L
  for (design in names(designs)) for (q in c("sample", "asymptotic")) {
    for (res in c("irbc-hc3", "cct-hc3")) {
      args <- c(list(y = y, x = x, h = c(.65, .75), q.method = q,
                     res = res, boot.ci = TRUE, boot.B = 11L,
                     boot.wild = "rademacher", boot.seed = 17041998L),
                designs[[design]])
      fit <- do.call(env$iRBCrd, args)
      stopifnot(identical(fit$estimate_irbc_boot, fit$estimate_irbc),
        identical(fit$res, res),
        all(is.finite(c(fit$estimate_irbc, fit$se_irbc, fit$ci_irbc_boot))),
        fit$ci_irbc[1] < fit$ci_irbc[2], fit$ci_irbc_boot[1] <= fit$ci_irbc_boot[2],
        fit$boot.success == 11L)
      expect_error(do.call(env$iRBCrd, c(args, list(boot.impl = "direct"))), "unused argument")
      checks <- checks + 1L
    }
  }
  for (k in 0:3) {
    stopifnot(identical(env$.irbcrd_normalize_res(paste0("hc", k)), paste0("irbc-hc", k)),
              identical(env$.irbcrd_normalize_res(paste0("irbc-hc", k)), paste0("irbc-hc", k)),
              identical(env$.irbcrd_normalize_res(paste0("rbc-hc", k)), paste0("cct-hc", k)))
  }
  expect_error(env$iRBCrd(y, x, h = .65, res = "unknown"), "Residuals incorrectly specified")
  cat("PASS:", checks, "four-design interface/bootstrap checks.\n")
  cat("PASS: residual options and unsupported arguments checked.\n")
  cat("PASS: sourcing did not attach any additional R packages.\n")
})
