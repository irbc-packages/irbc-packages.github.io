# Independent matrix-formula checks; run from this release directory.
local({
  env <- new.env(parent = globalenv())
  sys.source("iRBC_functions.R", env)
  sys.source("iRBCrd.R", env)
  checks <- 0L
  close <- function(actual, expected, tolerance = 2e-8) {
    stopifnot(length(actual) == length(expected),
              all(is.finite(actual)), all(is.finite(expected)))
    error <- max(abs(as.numeric(actual) - as.numeric(expected)))
    if (error > tolerance * max(1, max(abs(expected)))) {
      stop("Independent check failed: maximum discrepancy = ", format(error, digits = 12))
    }
    checks <<- checks + 1L
  }
  expect_error <- function(expr, pattern) {
    caught <- tryCatch({ force(expr); NULL }, error = identity)
    stopifnot(inherits(caught, "error"), grepl(pattern, conditionMessage(caught), fixed = TRUE))
    checks <<- checks + 1L
  }
  kernel <- function(u, k) switch(k,
    tri = pmax(1 - abs(u), 0), epa = .75 * pmax(1 - u^2, 0),
    uni = .5 * (abs(u) <= 1))
  wls <- function(x, center, h, p, k, bwcheck = NULL) {
    if (!is.null(bwcheck)) h <- max(h, sort(abs(x - center))[min(bwcheck, length(x))])
    u <- (x - center) / h
    R <- outer(u, 0:p, "^")
    w <- kernel(u, k)
    map <- solve(crossprod(R, R * w), t(R * w))
    list(map = map, R = R, w = w, h = h,
         leverage = rowSums(R * t(map)))
  }
  side_reference <- function(x, values, h, p, k, res, bwcheck = NULL) {
    cutoff <- wls(x, 0, h, p, k, bwcheck = bwcheck)
    h <- cutoff$h
    n <- length(x)
    S <- matrix(0, n, n)
    C.i <- numeric(n)
    for (j in which(cutoff$w > 0)) {
      fit <- wls(x, x[j], h, p, k, bwcheck)
      S[j, ] <- fit$map[1L, ]
      C.i[j] <- sum(S[j, ] * ((x - x[j]) / h)^(p + 1L))
    }
    a <- cutoff$map[2L, ] / h
    bias <- as.numeric(a %*% S) - a
    Q <- sum(a * (x / h)^(p + 1L)) / sum(a * C.i)
    # Reproduction gives the same finite C_kLP via either expression.
    close(sum(a * C.i), sum(bias * (x / h)^(p + 1L)))
    corrected <- a - Q * bias
    active <- which(a != 0 | corrected != 0)
    eps <- matrix(0, n, ncol(values))
    hc <- sub("^(cct|irbc)-", "", res)
    if (startsWith(res, "cct-")) {
      fit <- wls(x, 0, h, p + 1L, k)
      raw <- values - fit$R %*% fit$map %*% values
      adj <- switch(hc, hc0 = 1, hc1 = sqrt((sum(fit$w > 0) - p - 2) / sum(fit$w > 0)),
                    hc2 = sqrt(1 - fit$leverage), hc3 = 1 - fit$leverage)
      residual <- raw / adj
      eps[active, ] <- residual[active, , drop = FALSE]
    } else for (j in active) {
      fit <- wls(x, x[j], h, p, k, bwcheck)
      raw <- values[j, ] - fit$map[1L, ] %*% values
      adj <- switch(hc, loo = 1, hc0 = 1,
        hc1 = sqrt((sum(fit$w > 0) - p - 1) / sum(fit$w > 0)),
        hc2 = sqrt(1 - fit$leverage[j]), hc3 = 1 - fit$leverage[j])
      eps[j, ] <- raw / adj
    }
    list(raw = as.numeric(a %*% values), bias = as.numeric(Q * bias %*% values),
         a = a, S = S, corrected = corrected, Q = Q, eps = eps,
         cov = crossprod(eps * corrected), cov.us = crossprod(eps * (Q * a)),
         active = which(cutoff$w > 0))
  }
  set.seed(17041998)
  n <- 180L
  x <- sample(seq(-1.5, 1.5, length.out = n))
  Z <- cbind(z1 = .3 * x + rnorm(n), z2 = x^2 + rnorm(n))
  d <- .2 * x + 2 * pmax(x, 0) + .2 * Z[, 1] + rnorm(n, sd = .1)
  y <- 1 + x + .8 * d + .3 * Z[, 1] - .1 * Z[, 2] + x^3 / 3 + rnorm(n, sd = .2)
  V <- cbind(outcome = y, treatment = d, Z)
  ip <- which(x >= 0)
  im <- which(x < 0)
  designs <- list(sharp = list(), fuzzy = list(fuzzy = d),
    adjusted_sharp = list(covs = Z), adjusted_fuzzy = list(fuzzy = d, covs = Z))
  h <- c(.72, .95)
  residuals <- c(paste0("cct-hc", 0:3), paste0("irbc-hc", 0:3))
  for (p in 1:3) for (k in c("tri", "epa", "uni")) for (res in residuals) {
    fit <- env$iRBCrd(y, x, h, p = p, kersel = k, res = res,
                      deriv = 1, bwcheck = NULL)
    left <- side_reference(x[im], matrix(y[im]), h[1], p, k, res)
    right <- side_reference(x[ip], matrix(y[ip]), h[2], p, k, res)
    close(c(fit$Q.minus, fit$Q.plus), c(left$Q, right$Q))
    close(fit$tau.hat, right$raw - left$raw)
    close(fit$estimate_irbc, right$raw - left$raw - right$bias + left$bias)
    close(fit$se_irbc^2, left$cov + right$cov)
    close(fit$se_us^2, left$cov.us + right$cov.us)
    close(fit$epshat.minus, left$eps)
    close(fit$epshat.plus, right$eps)
    for (s in list(list(x = x[im], ref = left), list(x = x[ip], ref = right))) {
      moments <- as.numeric(crossprod(s$ref$corrected, outer(s$x, 0:(p + 1L), "^")))
      close(moments, c(0, 1, rep(0, p)))
    }
  }
  cat("PASS: p=1:3, three kernels, and all eight HC residual specifications.\n")

  # Full joint WLS independently verifies gamma, including unequal bandwidths.
  gamma_ref <- function(response) {
    R <- outer(x, 0:2, "^")
    A <- cbind(R * (x < 0), R * (x >= 0), Z)
    w <- ifelse(x < 0, kernel(x / h[1], "tri") / h[1], kernel(x / h[2], "tri") / h[2])
    tail(as.numeric(solve(crossprod(A, A * w), crossprod(A * w, response))), ncol(Z))
  }
  gy <- gamma_ref(y)
  gd <- gamma_ref(d)
  for (design in names(designs)) {
    args <- c(list(y = y, x = x, h = h, deriv = 1, p = 2, bwcheck = NULL,
                   res = "cct-hc3", boot.ci = TRUE, boot.B = 19,
                   boot.seed = 17041998), designs[[design]])
    fit <- do.call(env$iRBCrd, args)
    columns <- c(1L, if (grepl("fuzzy", design)) 2L,
                 if (grepl("adjusted", design)) 3:4)
    values <- V[, columns, drop = FALSE]
    left <- side_reference(x[im], values[im, , drop = FALSE], h[1], 2, "tri", "cct-hc3")
    right <- side_reference(x[ip], values[ip, , drop = FALSE], h[2], 2, "tri", "cct-hc3")
    close(fit$cov.irbc, left$cov + right$cov)
    close(fit$cov.us, left$cov.us + right$cov.us)
    tau <- right$raw - left$raw
    bias <- right$bias - left$bias
    wy <- c(1, if (grepl("fuzzy", design)) 0, if (grepl("adjusted", design)) -gy)
    if (grepl("fuzzy", design)) {
      wd <- c(0, 1, if (grepl("adjusted", design)) -gd)
      ty <- sum(wy * tau)
      td <- sum(wd * tau)
      ww <- wy / td - ty * wd / td^2
      raw <- ty / td
    } else {
      ww <- wy
      raw <- sum(wy * tau)
    }
    close(fit$linear.weights, ww)
    close(fit$estimate_irbc, raw - sum(ww * bias))
    close(fit$se_irbc^2, as.numeric(t(ww) %*% (left$cov + right$cov) %*% ww))
    if (grepl("adjusted", design)) {
      close(if (grepl("fuzzy", design)) fit$gamma.y.hat else fit$gamma.hat, gy)
      if (grepl("fuzzy", design)) close(fit$gamma.d.hat, gd)
    }
    local <- sort(c(im[left$active], ip[right$active]))
    means <- eps <- matrix(0, n, ncol(values))
    means[im, ] <- left$S %*% values[im, , drop = FALSE]
    means[ip, ] <- right$S %*% values[ip, , drop = FALSE]
    eps[im, ] <- left$eps
    eps[ip, ] <- right$eps
    set.seed(17041998)
    expected <- matrix(0, 19, ncol(values))
    for (b in 1:19) {
      star <- values
      star[local, ] <- means[local, , drop = FALSE] +
        eps[local, , drop = FALSE] * sample(c(-1, 1), length(local), replace = TRUE)
      # Brute-force refits at the cutoff on each bootstrap sample.
      gp <- wls(x[ip], 0, h[2], 2, "tri")$map[2, ] %*% star[ip, , drop = FALSE] / h[2]
      gm <- wls(x[im], 0, h[1], 2, "tri")$map[2, ] %*% star[im, , drop = FALSE] / h[1]
      expected[b, ] <- right$Q * (gp - right$raw) - left$Q * (gm - left$raw)
    }
    close(fit$boot.t.components, expected)
    close(fit$boot.t, expected %*% ww)
    probs <- pnorm(fit$se_irbc / fit$se_us * qnorm(c(.025, .975)))
    close(fit$ci_irbc_boot, raw - rev(as.numeric(quantile(fit$boot.t, probs, type = 7))))
    stopifnot(identical(fit$estimate_irbc, fit$estimate_irbc_boot))
    if (requireNamespace("rdrobust", quietly = TRUE)) {
      comparison <- do.call(rdrobust::rdrobust, c(list(y = y, x = x, h = h, b = h,
        deriv = 1, p = 2, q = 3, kernel = "triangular", vce = "hc3"), designs[[design]]))
      close(raw, comparison$Estimate[1, 1])
    }
  }
  cat("PASS: four-design joint covariance, covariate adjustment, and brute-force bootstrap refits.\n")

  for (p in 1:5) for (k in c("tri", "epa", "uni")) {
    c48 <- env$.irbcrd_kink_constants(k, p, nquad = 48)
    c96 <- env$.irbcrd_kink_constants(k, p, nquad = 96)
    close(c48$Q, c96$Q, 2e-6)
    grid <- (1:500 - .5) * 2 / 500
    finite <- env$.irbcrd_kink_side(matrix(sin(grid)), grid, 0, 1, p, k,
                                   "cct-hc0", "sample", NULL, FALSE)
    close(finite$Q, c96$Q, if (k == "uni") .03 else .002)
  }
  for (k in c("tri", "epa", "uni")) {
    expected <- c(tri = .562381509321, epa = .559439135670, uni = .565623346311)[k]
    close(env$.irbcrd_kink_constants(k, 1, length.ratio = TRUE)$length.ratio, expected)
  }
  cat("PASS: asymptotic Q quadrature, finite-design convergence, and paper length ratios.\n")

  # Regularized fits retain exactly the same bias map in the bootstrap DGP.
  for (res in c("loo", "cct-hc3", "irbc-hc3")) {
    fit <- env$iRBCrd(y, x, .1, deriv = 1, res = res,
                      bwcheck = 30, boot.ci = TRUE, boot.B = 19, boot.seed = 1)
    left <- side_reference(x[im], matrix(y[im]), .1, 2, "tri", res, 30)
    right <- side_reference(x[ip], matrix(y[ip]), .1, 2, "tri", res, 30)
    close(fit$estimate_irbc, right$raw - left$raw - right$bias + left$bias)
    close(fit$se_irbc^2, left$cov + right$cov)
    stopifnot(fit$h.minus >= .1, fit$h.plus >= .1, fit$boot.success == 19)
  }
  base <- env$iRBCrd(y, x, h, deriv = 1, bwcheck = NULL,
                     boot.ci = TRUE, boot.B = 19, boot.seed = 17041998)
  scaled <- env$iRBCrd(y, 3 * x + 2, 3 * h, c = 2, deriv = 1, bwcheck = NULL,
                       boot.ci = TRUE, boot.B = 19, boot.seed = 17041998)
  close(scaled$estimate_irbc, base$estimate_irbc / 3)
  close(scaled$se_irbc, base$se_irbc / 3)
  close(scaled$ci_irbc_boot, base$ci_irbc_boot / 3)
  level <- env$iRBCrd(y + 17 + 3 * x, x, h, deriv = 1, bwcheck = NULL)
  close(level$estimate_irbc, base$estimate_irbc)
  close(level$se_irbc, base$se_irbc)
  for (wild in c("rademacher", "mammen", "normal")) {
    for (design in designs) {
      fit <- do.call(env$iRBCrd, c(list(y = y, x = x, h = h, deriv = 1,
        kersel = c("tri", "epa"), q.method = "asymptotic",
        boot.ci = TRUE, boot.B = 19, boot.wild = wild, boot.seed = 1, boot.keep = FALSE), design))
      stopifnot(fit$p == 2L, fit$boot.success == 19L, is.null(fit$boot.t))
    }
  }
  star <- env$iRBCrd(y, x, h, fuzzy = d, deriv = 1, fuzzy.boot.weights = "bootstrap",
                     boot.ci = TRUE, boot.B = 19, boot.seed = 1)
  expected <- (star$boot.t.components[, 1] -
    star$tau.y.hat * star$boot.t.components[, 2] / star$tau.d.hat) /
      star$boot.adjusted.first.stage
  close(star$boot.t, expected)
  for (p in 1:2) {
    fast <- env$iRBCrd(y, x, h, p = p, deriv = 1, fast = TRUE, res = "cct-hc3", bwcheck = NULL)
    v <- 0
    for (indices in list(im, ip)) {
      hh <- if (identical(indices, im)) h[1] else h[2]
      residual <- if (identical(indices, im)) fast$epshat.minus else fast$epshat.plus
      a <- wls(x[indices], 0, hh, p + 1L, "tri")$map[2, ] / hh
      v <- v + sum((a * residual)^2) *
        env$.irbcrd_kink_constants("tri", p, length.ratio = TRUE)$length.ratio^2
    }
    close(fast$se_irbc^2, v)
  }
  expect_error(env$iRBCrd(y, x, h, deriv = 2), "'deriv'")
  expect_error(env$iRBCrd(y, x, h, deriv = 1, p = 0), "'p'")
  expect_error(env$iRBCrd(y, x, h, deriv = 1, fuzzy = rep(0, n)), "first-stage slope")
  expect_error(env$iRBCrd(y, x, h, deriv = 1, fast = TRUE, q.method = "sample"), "cannot be combined")
  expect_error(env$iRBCrd(y, x, h, deriv = 1, fuzzy = d, covs = Z,
                         fuzzy.boot.weights = "bootstrap"), "fixed fuzzy weights")
  expect_error(env$iRBCrd(y, x, .001, deriv = 1, bwcheck = NULL), "too few")
  cat("PASS: regularization, units, bootstrap options, fast SEs, and input checks.\n")
  if (requireNamespace("rdrobust", quietly = TRUE)) {
    for (rule in c("mserd", "msetwo", "cerrd", "certwo")) for (design in designs) {
      bw <- do.call(rdrobust::rdbwselect, c(list(y = y, x = x, deriv = 1,
        p = 2, q = 3, vce = "hc3", kernel = "triangular", bwselect = rule), design))
      hh <- as.numeric(bw$bws[1, 1:2])
      a <- do.call(env$iRBCrd, c(list(y = y, x = x, h = hh, deriv = 1,
        p = 2, res = "cct-hc3", bwcheck = NULL), design))
      b <- do.call(rdrobust::rdrobust, c(list(y = y, x = x, h = hh, b = hh,
        deriv = 1, p = 2, q = 3, vce = "hc3", kernel = "triangular"), design))
      close(c(a$h.minus, a$h.plus), hh)
      close(if (is.null(a$zeta.hat)) a$tau.hat else a$zeta.hat, b$Estimate[1, 1])
    }
    cat("PASS: all four kink designs at estimated mserd, msetwo, cerrd, and certwo bandwidths.\n")
  }
  cat("PASS:", checks, "numerical/error assertions in kink_test.R.\n")
})
