# Public result schema for all designs, including nested component results.
local({
  env <- new.env(parent = globalenv())
  sys.source("iRBC_functions.R", env)
  sys.source("iRBCrd.R", env)
  omitted <- c("Q.minus", "Q.plus", "q.method", "boot.success", "boot.mhat",
               "boot.probs", "h.requested", "kersel", "kersel.minus", "kersel.plus",
               "kink", "alpha")
  assert_result <- function(fit, requested, level = 95) {
    stopifnot(!any(omitted %in% names(fit)))
    stopifnot(fit$deriv %in% 0:1, identical(fit$level, level))
    if ("h" %in% names(fit)) {
      stopifnot(is.list(fit$h), setequal(names(fit$h), c("minus", "plus")),
                identical(as.numeric(unlist(fit$h[c("minus", "plus")])), requested))
    }
    for (name in intersect(names(fit), c("sharp.outcome", "sharp.treatment"))) {
      assert_result(fit[[name]], requested, level)
    }
    for (name in intersect(names(fit), c("sharp.covariates", "sharp.components"))) {
      for (component in fit[[name]]) assert_result(component, requested, level)
    }
  }
  set.seed(17041998)
  n <- 160L
  x <- sort(runif(n, -1, 1))
  Z <- cbind(z1 = .2 * x + rnorm(n), z2 = x^2 + rnorm(n))
  d <- 2 * (x >= 0) + 2 * pmax(x, 0) + .3 * Z[, 1] + rnorm(n, sd = .1)
  y <- x + x^2 + .8 * d + .5 * Z[, 1] + rnorm(n, sd = .2)
  designs <- list(list(), list(fuzzy = d), list(covs = Z), list(fuzzy = d, covs = Z))
  expected_formals <- alist(y = , x = , h = , c = NULL, p = NULL, kernel = NULL,
    fuzzy = NULL, deriv = NULL, covs = NULL, res = NULL, level = 95,
    bwcheck = .bwcheck_default, fast = NULL, boot.ci = NULL, boot.B = NULL,
    boot.seed = NULL, boot.wild = NULL, boot.keep = NULL, q.method = NULL,
    fuzzy.boot.weights = NULL, gamma.boot.weights = NULL)
  stopifnot(identical(formals(env$iRBCrd), as.pairlist(expected_formals)))
  expect_error <- function(args, pattern) {
    caught <- tryCatch(do.call(env$iRBCrd, c(list(y = y, x = x, h = .7), args)),
                       error = identity)
    stopifnot(inherits(caught, "error"),
              grepl(pattern, conditionMessage(caught), fixed = TRUE))
  }
  for (name in c("h.plus", "h.minus", "kersel", "kersel.plus", "kersel.minus",
                 "kernel.plus", "kernel.minus", "kink", "alpha")) {
    expect_error(setNames(list(NULL), name), "unused argument")
  }
  for (value in list(-1, 2, .5, Inf, NA, NA_real_, numeric(), c(0, 1), "1", TRUE, FALSE)) {
    expect_error(list(deriv = value), "'deriv'")
  }
  expect_error(list(d = d), "'deriv'")
  for (design in designs) {
    base <- c(list(y = y, x = x, h = .7), design)
    stopifnot(identical(do.call(env$iRBCrd, base),
                       do.call(env$iRBCrd, c(base, list(deriv = 0)))),
              identical(do.call(env$iRBCrd, base),
                       do.call(env$iRBCrd, c(base, list(deriv = NULL)))))
    for (is_kink in c(FALSE, TRUE)) {
      args <- c(list(y = y, x = x, h = c(.6, .8), kernel = c("tri", "epa"),
        deriv = as.integer(is_kink), boot.ci = TRUE, boot.B = 7L, boot.seed = 17041998), design)
      fit <- do.call(env$iRBCrd, args)
      draw.fields <- c("boot.t", "boot.t.components", "boot.linear.weights", "boot.fuzzy.weights",
                       "boot.gamma", "boot.gamma.y", "boot.gamma.d", "boot.adjusted.first.stage")
      stopifnot(!any(draw.fields %in% names(fit)),
                identical(fit, do.call(env$iRBCrd, c(args, list(boot.keep = FALSE)))))
      reordered <- args
      reordered$h <- c(right = .8, left = .6)
      reordered$kernel <- c(plus = "epanechnikov", minus = "triangular")
      stopifnot(identical(fit, do.call(env$iRBCrd, reordered)),
                identical(fit$kernel.minus, "tri"), identical(fit$kernel.plus, "epa"))
      stopifnot(identical(fit$deriv, as.integer(is_kink)), fit$p == 1L + is_kink)
      # Exercise the entire documented positional argument order.
      positional <- lapply(expected_formals, function(value) NULL)
      for (name in names(args)) positional[[name]] <- args[[name]]
      positional$bwcheck <- env$.bwcheck_default
      positional$level <- 95
      stopifnot(identical(fit, do.call(env$iRBCrd, unname(positional))))
    }
  }
  for (design in designs) for (nu in 0:1) {
    args <- c(list(y = y, x = x, h = .7, deriv = nu, boot.ci = TRUE,
      boot.B = 19L, boot.seed = 17041998, boot.keep = TRUE), design)
    previous <- NULL
    for (level in c(90, 95, 99)) {
      fit <- do.call(env$iRBCrd, c(args, list(level = level)))
      stopifnot(identical(fit$level, level), identical(fit$deriv, nu),
                isTRUE(all.equal(fit$ci_irbc, fit$estimate_irbc +
                  qnorm(c((100 - level) / 200, (100 + level) / 200)) * fit$se_irbc)))
      if (!is.null(previous)) {
        stopifnot(identical(fit$estimate_irbc, previous$estimate_irbc),
                  identical(fit$se_irbc, previous$se_irbc), identical(fit$boot.t, previous$boot.t),
                  fit$ci_irbc[1] <= previous$ci_irbc[1], fit$ci_irbc[2] >= previous$ci_irbc[2],
                  fit$ci_irbc_boot[1] <= previous$ci_irbc_boot[1],
                  fit$ci_irbc_boot[2] >= previous$ci_irbc_boot[2])
      }
      previous <- fit
    }
    for (bad in list(NULL, NA, NaN, Inf, -1, 0, 100, 101, TRUE, "95", numeric(), c(90, 95))) {
      expect_error(c(design, list(deriv = nu, level = bad)), "'level'")
    }
  }
  bandwidths <- list(
    list(args = list(h = .7), requested = c(.7, .7)),
    list(args = list(h = c(right = .85, left = .65)), requested = c(.65, .85)),
    list(args = list(h = c(.6, .8)), requested = c(.6, .8)),
    list(args = list(h = c(.02, .02)), requested = c(.02, .02)))
  for (bad in list(NA, "unknown", c("fixed", "bootstrap"), character(), 1)) {
    expect_error(list(fuzzy = d, fuzzy.boot.weights = bad), "'fuzzy.boot.weights'")
    expect_error(list(covs = Z, gamma.boot.weights = bad), "'gamma.boot.weights'")
  }
  expect_error(list(gamma.boot.weights = "bootstrap"), "supply 'covs'")
  expect_error(list(fuzzy.boot.weights = "bootstrap"), "supply 'fuzzy'")
  for (design in designs) for (is_kink in c(FALSE, TRUE)) {
    for (bad in list(NA, 0, logical(), c(TRUE, FALSE))) {
      expect_error(c(design, list(deriv = as.integer(is_kink), boot.keep = bad)), "'boot.keep'")
    }
  }
  count <- 0L
  for (nu in 0:1) for (design in designs) for (boot in c(FALSE, TRUE)) {
    for (bw in bandwidths) {
      count <- count + 1L
      keep <- count %% 2L == 0L
      args <- c(list(y = y, x = x, deriv = nu, res = "cct-hc3",
        q.method = if (count %% 3L == 0L) "asymptotic" else "sample",
        boot.ci = boot, boot.B = 7L, boot.keep = keep, boot.seed = 17041998),
        bw$args, design)
      fit <- do.call(env$iRBCrd, args)
      assert_result(fit, bw$requested)
      assert_result(unserialize(serialize(fit, NULL)), bw$requested)
      stopifnot("h" %in% names(fit), all(is.finite(c(fit$estimate_irbc, fit$se_irbc))))
      if (bw$requested[1L] == .02) {
        stopifnot(fit$h.minus > .02, fit$h.plus > .02)
      }
      if (boot) {
        stopifnot(identical(fit$boot.B, 7L), identical(fit$boot.wild, "rademacher"),
                  all(is.finite(fit$ci_irbc_boot)))
        if (keep) stopifnot(length(fit$boot.t) == 7L, all(is.finite(fit$boot.t))) else {
          stopifnot(!"boot.t" %in% names(fit))
        }
      }
    }
  }
  for (method in c("iRBCfrd", "iRBCcrd", "iRBCcfrd")) for (level in c(90, 95, 99)) {
    args <- list(y = y, x = x, h = .7, boot.ci = TRUE, boot.B = 7L,
                 boot.seed = 17041998, level = level)
    unified <- args
    if (method %in% c("iRBCfrd", "iRBCcfrd")) args$d <- unified$fuzzy <- d
    if (method %in% c("iRBCcrd", "iRBCcfrd")) args$covs <- unified$covs <- Z
    fit <- do.call(env[[method]], args)
    stopifnot(identical(fit, do.call(env$iRBCrd, unified)))
    assert_result(fit, c(.7, .7), level)
    invalid <- tryCatch(do.call(env[[method]], c(args, list(alpha = .05))), error = identity)
    stopifnot(inherits(invalid, "error"), grepl("unused argument", conditionMessage(invalid), fixed = TRUE))
  }
  # Covariate names must survive even when they match a removed result field.
  colnames(Z) <- c("Q.plus", "boot.probs")
  for (nu in 0:1) {
    fit <- env$iRBCrd(y, x, h = .7, deriv = nu, fuzzy = d, covs = Z)
    assert_result(fit, c(.7, .7))
    stopifnot(identical(names(fit$sharp.covariates), colnames(Z)))
  }
  cat("PASS:", count, "public output configurations, including serialized and nested results.\n")
  cat("PASS: direct design functions, covariate names, and requested/effective bandwidth distinctions.\n")
  cat("PASS: exact argument order, deriv restricted to 0/1, and removed-argument rejection.\n")
  cat("PASS: 90/95/99% analytic/bootstrap intervals and level validation in all eight designs.\n")
  cat("PASS: default draw omission and bootstrap option validation in all eight designs.\n")
})
