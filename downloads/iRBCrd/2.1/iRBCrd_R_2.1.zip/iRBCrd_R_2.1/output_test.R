# Public result schema for all designs, including nested component results.
local({
  env <- new.env(parent = globalenv())
  sys.source("iRBC_functions.R", env)
  sys.source("iRBCrd.R", env)
  omitted <- c("Q.minus", "Q.plus", "q.method", "boot.success", "boot.mhat",
               "boot.probs", "h.requested")
  assert_result <- function(fit, requested) {
    stopifnot(!any(omitted %in% names(fit)))
    if ("h" %in% names(fit)) {
      stopifnot(is.list(fit$h), setequal(names(fit$h), c("minus", "plus")),
                identical(as.numeric(unlist(fit$h[c("minus", "plus")])), requested))
    }
    for (name in intersect(names(fit), c("sharp.outcome", "sharp.treatment"))) {
      assert_result(fit[[name]], requested)
    }
    for (name in intersect(names(fit), c("sharp.covariates", "sharp.components"))) {
      for (component in fit[[name]]) assert_result(component, requested)
    }
  }
  set.seed(17041998)
  n <- 160L
  x <- sort(runif(n, -1, 1))
  Z <- cbind(z1 = .2 * x + rnorm(n), z2 = x^2 + rnorm(n))
  d <- 2 * (x >= 0) + 2 * pmax(x, 0) + .3 * Z[, 1] + rnorm(n, sd = .1)
  y <- x + x^2 + .8 * d + .5 * Z[, 1] + rnorm(n, sd = .2)
  designs <- list(list(), list(fuzzy = d), list(covs = Z), list(fuzzy = d, covs = Z))
  bandwidths <- list(
    list(args = list(h = .7), requested = c(.7, .7)),
    list(args = list(h = c(right = .85, left = .65)), requested = c(.65, .85)),
    list(args = list(h = .7, h.minus = .6, h.plus = .8), requested = c(.6, .8)),
    list(args = list(h = c(.02, .02)), requested = c(.02, .02)))
  count <- 0L
  for (nu in 0:1) for (design in designs) for (boot in c(FALSE, TRUE)) {
    for (bw in bandwidths) {
      count <- count + 1L
      keep <- count %% 2L == 0L
      args <- c(list(y = y, x = x, deriv = nu, res = "cct-hc3",
        q.method = if (count %% 3L == 0L) "asymptotic" else "sample",
        boot.ci = boot, boot.B = 7L, boot.keep = keep, boot.seed = 17041998),
        bw$args, design)
      fit <- do.call(env$iRBCrd, args)
      assert_result(fit, bw$requested)
      assert_result(unserialize(serialize(fit, NULL)), bw$requested)
      stopifnot("h" %in% names(fit), all(is.finite(c(fit$estimate_irbc, fit$se_irbc))))
      if (bw$requested[1L] == .02) {
        stopifnot(fit$h.minus > .02, fit$h.plus > .02)
      }
      if (boot) {
        stopifnot(identical(fit$boot.B, 7L), identical(fit$boot.wild, "rademacher"),
                  all(is.finite(fit$ci_irbc_boot)))
        if (keep) stopifnot(length(fit$boot.t) == 7L, all(is.finite(fit$boot.t))) else {
          stopifnot(!"boot.t" %in% names(fit))
        }
      }
    }
  }
  for (method in c("iRBCfrd", "iRBCcrd", "iRBCcfrd")) {
    args <- list(y = y, x = x, h = .7, boot.ci = TRUE, boot.B = 7L,
                 boot.seed = 17041998)
    unified <- args
    if (method %in% c("iRBCfrd", "iRBCcfrd")) args$d <- unified$fuzzy <- d
    if (method %in% c("iRBCcrd", "iRBCcfrd")) args$covs <- unified$covs <- Z
    fit <- do.call(env[[method]], args)
    stopifnot(identical(fit, do.call(env$iRBCrd, unified)))
    assert_result(fit, c(.7, .7))
  }
  # Covariate names must survive even when they match a removed result field.
  colnames(Z) <- c("Q.plus", "boot.probs")
  for (nu in 0:1) {
    fit <- env$iRBCrd(y, x, h = .7, deriv = nu, fuzzy = d, covs = Z)
    assert_result(fit, c(.7, .7))
    stopifnot(identical(names(fit$sharp.covariates), colnames(Z)))
  }
  cat("PASS:", count, "public output configurations, including serialized and nested results.\n")
  cat("PASS: direct design functions, covariate names, and requested/effective bandwidth distinctions.\n")
})
