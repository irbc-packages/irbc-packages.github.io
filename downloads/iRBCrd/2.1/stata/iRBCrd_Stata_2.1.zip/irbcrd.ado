*! irbcrd 2.1, 28oct2026
program define irbcrd, eclass
    version 16.0
    if replay() {
        if "`e(cmd)'" != "irbcrd" error 301
        syntax [, ALPHA(string) NODISplay]
        if "`alpha'" != "" {
            confirm number `alpha'
            if `alpha' != e(alpha) {
                di as error "Refit with alpha() to change the confidence level, including bootstrap quantiles."
                exit 198
            }
        }
        if "`nodisplay'" == "" _irbcrd_display
        exit
    }
    local cmdline `"irbcrd `0'"'
    syntax varlist(min=2 max=2 numeric) [if] [in], H(numlist min=1 max=2 >0) ///
        [C(real 0) P(string) KERNEL(string) FUZZY(varname numeric) KINK ///
         COVS(varlist numeric) RES(string) ALPHA(real .05) BWCHECK(integer 21) ///
         FAST boot_ci boot_b(integer 999) boot_seed(string) ///
         boot_wild(string) boot_keep q_method(string) ///
         fuzzy_boot_weights(string) gamma_boot_weights(string) NODISplay]

    gettoken y x : varlist
    if "`p'" == "" {
        local p 1
        if "`kink'" != "" local p 2
    }
    confirm integer number `p'
    if missing(`c') | missing(`p') | `p' < 0 | ("`kink'" != "" & `p' < 1) {
        di as error "c() must be finite; p() must be nonnegative for levels and at least one for kinks."
        exit 198
    }
    if missing(`alpha') | `alpha' <= 0 | `alpha' >= 1 {
        di as error "alpha() must be strictly between zero and one."
        exit 198
    }
    if missing(`bwcheck') | `bwcheck' < 0 {
        di as error "bwcheck() must be a positive integer, or zero to disable regularization."
        exit 198
    }
    if missing(`boot_b') | `boot_b' < 1 {
        di as error "boot_b() must be a positive integer."
        exit 198
    }
    local nh : word count `h'
    local hl : word 1 of `h'
    local hr `hl'
    local pooled = (`nh' == 1 & "`kink'" == "")
    if `nh' == 2 local hr : word 2 of `h'
    if missing(`hl') | missing(`hr') | `hl' <= 0 | `hr' <= 0 {
        di as error "h() must contain one or two positive finite bandwidths, ordered left, right."
        exit 198
    }
    if "`kernel'" == "" local kernel tri
    local kernel = lower(strtrim("`kernel'"))
    local nk : word count `kernel'
    if `nk' < 1 | `nk' > 2 {
        di as error "kernel() accepts one kernel or two kernels ordered left, right."
        exit 198
    }
    local kl : word 1 of `kernel'
    local kr `kl'
    if `nk' == 2 local kr : word 2 of `kernel'
    foreach side in l r {
        if "`k`side''" == "triangular" local k`side' tri
        if "`k`side''" == "epanechnikov" local k`side' epa
        if "`k`side''" == "uniform" local k`side' uni
        if !inlist("`k`side''", "tri", "epa", "uni") {
            di as error "kernel() must use tri, epa, or uni (long names are also accepted)."
            exit 198
        }
    }
    if "`res'" == "" local res irbc-hc3
    local res = lower(strtrim("`res'"))
    local res = subinstr(subinstr("`res'", "_", "-", .), " ", "-", .)
    if inlist("`res'", "hc0", "hc1", "hc2", "hc3") local res irbc-`res'
    if substr("`res'",1,4) == "rbc-" local res = "cct-" + substr("`res'",5,.)
    if !inlist("`res'", "irbc-hc0", "irbc-hc1", "irbc-hc2", "irbc-hc3", ///
               "cct-hc0", "cct-hc1", "cct-hc2", "cct-hc3", "loo") {
        di as error "res() must be irbc-hc0..irbc-hc3, cct-hc0..cct-hc3, or loo."
        exit 198
    }
    if "`q_method'" == "" {
        local q_method sample
        if "`fast'" != "" local q_method asymptotic
    }
    local q_method = lower(strtrim("`q_method'"))
    foreach ch in " " "_" "." "-" {
        local q_method = subinstr("`q_method'", "`ch'", "", .)
    }
    if inlist("`q_method'", "samples", "qn", "finite", "finitesample") local q_method sample
    if inlist("`q_method'", "asym", "population", "limit", "fast") local q_method asymptotic
    if !inlist("`q_method'", "sample", "asymptotic") {
        di as error "q_method() must be sample or asymptotic."
        exit 198
    }
    if "`kink'" == "" & "`q_method'" == "asymptotic" & `p' != 1 {
        di as error "Asymptotic Q for level RD requires p(1)."
        exit 198
    }
    if "`fast'" != "" & "`q_method'" != "asymptotic" {
        di as error "fast requires q_method(asymptotic)."
        exit 198
    }
    if "`boot_wild'" == "" local boot_wild rademacher
    local boot_wild = lower(strtrim("`boot_wild'"))
    foreach ch in " " "_" "." "-" "'" {
        local boot_wild = subinstr("`boot_wild'", "`ch'", "", .)
    }
    if "`boot_wild'" == "rad" local boot_wild rademacher
    if inlist("`boot_wild'", "gaussian", "standardnormal") local boot_wild normal
    if inlist("`boot_wild'", "mammens", "mammen1993", "mammentwopoint", "mammenwild") local boot_wild mammen
    if !inlist("`boot_wild'", "rademacher", "mammen", "normal") {
        di as error "boot_wild() must be rademacher, mammen, or normal."
        exit 198
    }
    if "`fuzzy_boot_weights'" != "" & "`fuzzy'" == "" {
        di as error "fuzzy_boot_weights() requires fuzzy()."
        exit 198
    }
    if "`gamma_boot_weights'" != "" & "`covs'" == "" {
        di as error "gamma_boot_weights() requires covs()."
        exit 198
    }
    foreach opt in fuzzy_boot_weights gamma_boot_weights {
        if "``opt''" == "" local `opt' fixed
        local `opt' = lower(strtrim("``opt''"))
        foreach ch in " " "_" "." "-" {
            local `opt' = subinstr("``opt''", "`ch'", "", .)
        }
        if "`opt'" == "fuzzy_boot_weights" & ///
            inlist("``opt''", "eq615", "equation615", "linear", "paper") local `opt' fixed
        if "`opt'" == "gamma_boot_weights" & ///
            inlist("``opt''", "original", "sample", "hat") local `opt' fixed
        if inlist("``opt''", "boot", "star", "starred", "bootstrapweights", "bootweights") local `opt' bootstrap
        if !inlist("``opt''", "fixed", "bootstrap") {
            di as error "`opt'() must be fixed or bootstrap."
            exit 198
        }
    }
    if "`boot_seed'" != "" {
        confirm number `boot_seed'
        if missing(`boot_seed') | `boot_seed' < 0 | `boot_seed' > 2147483647 {
            di as error "boot_seed() must be between zero and 2147483647."
            exit 198
        }
        local boot_seed = floor(`boot_seed')
    }

    marksample touse
    markout `touse' `fuzzy' `covs'
    quietly count `if' `in'
    local selected = r(N)
    quietly count if `touse'
    local N = r(N)
    if `N' == 0 error 2000
    local omitted = `selected' - `N'

    capture mata: st_local("irbc_loaded", strofreal(irbc_st_version()))
    if _rc {
        quietly findfile irbcrd.mata
        quietly do `"`r(fn)'"'
    }
    else if "`irbc_loaded'" != "210" {
        di as error "A different iRBC Mata version is loaded; restart Stata before using this release."
        exit 498
    }
    tempname b V H
    if "`boot_ci'" != "" & "`boot_seed'" != "" set seed `boot_seed'
    mata: irbc_stata("`y'", "`x'", "`fuzzy'", "`covs'", "`touse'", "`b'", "`V'")
    matrix colnames `b' = tau
    matrix colnames `V' = tau
    matrix rownames `V' = tau
    matrix `H' = (`hl', `hr')
    matrix colnames `H' = minus plus
    ereturn post `b' `V', esample(`touse') obs(`N') depname(`y')
    mata: irbc_post()
    ereturn scalar N_selected = `selected'
    ereturn scalar N_omitted = `omitted'
    ereturn scalar c = `c'
    ereturn scalar p = `p'
    ereturn scalar kink = ("`kink'" != "")
    ereturn scalar alpha = `alpha'
    ereturn scalar level = 100 * (1 - `alpha')
    ereturn scalar bwcheck = `bwcheck'
    ereturn scalar pooled_regularization = `pooled'
    ereturn scalar fast = ("`fast'" != "")
    ereturn matrix h = `H'
    ereturn local kernel "`kl' `kr'"
    ereturn local kernel_minus "`kl'"
    ereturn local kernel_plus "`kr'"
    ereturn local res "`res'"
    ereturn local covs "`covs'"
    ereturn local fuzzy "`fuzzy'"
    ereturn local runningvar "`x'"
    ereturn local vce "robust"
    ereturn local vcetype "iRBC"
    ereturn local version "2.1"
    ereturn local cmdline `"`cmdline'"'
    ereturn local cmd "irbcrd"
    if "`fuzzy'" != "" ereturn local fuzzy_boot_weights "`fuzzy_boot_weights'"
    if "`covs'" != "" ereturn local gamma_boot_weights "`gamma_boot_weights'"
    if "`boot_ci'" != "" {
        ereturn scalar boot_B = `boot_b'
        ereturn scalar boot_keep = ("`boot_keep'" != "")
        ereturn local boot_wild "`boot_wild'"
        if "`boot_seed'" != "" ereturn scalar boot_seed = `boot_seed'
        if "`boot_insufficient'" == "1" {
            di as error "Warning: fewer than two finite bootstrap draws; the bootstrap interval is missing."
        }
    }
    if "`nodisplay'" == "" _irbcrd_display
end

program define _irbcrd_display
    version 16.0
    di as text _newline "iRBCrd: `e(design)' regression discontinuity"
    di as text "Observations = " as result e(N) as text "    Confidence level = " as result e(level) as text "%"
    di as text "Residuals: `e(res)'"
    matlist e(table_irbc), format(%12.6g) names(all) border(rows)
    if "`e(boot_wild)'" != "" {
        di as text "Bootstrap: `e(boot_wild)', " as result e(boot_B) as text " draws requested."
        di as text "Bootstrap estimate equals analytic iRBC; the interval need not be centered on it."
    }
    if e(N_omitted)>0 di as text "Excluded " as result e(N_omitted) as text " observations with missing analysis variables."
end
