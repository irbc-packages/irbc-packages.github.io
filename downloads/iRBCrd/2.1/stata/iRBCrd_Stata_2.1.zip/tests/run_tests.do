* Prepared for a future Stata run; not executed during the 2.1 source update.
* Start in the package folder. This script replaces data and clears Mata.
version 16.0
clear all
set more off
adopath ++ "."
set seed 17041998
set obs 240
generate double x = 2*(_n-.5)/_N-1
generate double z1 = .2*x+rnormal()
generate double z2 = -.3*x+rnormal()
generate double d = .4+.8*(x>=0)+1.5*x*(x>=0)+.1*z1+.05*rnormal()
generate double y = 1+x+.5*x^2+.2*x^3+.9*d+.4*z1-.2*z2+.15*rnormal()

* All eight designs, both Q choices, all HC residuals, and unscaled residuals.
foreach kink in 0 1 {
    local kopt ""
    if `kink' local kopt kink
    foreach fuzzy in 0 1 {
        local fopt ""
        if `fuzzy' local fopt fuzzy(d)
        foreach covs in 0 1 {
            local zopt ""
            if `covs' local zopt covs(z1 z2)
            foreach q in sample asymptotic {
                foreach res in irbc-hc0 irbc-hc1 irbc-hc2 irbc-hc3 cct-hc0 cct-hc1 cct-hc2 cct-hc3 loo {
                    quietly irbcrd y x, h(.6 .7) `kopt' `fopt' `zopt' res(`res') q_method(`q')
                    assert !missing(e(estimate_irbc),e(se_irbc))
                    assert e(kink)==`kink'
                    assert e(p)==1+`kink'
                    assert e(alpha)==.05
                    assert e(estimate_irbc)==_b[tau]
                    assert abs(e(se_irbc)-_se[tau])<1e-12
                    assert "`e(res)'"=="`res'"
                    mata: assert(all(st_matrix("e(h)"):==(.6,.7)))
                    mata: assert(rows(st_matrix("e(boot_t)"))==0)
                    mata: assert(rows(st_matrix("e(Q)"))==0)
                    assert "`e(q_method)'"==""
                    local scalars : e(scalars)
                    foreach removed in boot_success boot_mhat {
                        local found : list removed in scalars
                        assert !`found'
                    }
                }
            }

            * Independent fuzzy/gamma weights; same analytic result in every case.
            quietly irbcrd y x, h(.65) `kopt' `fopt' `zopt' res(cct-hc3)
            scalar reference_estimate = e(estimate_irbc)
            scalar reference_se = e(se_irbc)
            foreach fw in fixed bootstrap {
                if !`fuzzy' & "`fw'"=="bootstrap" continue
                local fwopt ""
                if `fuzzy' local fwopt fuzzy_boot_weights(`fw')
                foreach gw in fixed bootstrap {
                    if !`covs' & "`gw'"=="bootstrap" continue
                    local gwopt ""
                    if `covs' local gwopt gamma_boot_weights(`gw')
                    foreach wild in rademacher mammen normal {
                        quietly irbcrd y x, h(.65) `kopt' `fopt' `zopt' res(cct-hc3) ///
                            boot_ci boot_b(39) boot_seed(17041998) boot_wild(`wild') `fwopt' `gwopt'
                        assert abs(e(estimate_irbc)-reference_estimate)<1e-12
                        assert abs(e(se_irbc)-reference_se)<1e-12
                        assert e(estimate_irbc_boot)==e(estimate_irbc)
                        mata: assert(rows(st_matrix("e(boot_t)"))==0)
                        mata: irbc_test_ci = st_matrix("e(ci_irbc_boot)")
                        quietly irbcrd y x, h(.65) `kopt' `fopt' `zopt' res(cct-hc3) ///
                            boot_ci boot_b(39) boot_seed(17041998) boot_wild(`wild') ///
                            boot_keep `fwopt' `gwopt'
                        mata: assert(all(st_matrix("e(ci_irbc_boot)"):==irbc_test_ci))
                        mata: assert(rows(st_matrix("e(boot_t)"))==39)
                        mata: assert(rows(st_matrix("e(boot_linear_weights)"))==39)
                    }
                }
            }
        }
    }
}

* Other orders, paired kernels, fast constants, and bandwidth enlargement.
foreach kernel in tri epa uni {
    quietly irbcrd y x, h(.65) kernel(`kernel') q_method(asymptotic) fast
    foreach p in 1 2 3 {
        quietly irbcrd y x, h(.65) kink p(`p') kernel(`kernel') q_method(asymptotic) fast
        assert !missing(e(se_irbc))
    }
}
quietly irbcrd y x, h(.65) p(0) res(cct-hc0)
quietly irbcrd y x, h(.6 .7) kernel(triangular epanechnikov) bwcheck(0)
assert "`e(kernel_minus)'"=="tri"
assert "`e(kernel_plus)'"=="epa"
quietly irbcrd y x, h(.01) kink bwcheck(31) res(cct-hc3)
mata: assert(all(st_matrix("e(h)"):==(.01,.01)))
assert e(h_minus)>.01 & e(h_plus)>.01
quietly irbcrd y x, h(.65) alpha(.01) boot_ci boot_b(1) boot_seed(123)
mata: assert(all(st_matrix("e(ci_irbc_boot)"):>=.))
quietly irbcrd y x, h(.65) alpha(.1)
assert e(alpha)==.1
irbcrd
capture irbcrd, alpha(.05)
assert _rc==198

* Rejected old options and invalid designs must not silently change the target.
foreach old in gloo hleft(.5) hright(.6) kleft(tri) kright(epa) residuals(hc3) qmethod(sample) level(95) bootstrap reps(39) nokeep {
    capture irbcrd y x, h(.65) `old'
    assert _rc==198
}
foreach bad in alpha(0) p(-1) boot_b(0) q_method(unknown) res(unknown) fuzzy_boot_weights(bootstrap) gamma_boot_weights(bootstrap) {
    capture irbcrd y x, h(.65) `bad'
    assert _rc==198
}
capture irbcrd y x, h(.65) q_method(sample) fast
assert _rc==198
capture irbcrd y x, h(.65) q_method(asymptotic) p(2)
assert _rc==198
capture irbcrd y x, h(.65) kink p(0)
assert _rc==198
generate double zero = 0
capture irbcrd y x, h(.65) fuzzy(zero)
assert _rc==498
capture irbcrd y x, h(.65) covs(zero)
assert _rc==498

* Sample marking and reloading after Mata is cleared.
replace y = . in 1
replace z1 = . in 2
quietly count if _n<=200 & !missing(y,x,d,z1,z2)
local wanted = r(N)
quietly irbcrd y x if _n<=200, h(.65) fuzzy(d) covs(z1 z2)
assert e(N)==`wanted' & e(N_omitted)==2
quietly count if e(sample)
assert r(N)==`wanted'
mata: mata clear
quietly irbcrd y x, h(.65) res(cct-hc3)
assert !missing(e(estimate_irbc))
display as result "PASS: Stata 2.1 design, interface, and bootstrap checks."
