# Generate R 2.1 expectations and shared wild multipliers; never launch Stata.
main <- function() {
  arg <- grep("^--file=", commandArgs(), value = TRUE)
  here <- if (length(arg)) dirname(normalizePath(sub("^--file=", "", arg[1]))) else normalizePath("tests")
  root <- dirname(here)
  reference <- normalizePath(file.path(root, "../../R/2.1"), mustWork = TRUE)
  output <- file.path(here, "reference_fixtures")
  dir.create(output, showWarnings = FALSE)
  E <- new.env(parent = globalenv())
  sources <- file.path(reference, c("iRBC_functions.R", "iRBCrd.R"))
  for (path in sources) sys.source(path, E)
  old <- options(digits = 17)
  on.exit(options(old), add = TRUE)
  csv <- function(x, name) write.table(x, file.path(output, name), sep = ",",
    row.names = FALSE, col.names = TRUE, quote = FALSE, na = ".")
  set.seed(17041998)
  make_data <- function(x, binary = FALSE) {
    n <- length(x)
    z1 <- .3*x + rnorm(n)
    z2 <- -.2*x + rnorm(n)
    d <- if (binary) rbinom(n, 1, .15 + .7*(x >= 0)) else
      .4 + 1.8*(x >= 0) + 2.5*pmax(x, 0) + .2*z1 + rnorm(n, sd = .12)
    y <- 1 + x + .5*x^2 + .2*x^3 + .9*d + .4*z1 - .2*z2 + rnorm(n, sd = .25)
    data.frame(y, x, d, z1, z2)
  }
  balanced <- make_data(sample(seq(-.99, .99, length.out = 120)))
  shifted <- balanced
  shifted$x <- shifted$x + .25
  datasets <- list(balanced = balanced, shifted = shifted,
    sparse = make_data(sample(c(seq(-1, -.02, length.out = 32), seq(.01, .95, length.out = 88)))),
    tied = make_data(rep(seq(-1, 1, length.out = 41), each = 3)),
    binary = make_data(sample(seq(-.99, .99, length.out = 160)), TRUE))
  for (name in names(datasets)) csv(datasets[[name]], paste0(name, ".csv"))

  cases <- list()
  add <- function(kink = FALSE, fuzzy = FALSE, adjusted = FALSE, ...) {
    spec <- modifyList(list(kink = kink, fuzzy = fuzzy, adjusted = adjusted,
      dataset = "balanced", h = .65, p = if (kink) 2L else 1L, c = 0,
      kernel = "tri", res = "irbc-hc3", q = "sample", bwcheck = 21L,
      fast = FALSE, fw = "fixed", gw = "fixed", wild = "rademacher",
      B = 19L, alpha = .05), list(...))
    cases[[length(cases) + 1L]] <<- spec
  }
  for (k in c(FALSE, TRUE)) for (f in c(FALSE, TRUE)) for (z in c(FALSE, TRUE)) {
    for (q in c("sample", "asymptotic")) {
      for (res in c(paste0("irbc-hc", 0:3), paste0("cct-hc", 0:3), "loo")) add(k,f,z,q=q,res=res)
      for (fw in if (f) c("fixed", "bootstrap") else "fixed") {
        for (gw in if (z) c("fixed", "bootstrap") else "fixed") {
          for (wild in c("rademacher", "mammen", "normal")) {
            for (res in c("irbc-hc3", "cct-hc3")) {
              if (fw == "fixed" && gw == "fixed" && wild == "rademacher") next
              add(k,f,z,q=q,res=res,fw=fw,gw=gw,wild=wild)
            }
          }
        }
      }
    }
    for (ker in c("tri", "epa", "uni")) add(k,f,z,kernel=ker,q="asymptotic",fast=TRUE)
    add(k,f,z,h=c(.55,.75),kernel=c("tri","epa"),bwcheck=0L,alpha=.1)
    add(k,f,z,h=c(.55,.75),kernel="uni",res="cct-hc3",alpha=.01)
    add(k,f,z,p=if (k) 3L else 2L,res="cct-hc3")
    add(k,f,z,dataset="shifted",c=.25)
    add(k,f,z,dataset="tied",h=c(.6,.7),res="cct-hc3")
    add(k,f,z,dataset="sparse",h=c(.03,.04),bwcheck=25L,res="cct-hc3")
    add(k,f,z,dataset="sparse",h=.03,bwcheck=21L,res="irbc-hc3")
    add(k,f,z,B=999L,res="cct-hc3",fw=if(f) "bootstrap" else "fixed",
        gw=if(z) "bootstrap" else "fixed")
    if (!k) add(k,f,z,dataset="binary",res="cct-hc3")
  }

  get_reference <- function(data, o, W) {
    x <- data$x
    left <- x < o$c
    right <- !left
    bw <- if (o$bwcheck == 0) NULL else o$bwcheck
    h <- rep(o$h, length.out = 2)
    kernels <- rep(o$kernel, length.out = 2)
    if (o$kink || length(o$h) == 2L) {
      h <- c(E$.regularize_h(x[left],o$c,h[1],bw), E$.regularize_h(x[right],o$c,h[2],bw))
    } else h[] <- E$.regularize_h(x,o$c,h[1],bw)
    hfit <- c(E$.regularize_h(x[left],o$c,h[1],bw), E$.regularize_h(x[right],o$c,h[2],bw))
    hb <- if (o$kink || (!o$fuzzy && !o$adjusted)) hfit else h
    active <- if (o$kink) which(ifelse(right,
      E$K((x-o$c)/hb[2],kernels[2]) > 0, E$K((x-o$c)/hb[1],kernels[1]) > 0)) else
      which(ifelse(right,abs(x-o$c)<=hb[2],abs(x-o$c)<=hb[1]))
    draw <- E$.irbcrd_wild_draws
    bb <- 0L
    E$.irbcrd_wild_draws <- function(n, wild) {
      bb <<- bb + 1L
      stopifnot(n == length(active), bb <= ncol(W))
      W[active, bb]
    }
    on.exit(E$.irbcrd_wild_draws <- draw, add = TRUE)
    args <- list(y=data$y,x=x,h=o$h,c=o$c,p=o$p,kernel=o$kernel,kink=o$kink,
      res=o$res,alpha=o$alpha,bwcheck=bw,fast=o$fast,q.method=o$q,
      boot.ci=TRUE,boot.B=o$B,boot.wild=o$wild,boot.keep=TRUE)
    if (o$fuzzy) { args$fuzzy <- data$d; args$fuzzy.boot.weights <- o$fw }
    if (o$adjusted) { args$covs <- as.matrix(data[c("z1","z2")]); args$gamma.boot.weights <- o$gw }
    fit <- do.call(E$iRBCrd,args)
    stopifnot(bb == o$B, fit$estimate_irbc_boot == fit$estimate_irbc)
    fits <- if (o$kink) fit$sharp.components else if (!o$fuzzy && !o$adjusted) list(fit) else
      c(list(fit$sharp.outcome),if(o$fuzzy) list(fit$sharp.treatment),if(o$adjusted) fit$sharp.covariates)
    tau <- vapply(fits,function(f) as.numeric(f$tau.hat),numeric(1))
    bias <- vapply(fits,function(f) as.numeric(f$Bhat.irbc),numeric(1))
    residuals <- matrix(0,nrow(data),length(fits))
    for (j in seq_along(fits)) {
      residuals[left,j] <- fits[[j]]$epshat.minus
      residuals[right,j] <- fits[[j]]$epshat.plus
    }
    raw <- if(o$fuzzy) fit$zeta.hat else fit$tau.hat
    weights <- if(o$kink) fit$linear.weights else if(o$fuzzy && o$adjusted) fit$cfrd.weights else
      if(o$fuzzy) fit$frd.weights else if(o$adjusted) fit$crd.weights else 1
    # Each entry pairs a real R result with the corresponding Mata expression.
    out <- list(estimate=fit$estimate_irbc,uncorrected=raw,bias=raw-fit$estimate_irbc,
      se=fit$se_irbc,se_us=fit$se_us,ci=fit$ci_irbc,ci_boot=fit$ci_irbc_boot,
      h=c(fit$h.minus,fit$h.plus),weights=weights,components=tau,component_bias=bias,
      residuals=residuals,boot_t=fit$boot.t)
    if(o$fuzzy) out$first_stage <- if(o$adjusted) fit$tau.d.adj.hat else fit$tau.d.hat
    if(o$adjusted) out$gamma <- if(o$fuzzy) cbind(fit$gamma.y.hat,fit$gamma.d.hat) else matrix(fit$gamma.hat,ncol=1)
    for (nm in c("cov.irbc","cov.us","boot.t.components","boot.linear.weights","boot.fuzzy.weights")) {
      if(!is.null(fit[[nm]])) {
        target <- switch(nm,"boot.t.components"="boot_components",gsub(".","_",nm,fixed=TRUE))
        out[[target]] <- fit[[nm]]
      }
    }
    if(!is.null(fit$boot.gamma)) out$boot_gamma_y <- fit$boot.gamma
    if(!is.null(fit$boot.gamma.y)) out$boot_gamma_y <- fit$boot.gamma.y
    if(!is.null(fit$boot.gamma.d)) out$boot_gamma_d <- fit$boot.gamma.d
    if(!is.null(fit$boot.adjusted.first.stage)) out$boot_first_stage <- fit$boot.adjusted.first.stage
    if(o$kink) {
      out$kink_weights_minus <- do.call(cbind,fit$kink.weights$minus)
      out$kink_weights_plus <- do.call(cbind,fit$kink.weights$plus)
      out$pilot_h_minus <- fit$pilot.h$minus
      out$pilot_h_plus <- fit$pilot.h$plus
    }
    list(values=out,fit=fit)
  }

  commands <- c("* Generated R 2.1 comparisons. Run from tests/compare_R.do.",
                "mata: irbc_compare_report = J(0,4,.)")
  public_commands <- c("* Generated public-command checks against the numerical core.",
                       "mata: irbc_public_report = J(0,4,.)")
  manifest <- list()
  failures <- list()
  for (i in seq_along(cases)) {
    o <- cases[[i]]
    data <- datasets[[o$dataset]]
    id <- sprintf("case_%03d",i)
    set.seed(17041998+i)
    W <- matrix(E$.irbcrd_wild_draws(nrow(data)*o$B,o$wild),nrow(data),o$B)
    result <- tryCatch(get_reference(data,o,W),error=function(e)e)
    if(inherits(result,"error")) {
      failures[[length(failures)+1L]] <- data.frame(case=id,error=conditionMessage(result))
      cat(id,"R reference ERROR:",conditionMessage(result),"\n")
      next
    }
    out <- result$values
    values <- unlist(lapply(out,as.numeric),use.names=FALSE)
    labels <- unlist(Map(function(nm,v) paste0(nm,"[",seq_along(v),"]"),names(out),out),use.names=FALSE)
    csv(data.frame(field=labels,value=values),paste0(id,"_expected.csv"))
    csv(as.data.frame(W),paste0(id,"_weights.csv"))
    h <- rep(o$h,length.out=2)
    kernel <- rep(o$kernel,length.out=2)
    ycols <- paste(c("y",if(o$fuzzy) "d",if(o$adjusted) c("z1","z2")),collapse=" ")
    commands <- c(commands,
      sprintf('import delimited using "tests/reference_fixtures/%s_weights.csv", varnames(1) asdouble clear',id),
      "mata: irbc_test_W = st_data(.,.)",
      sprintf('import delimited using "tests/reference_fixtures/%s.csv", varnames(1) asdouble clear',o$dataset),
      "mata:","irbc_test_o = irbc_test_options()",
      sprintf("irbc_test_o.cutoff = %.17g",o$c),sprintf("irbc_test_o.p = %d",o$p),
      sprintf("irbc_test_o.kink = %d",o$kink),sprintf("irbc_test_o.fuzzy = %d",o$fuzzy),
      sprintf("irbc_test_o.alpha = %.17g",o$alpha),sprintf("irbc_test_o.bwcheck = %d",o$bwcheck),
      sprintf("irbc_test_o.pooled = %d",length(o$h)==1L && !o$kink),
      sprintf("irbc_test_o.fast = %d",o$fast),sprintf("irbc_test_o.reps = %d",o$B),
      sprintf("irbc_test_o.h = (%.17g,%.17g)",h[1],h[2]),
      sprintf('irbc_test_o.kernel = ("%s","%s")',kernel[1],kernel[2]),
      sprintf('irbc_test_o.res = "%s"',o$res),sprintf('irbc_test_o.q_method = "%s"',o$q),
      sprintf('irbc_test_o.boot_wild = "%s"',o$wild),
      sprintf('irbc_test_o.fuzzy_boot_weights = "%s"',o$fw),
      sprintf('irbc_test_o.gamma_boot_weights = "%s"',o$gw),
      sprintf('irbc_test_result = irbc_compute(st_data(.,"x"),st_data(.,tokens("%s")),irbc_test_o,irbc_test_W)',ycols),
      paste0("irbc_test_actual = (",paste0("vec(irbc_test_result.",names(out),")",collapse=" \\ "),")"),
      "end",
      sprintf('import delimited using "tests/reference_fixtures/%s_expected.csv", varnames(1) asdouble clear',id),
      sprintf('mata: irbc_compare_R(irbc_test_actual,st_data(.,"value"),st_sdata(.,"field"),%d)',i))
    options <- c(sprintf("h(%s)",paste(o$h,collapse=" ")),sprintf("c(%.17g)",o$c),
      sprintf("p(%d)",o$p),sprintf("kernel(%s)",paste(o$kernel,collapse=" ")),
      if(o$kink) "kink",if(o$fuzzy) "fuzzy(d)",if(o$adjusted) "covs(z1 z2)",
      sprintf("res(%s)",o$res),sprintf("alpha(%.17g)",o$alpha),
      sprintf("bwcheck(%d)",o$bwcheck),if(o$fast) "fast",sprintf("q_method(%s)",o$q))
    public_commands <- c(public_commands,
      sprintf('import delimited using "tests/reference_fixtures/%s.csv", varnames(1) asdouble clear',o$dataset),
      sprintf("quietly irbcrd y x, %s",paste(options,collapse=" ")),
      sprintf('mata: irbc_compare_public(%d)',i))
    manifest[[length(manifest)+1L]] <- data.frame(case=id,kink=o$kink,fuzzy=o$fuzzy,adjusted=o$adjusted,
      dataset=o$dataset,res=o$res,q=o$q,fw=o$fw,gw=o$gw,wild=o$wild,B=o$B,fast=o$fast,
      p=o$p,h=paste(o$h,collapse="/"),kernel=paste(o$kernel,collapse="/"),values=length(values))
    if(i %% 20L == 0L) cat("Prepared",i,"of",length(cases),"R reference cases\n")
  }
  manifest <- do.call(rbind,manifest)
  failures <- if(length(failures)) do.call(rbind,failures) else data.frame(case=character(),error=character())
  csv(manifest,"manifest.csv")
  csv(failures,"R_reference_errors.csv")
  saveRDS(cases,file.path(output,"specifications.rds"))
  writeLines(commands,file.path(output,"cases.do"))
  writeLines(public_commands,file.path(output,"public_cases.do"))
  report <- c(paste("R reference cases prepared:",nrow(manifest)),
    paste("R reference errors:",nrow(failures)),paste("Expected numeric values:",sum(manifest$values)),
    "Stata comparisons have NOT been run by this script.",
    paste(basename(sources),unname(tools::md5sum(sources))))
  writeLines(report,file.path(output,"REFERENCE_STATUS.txt"))
  cat(paste(report,collapse="\n"),"\n")
  if(nrow(failures)) stop("Some R reference cases failed; inspect R_reference_errors.csv before validation.")
}
main()
