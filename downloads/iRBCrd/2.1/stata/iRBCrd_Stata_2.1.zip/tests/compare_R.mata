version 16.0
mata:
irbc_compare_report = J(0,4,.)
irbc_public_report = J(0,4,.)

struct irbc_options scalar irbc_test_options()
{
    struct irbc_options scalar o
    o.cutoff = 0
    o.p = 1
    o.alpha = .05
    o.bwcheck = 21
    o.pooled = 1
    o.fast = o.kink = o.fuzzy = 0
    o.bootstrap = o.keep = 1
    o.reps = 19
    o.h = (.65,.65)
    o.kernel = ("tri","tri")
    o.res = "irbc-hc3"
    o.q_method = "sample"
    o.boot_wild = "rademacher"
    o.fuzzy_boot_weights = o.gamma_boot_weights = "fixed"
    return(o)
}

void irbc_compare_R(real colvector actual, real colvector expected,
                    string colvector fields, real scalar id)
{
    external real matrix irbc_compare_report
    real colvector valid, difference, scaled, where
    real scalar maximum, maximum_absolute
    if (rows(actual)!=rows(expected)) irbc_fail("R comparison: result dimensions differ.")
    if (sum((actual:>=.):!=(expected:>=.))) irbc_fail("R comparison: missing-value patterns differ.")
    valid = selectindex(expected:<.)
    difference = abs(actual[valid]-expected[valid])
    scaled = difference:/(1:+abs(expected[valid]))
    maximum = max(scaled)
    maximum_absolute = max(difference)
    irbc_compare_report = irbc_compare_report \ (id,rows(expected),maximum_absolute,maximum)
    if (maximum>1e-7 | maximum>=.) {
        where = selectindex(scaled:==maximum)
        errprintf("Case %g, %s: Stata=%21.14g, R=%21.14g, scaled difference=%12.5g\n",
            id,fields[valid[where[1]]],actual[valid[where[1]]],expected[valid[where[1]]],maximum)
        irbc_fail("Stata/R numerical comparison failed.")
    }
    printf("PASS R comparison case %g: %g values; max scaled difference %12.5g\n",id,rows(expected),maximum)
}

void irbc_compare_public(real scalar id)
{
    external struct irbc_result scalar irbc_last
    external real matrix irbc_public_report
    real colvector actual, expected, difference
    actual = (vec(st_matrix("e(b)")) \ vec(st_matrix("e(V)")) \
              st_numscalar("e(estimate_irbc)") \ st_numscalar("e(se_irbc)") \
              st_numscalar("e(se_us)") \ vec(st_matrix("e(ci_irbc)")) \
              st_numscalar("e(h_minus)") \ st_numscalar("e(h_plus)") \
              vec(st_matrix("e(component_estimates)")) \
              vec(st_matrix("e(component_bias)")) \ vec(st_matrix("e(linear_weights)")) \
              vec(st_matrix("e(cov_irbc)")) \ vec(st_matrix("e(cov_us)")) \
              vec(st_matrix("e(epshat_minus)")) \ vec(st_matrix("e(epshat_plus)")))
    expected = (irbc_last.estimate \ irbc_last.se^2 \ irbc_last.estimate \
                irbc_last.se \ irbc_last.se_us \ vec(irbc_last.ci) \ vec(irbc_last.h) \
                vec(irbc_last.components) \ vec(irbc_last.component_bias) \
                vec(irbc_last.weights) \ vec(irbc_last.cov_irbc) \ vec(irbc_last.cov_us) \
                vec(irbc_last.residuals[irbc_last.index_minus,.]) \
                vec(irbc_last.residuals[irbc_last.index_plus,.]))
    if (rows(actual)!=rows(expected) | hasmissing(actual)) irbc_fail("Public results have incorrect dimensions or missing values.")
    difference = abs(actual-expected)
    irbc_public_report = irbc_public_report \ (id,rows(expected),max(difference),max(difference:/(1:+abs(expected))))
    if (max(difference)>1e-12) irbc_fail("Public results differ from the numerical core.")
}
end
