# Summarize completed native tests; never infer success from process exit codes.
arg <- grep("^--file=", commandArgs(), value = TRUE)
here <- if (length(arg)) dirname(normalizePath(sub("^--file=", "", arg[1]))) else normalizePath("tests")
root <- dirname(here)
fixtures <- file.path(here, "reference_fixtures")
has_marker <- function(log, marker) {
  lines <- readLines(file.path(root, log), warn = FALSE)
  stopifnot(any(lines == marker))
}
has_marker("run_tests.log", "PASS: Stata 2.1 design, interface, and bootstrap checks.")
has_marker("compare_R.log", "PASS: all native Stata/R 2.1 numerical comparisons.")
has_marker("compare_R.log", "PASS: all public-command result checks.")
manifest <- read.csv(file.path(fixtures, "manifest.csv"))
errors <- read.csv(file.path(fixtures, "R_reference_errors.csv"))
comparison <- read.csv(file.path(fixtures, "stata_comparison_results.csv"))
public <- read.csv(file.path(fixtures, "public_comparison_results.csv"))
stopifnot(nrow(errors) == 0L,
  identical(sprintf("case_%03d", comparison$case_number), manifest$case),
  identical(comparison$compared_values, manifest$values),
  identical(public$case_number, comparison$case_number),
  all(is.finite(as.matrix(comparison))), all(is.finite(as.matrix(public))),
  max(comparison$max_scaled_difference) <= 1e-7,
  max(public$max_absolute_difference) <= 1e-12)
reference <- file.path(root, "../../R/2.1", c("iRBC_functions.R", "iRBCrd.R"))
hashes <- paste(basename(reference), unname(tools::md5sum(reference)))
stopifnot(all(hashes %in% readLines(file.path(fixtures, "REFERENCE_STATUS.txt"))))
sources <- c("irbcrd.ado", "irbcrd.mata", "tests/run_tests.do", "tests/prepare_reference.R",
             "tests/compare_R.mata", "tests/compare_R.do")
report <- c(
  "iRBCrd Stata 2.1: native validation against R 2.1",
  paste("Report generated:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "Executed with Stata/SE 18.0 on macOS.",
  "",
  "PASS: native interface, design, bootstrap, and error-handling tests.",
  sprintf("PASS: %d cross-language cases; %d numerical values.", nrow(comparison), sum(comparison$compared_values)),
  sprintf("Largest absolute difference: %.8g", max(comparison$max_absolute_difference)),
  sprintf("Largest abs(Stata-R)/(1+abs(R)): %.8g", max(comparison$max_scaled_difference)),
  "Required scaled tolerance: 1e-7; missing-value patterns also matched.",
  sprintf("PASS: %d public-command checks; %d returned values.", nrow(public), sum(public$compared_values)),
  sprintf("Largest public-output/core difference: %.8g", max(public$max_absolute_difference)),
  "",
  "Coverage of the comparison suite:",
  "- Sharp, fuzzy, covariate-adjusted sharp, and covariate-adjusted fuzzy RD,",
  "  each in levels and kinks; analytic and bootstrap inference.",
  "- Sample/asymptotic Q, iRBC-HC0..HC3, CCT-HC0..HC3, and loo residuals.",
  "- Fixed/bootstrap fuzzy and covariate weights in every applicable combination.",
  "- Rademacher, Mammen, and normal multipliers; B=19 and B=999 cases.",
  "- Kernel and bandwidth pairs, fast calculations, higher polynomial orders,",
  "  shifted cutoffs, ties, binary treatment, and sparse-bandwidth regularization.",
  "- Estimates, standard errors, confidence intervals, residuals, component",
  "  covariance matrices, and retained bootstrap draws/weights where available.",
  "",
  "Both programs received identical data and observation-level multipliers.",
  "Identical numeric seeds alone do not match R and Stata bootstrap streams.",
  "Agreement is established for these tests, not a proof for every possible input.",
  "",
  "Fixes made during native validation:",
  "- Lowercase declarations for underscore-containing Stata options.",
  "- Valid Mata global initialization and a nonreserved bootstrap-mask name.",
  "- Safe empty-cache-hit check for population kink constants.",
  "The R implementation was not modified.",
  "",
  "R reference MD5:", hashes, "",
  "Validated Stata/test MD5:", paste(sources, unname(tools::md5sum(file.path(root, sources)))),
  "",
  "Detailed cases and differences: tests/reference_fixtures/.",
  "Native logs: run_tests.log and compare_R.log.")
writeLines(report, file.path(here, "VALIDATION.txt"))
cat(paste(report, collapse = "\n"), "\n")
