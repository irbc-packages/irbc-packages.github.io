DEVELOPER CHECKS -- STATA 2.1

The October 28 source update was initially requested without Stata validation.
The subsequent native validation used activated Stata/SE 18.0 on macOS.
See VALIDATION.txt for completed checks, numerical differences, and source hashes.
No Stata executable is invoked by the source-check or archive-build scripts.

check_source.R checks the manifest, source delimiters, option spelling,
removed public outputs, retention default, and R script syntax only.
It is not a compiler or a test of numerical agreement.

run_tests.do performs native interface and behavior checks.
It replaces data in memory and clears Mata. From the package folder:
  do tests/run_tests.do
It covers all eight designs, Q choices, residuals, all fuzzy/gamma weighting
combinations, wild-weight distributions, RNG reproducibility via identical
seeded keep/no-keep calls, kernel pairs, kink orders, regularization,
stored results, missing data, and invalid/retired options.

The R implementation used as the source specification is ../../R/2.1
relative to this package folder. SOURCE_CHECK.txt contains source hashes.
The old Stata 2.0 fixtures are intentionally not copied: they exercise a
different interface and do not cover the new kink and weighting behavior.
Cross-language numerical comparison must use aligned multiplier draws;
identical R/Stata seeds are not a substitute for aligned draws.

prepare_reference.R calls the current R 2.1 functions on shared data and
supplies predetermined bootstrap multipliers. From the package folder:
  Rscript --vanilla tests/prepare_reference.R
It writes expected results, multipliers, case specifications, source hashes,
and a generated comparison script to tests/reference_fixtures. It does not
launch Stata, and successful generation does not establish Stata agreement.

After activation, run in Stata from this package folder:
  do tests/compare_R.do
This clears data and Mata. It compares estimates, standard errors, intervals,
residuals, component results, available covariance matrices, and individual
bootstrap statistics, with identical data and multipliers in both programs.
The tolerance is abs(Stata - R)/(1 + abs(R)) <= 1e-7, with matching missing
patterns. Cases cover all eight designs, both Q choices, residual options,
all applicable weighting combinations, kernels, regularization, and B=999.
The second part checks results returned through the public command against
the numerical core. Check the log for both final PASS markers; an executable
exit code alone is not sufficient. Each report is written only after its
corresponding suite completes successfully.

After completing both native scripts, generate the validation summary with:
  Rscript --vanilla tests/summarize_validation.R
This verifies the PASS markers, case counts, numerical tolerances, and R
reference hashes before writing VALIDATION.txt. Native logs and generated
fixtures remain local; the ZIP includes the scripts and summary, not the logs.
