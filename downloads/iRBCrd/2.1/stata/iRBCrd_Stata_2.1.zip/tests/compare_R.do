* Run after Rscript tests/prepare_reference.R, from the package directory.
* This script clears the current data and Mata session.
version 16.0
clear all
set more off
adopath ++ "."
do irbcrd.mata
do tests/compare_R.mata
do tests/reference_fixtures/cases.do
clear
mata: st_addobs(rows(irbc_compare_report))
mata: st_addvar("double",("case_number","compared_values","max_absolute_difference","max_scaled_difference"))
mata: st_store(.,.,irbc_compare_report)
export delimited using tests/reference_fixtures/stata_comparison_results.csv, replace
display as result "PASS: all native Stata/R 2.1 numerical comparisons."
do tests/reference_fixtures/public_cases.do
clear
mata: st_addobs(rows(irbc_public_report))
mata: st_addvar("double",("case_number","compared_values","max_absolute_difference","max_scaled_difference"))
mata: st_store(.,.,irbc_public_report)
export delimited using tests/reference_fixtures/public_comparison_results.csv, replace
display as result "PASS: all public-command result checks."
