# Static checks only. This script never launches or compiles Stata/Mata.
arg <- grep("^--file=", commandArgs(), value = TRUE)
here <- if (length(arg)) dirname(normalizePath(sub("^--file=", "", arg[1]))) else normalizePath("tests")
root <- dirname(here)
read <- function(name) paste(readLines(file.path(root, name), warn = FALSE), collapse = "\n")
manifest <- readLines(file.path(root, "irbcrd.pkg"), warn = FALSE)
files <- sub("^f +", "", manifest[grepl("^f +", manifest)])
stopifnot(length(files) > 0, all(file.exists(file.path(root, files))))
mata <- read("irbcrd.mata")
ado <- read("irbcrd.ado")

# Check Mata delimiters outside strings/comments; apostrophes are transposes.
chars <- strsplit(mata, "", fixed = TRUE)[[1L]]
state <- "code"
stack <- character()
pairs <- c(")" = "(", "]" = "[", "}" = "{")
i <- 1L
while (i <= length(chars)) {
  a <- chars[i]
  b <- if (i < length(chars)) chars[i + 1L] else ""
  if (state == "line") {
    if (a == "\n") state <- "code"
  } else if (state == "block") {
    if (a == "*" && b == "/") { state <- "code"; i <- i + 1L }
  } else if (state == "string") {
    if (a == '"') state <- "code"
  } else if (a == "/" && b == "/") {
    state <- "line"; i <- i + 1L
  } else if (a == "/" && b == "*") {
    state <- "block"; i <- i + 1L
  } else if (a == '"') {
    state <- "string"
  } else if (a %in% c("(", "[", "{")) {
    stack <- c(stack, a)
  } else if (a %in% names(pairs)) {
    stopifnot(length(stack) > 0, tail(stack, 1) == pairs[[a]])
    stack <- head(stack, -1L)
  }
  i <- i + 1L
}
stopifnot(!length(stack), state %in% c("code", "line"))

options_block <- regmatches(mata, regexpr("struct irbc_options \\{[^}]+\\}", mata))
declared <- unique(unlist(strsplit(gsub("[^A-Za-z_ ]", " ", options_block), " +")))
used <- unique(sub("^o\\.", "", regmatches(mata, gregexpr("\\bo\\.[A-Za-z_]+", mata))[[1L]]))
stopifnot(all(used %in% declared))
syntax_start <- regexpr("syntax varlist", ado, fixed = TRUE)[1L]
syntax_end <- regexpr("gettoken y x", ado, fixed = TRUE)[1L]
syntax <- substr(ado, syntax_start, syntax_end - 1L)
expected <- c("H", "C", "P", "KERNEL", "FUZZY", "KINK", "COVS", "RES", "ALPHA",
              "BWCHECK", "FAST", "BOOT_CI", "BOOT_B", "BOOT_SEED", "BOOT_WILD",
              "BOOT_KEEP", "Q_METHOD", "FUZZY_BOOT_WEIGHTS", "GAMMA_BOOT_WEIGHTS")
for (opt in expected) stopifnot(grepl(paste0("\\b", opt, "\\b"), toupper(syntax)))
reference <- file.path(root, "../../R/2.1", c("iRBCrd.R", "iRBC_functions.R"))
reference_report <- "R source specification: version 2.1 (source files not present beside this extracted archive)."
if (all(file.exists(reference))) {
  expressions <- parse(reference[1L])
  entry <- Filter(function(e) is.call(e) && identical(e[[1L]], as.name("<-")) &&
                    identical(e[[2L]], as.name("iRBCrd")), as.list(expressions))
  stopifnot(length(entry) == 1L)
  arguments <- names(entry[[1L]][[3L]][[2L]])
  mapped <- toupper(gsub(".", "_", setdiff(arguments, c("y", "x")), fixed = TRUE))
  stopifnot(identical(mapped, expected))
  reference_report <- c("Every current R 2.1 unified argument has a corresponding Stata input.",
                        paste("R specification:", basename(reference), unname(tools::md5sum(reference))))
}
removed <- c("GLOO", "HLEFT", "HRIGHT", "KLEFT", "KRIGHT", "RESIDUALS", "QMETHOD",
             "LEVEL", "NOREGULARIZE", "BOOTSTRAP", "REPS", "SEED", "WILD",
             "FUZZYWEIGHTS", "GAMMAWEIGHTS", "NOKEEP", "DRAWMATRIX")
for (opt in removed) stopifnot(!grepl(paste0("\\b", opt, "\\b"), toupper(syntax)))
for (field in c("Q", "Q_minus", "Q_plus", "q_method", "boot_success", "boot_mhat",
                "boot_probs", "h_requested")) {
  stopifnot(!grepl(paste0('"e(', field, ')"'), mata, fixed = TRUE))
}
stopifnot(grepl('o.keep = st_local("boot_keep")!=""', mata, fixed = TRUE))
stopifnot(!grepl("gloo", paste(ado, mata), fixed = TRUE))
for (method in c("irbc_build_kink_side", "irbc_kink_constants", "irbc_gamma_refit")) {
  stopifnot(grepl(method, mata, fixed = TRUE))
}
for (name in c("boot_ci", "boot_b", "boot_keep", "gamma_boot_weights", "q_method")) {
  stopifnot(grepl(name, read("README.txt"), fixed = TRUE),
            grepl(name, read("irbcrd.sthlp"), fixed = TRUE))
}
scripts <- list.files(root, "\\.R$", recursive = TRUE, full.names = TRUE)
invisible(lapply(scripts, parse))
report <- c(
  "Static source integrity: PASS",
  "Checked package manifest, Mata delimiters, option declarations/references,",
  "public option mapping, removed output fields, default draw retention, and R script syntax.",
  "No Stata executable was launched. Mata was not compiled or executed.",
  "Native numerical validation is separate; consult tests/VALIDATION.txt when present.",
  reference_report,
  paste(files, unname(tools::md5sum(file.path(root, files)))))
writeLines(report, file.path(here, "SOURCE_CHECK.txt"))
cat(paste(report, collapse = "\n"), "\n")
