{smcl}
{* *! version 2.1 28oct2026}{...}
{title:irbcrd -- Improved robust bias correction for RD designs}

{title:Syntax}

{p 8 16 2}
{cmd:irbcrd} {it:y x} {ifin}, {opt h(# [#])}
[{opt c(#)} {opt p(#)} {opt kernel(name [name])} {opt fuzzy(varname)}
{opt kink} {opt covs(varlist)} {opt res(name)} {opt alpha(#)}
{opt bwcheck(#)} {opt fast} {opt boot_ci} {opt boot_b(#)}
{opt boot_seed(#)} {opt boot_wild(name)} {opt boot_keep}
{opt q_method(name)} {opt fuzzy_boot_weights(name)}
{opt gamma_boot_weights(name)} {opt nodisplay}]

{title:Description}

{pstd}
One command provides analytic and bootstrap inference for sharp, fuzzy,
covariate-adjusted sharp, and covariate-adjusted fuzzy RD. Add {cmd:kink}
for slope changes in any design. Covariate-adjusted fuzzy RD adjusts both
outcome and treatment equations. Estimation is native Stata/Mata, requires
Stata 16 or later, and needs no additional package.

{title:Options}

{synoptset 30 tabbed}{...}
{synopthdr:option}
{synoptline}
{synopt:{opt h(# [#])}}Required positive bandwidth; a pair is left, right.{p_end}
{synopt:{opt c(#)}}Cutoff, default 0; x=c is on the right.{p_end}
{synopt:{opt p(#)}}Polynomial order; default 1 for levels, 2 for kinks.{p_end}
{synopt:{opt kernel(name [name])}}tri, epa, or uni; default tri; left/right pair allowed.{p_end}
{synopt:{opt fuzzy(varname)}}Treatment variable; omission selects sharp RD.{p_end}
{synopt:{opt kink}}Slope change instead of level discontinuity; default off.{p_end}
{synopt:{opt covs(varlist)}}Covariates with common coefficients across cutoff sides.{p_end}
{synopt:{opt res(name)}}irbc-hc0..irbc-hc3, cct-hc0..cct-hc3, or loo; default irbc-hc3.{p_end}
{synopt:{opt alpha(#)}}Significance level, default .05 for a 95% interval.{p_end}
{synopt:{opt bwcheck(#)}}Minimum-neighbor rule, default 21; 0 disables it.{p_end}
{synopt:{opt fast}}Asymptotic Q and sharp-design variance shortcut; default off.{p_end}
{synopt:{opt boot_ci}}Add a bootstrap interval; default off.{p_end}
{synopt:{opt boot_b(#)}}Number of draws, default 999; positive integer.{p_end}
{synopt:{opt boot_seed(#)}}Optional RNG seed; no restoration of the previous state.{p_end}
{synopt:{opt boot_wild(name)}}rademacher (default), mammen, or normal.{p_end}
{synopt:{opt boot_keep}}Retain statistic draws and weight diagnostics; default off.{p_end}
{synopt:{opt q_method(name)}}sample or asymptotic; default sample, or asymptotic with fast.{p_end}
{synopt:{opt fuzzy_boot_weights(name)}}fixed (default) or bootstrap; requires fuzzy().{p_end}
{synopt:{opt gamma_boot_weights(name)}}fixed (default) or bootstrap; requires covs().{p_end}
{synopt:{opt nodisplay}}Suppress the table without changing results.{p_end}
{synoptline}

{pstd}
Names follow R's {cmd:iRBCrd()} interface with dots replaced by underscores:
{cmd:boot.ci} becomes {cmd:boot_ci}, {cmd:boot.B} becomes {cmd:boot_b}, and
{cmd:q.method} becomes {cmd:q_method}. Stata flags represent TRUE when
present and FALSE when omitted. {cmd:bwcheck(0)} corresponds to R's
{cmd:bwcheck = NULL}. Full kernel names are accepted. Missing analysis
observations are omitted; {cmd:if} and {cmd:in} restrict the estimation sample.

{title:Bandwidths and data}

{pstd}
Supply a bandwidth selected separately, for example with {cmd:rdbwselect}
using matching fuzzy, covariate, and derivative inputs. Kinks require
{cmd:deriv(1)} and the same polynomial order in that selector. For an
{cmd:rdrobust} comparison with rho=1, use the same h and set b=h there.
Only {cmd:h()} and {cmd:kernel()} specify the side choices.

{pstd}
Regularization counts observations rather than distinct values. Initial
level-RD regularization is pooled for scalar h and separate for paired h;
kinks always regularize separately. Auxiliary fits may enlarge their
bandwidths again. Ties or collinearity can still cause rank failure.
Do not trim the data to the cutoff window: auxiliary fits need observations
outside it. {cmd:e(h)} records the requested pair, while {cmd:e(h_minus)}
and {cmd:e(h_plus)} record effective cutoff bandwidths.

{title:Extensions}

{pstd}
{cmd:kink} estimates the right slope minus the left slope, with p=2 by
default and p>=1 supported. A sharp kink is not divided by a known
policy-schedule slope change; rescale y beforehand for that target.
{cmd:fuzzy()} estimates a ratio of outcome and treatment discontinuities
(or slope changes), correcting the linearized ratio and retaining component
covariance. A first stage near zero prevents ordinary ratio inference.
{cmd:covs()} adjusts the outcome and, when fuzzy, the treatment separately.
Covariate balance requires continuity for level RD and no slope change for
kink RD, alongside the identifying assumptions. These options can be combined.

{title:Bootstrap}

{pstd}
The fixed-regressor wild bootstrap holds bandwidths and Q fixed. Within
the cutoff working window, pointwise fitted levels plus HC-adjusted
residuals times wild multipliers form the bootstrap data. A shared multiplier
preserves dependence across all components of an observation. Observations
outside that window are unchanged. Kink statistics use slope fits, but
bootstrap outcomes and residuals remain in levels.

{pstd}
Fuzzy and covariate combination weights are fixed by default and can be
re-estimated independently. {cmd:fuzzy_boot_weights(bootstrap)} substitutes
the bootstrap first stage in the denominator, keeping the original
outcome-to-treatment ratio fixed. {cmd:gamma_boot_weights(bootstrap)} refits
common covariate coefficients on the bootstrap data, including the treatment
equation when fuzzy. All four combinations are available in adjusted fuzzy
level and kink designs. Singular covariate refits and undefined fuzzy
denominators cause individual draws to be omitted from the interval.

{pstd}
Quantiles use normal((se_irbc/se_us)*invnormal(alpha/2)) and its upper-tail
counterpart, finite draws, and R type-7 interpolation. Inversion is around
the uncorrected jump or ratio. The reportable bootstrap estimate is still
the analytic bias-corrected estimate. An identical numeric seed in R and
Stata does not produce identical draws because the RNGs differ.

{title:Other design choices}

{pstd}
iRBC-HCk residuals subtract an order-p fit centered at each X_i, with no
extra correction of that fitted value. CCT-HCk residuals subtract the
order-(p+1) cutoff polynomial evaluated at X_i. HC0 is unscaled; HC1 divides
by sqrt((n_local-df)/n_local); HC2 by sqrt(1-leverage); HC3 by 1-leverage.
df=p+1 for iRBC and p+2 for CCT. Variance estimation and bootstrap data use
the same residuals. {cmd:hc0}..{cmd:hc3} select iRBC; {cmd:rbc-hc0}..{cmd:rbc-hc3}
select CCT. {cmd:res(loo)} uses unscaled ordinary pointwise-fit residuals.

{pstd}
{cmd:q_method(asymptotic)} retains full variance calculations unless
{cmd:fast} is also supplied. Asymptotic Q requires p=1 for levels and supports
higher orders for kinks. {cmd:fast} implies asymptotic Q and uses a variance
shortcut only for sharp designs; joint designs retain full covariance.

{title:Stored results}

{pstd}
{cmd:e(b)}, {cmd:e(V)}, and {cmd:e(sample)} follow Stata conventions.
{cmd:e(estimate_irbc)}, {cmd:e(se_irbc)}, and {cmd:e(ci_irbc)} are the
primary analytic results. With {cmd:boot_ci}, {cmd:e(estimate_irbc_boot)}
equals the analytic estimate and {cmd:e(ci_irbc_boot)} stores the bootstrap CI.
Both intervals are ordered lower, upper.

{pstd}
Other results include {cmd:e(h)}, {cmd:e(h_minus)}, {cmd:e(h_plus)},
{cmd:e(kernel_minus)}, {cmd:e(kernel_plus)}, {cmd:e(res)}, {cmd:e(p)},
{cmd:e(alpha)}, {cmd:e(kink)}, {cmd:e(design)}, component estimates and
corrections, covariance matrices, and side-specific residuals. Adjusted
designs store covariate coefficients. Kinks store coefficient maps and
pilot bandwidths. R's nested component lists become labeled matrices here.

{pstd}
{cmd:boot_keep} adds {cmd:e(boot_t)}, {cmd:e(boot_t_components)},
{cmd:e(boot_linear_weights)}, and relevant fuzzy/gamma draw diagnostics.
Without it, no bootstrap draws are retained. Large matrices can be accessed
with Mata's {cmd:st_matrix()}. Internal Q and bootstrap calibration inputs
are not exposed as e() results. See README.txt for the complete result list.

{title:Examples}

{phang2}{cmd:. irbcrd y x, h(.6)}{p_end}
{phang2}{cmd:. irbcrd y x, h(.5 .7) kernel(tri epa) res(cct-hc3)}{p_end}
{phang2}{cmd:. irbcrd y x, h(.6) boot_ci boot_b(999) boot_seed(17041998)}{p_end}
{phang2}{cmd:. irbcrd y x, h(.7) kink fuzzy(d) covs(z1 z2)}{p_end}
{phang2}{cmd:. irbcrd y x, h(.7) kink fuzzy(d) covs(z1 z2) boot_ci fuzzy_boot_weights(bootstrap) gamma_boot_weights(bootstrap)}{p_end}

{title:References}

{pstd}
Cavaliere, G., S. Goncalves, M. O. Nielsen, and E. Zanelli (2026).
Improved Inference for Nonparametric Regression and Regression-Discontinuity
Designs. {browse "https://arxiv.org/abs/2512.00566":arXiv:2512.00566}.

{pstd}
Calonico, S., M. D. Cattaneo, M. H. Farrell, and R. Titiunik (2019).
Regression Discontinuity Designs Using Covariates.
Review of Economics and Statistics, 101(3), 442-451.

{title:Authors}

{pstd}
Giuseppe Cavaliere (giuseppe.cavaliere@unibo.it),
Silvia Goncalves (silvia.goncalves@mcgill.ca),
Morten Orregaard Nielsen (mon@econ.au.dk), and
Edoardo Zanelli (ez@econ.au.dk).
