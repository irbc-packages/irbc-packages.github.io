version 16.0
mata:

// iRBCrd 2.1: native Stata/Mata implementation of the R 2.1 specification.

struct irbc_options {
    real scalar cutoff, p, alpha, bwcheck, pooled, fast, kink, fuzzy
    real scalar bootstrap, reps, keep
    real rowvector h
    string rowvector kernel
    string scalar res, q_method, boot_wild, fuzzy_boot_weights, gamma_boot_weights
}

struct irbc_localfit {
    real scalar h, nh
    real colvector weight, leverage
    real colvector active
    real matrix coefficient_weights
}

struct irbc_side {
    real scalar h, hfit, Q, nh
    real colvector a, omega, omega_us
    real colvector bias_weights, pilot_h, boot_active
    real rowvector point, bias
    real matrix residuals, fitted, cov_irbc, cov_us
    real scalar fast_variance
}

struct irbc_result {
    real scalar n, estimate, uncorrected, bias, se, se_us, first_stage
    real scalar mhat, boot_success
    real scalar kink
    real rowvector h, hfit, Q, nh, ci, ci_boot, probs, weights
    real rowvector components, component_bias
    real matrix gamma, cov_irbc, cov_us, residuals, fitted
    real colvector boot_t, boot_first_stage
    real matrix boot_components
    real matrix boot_gamma_y, boot_gamma_d, boot_linear_weights, boot_fuzzy_weights
    real matrix kink_weights_minus, kink_weights_plus
    real colvector pilot_h_minus, pilot_h_plus
    real colvector index_minus, index_plus
    string scalar design
}

real scalar irbc_st_version()
{
    return(210)
}

void irbc_fail(string scalar message)
{
    errprintf("irbcrd: %s\n", message)
    _error(498)
}

real matrix irbc_inverse(real matrix A)
{
    real matrix out
    out = cholinv((A+A')/2)
    if (hasmissing(out)) irbc_fail("A local regression is singular or numerically ill-conditioned.")
    return(out)
}

real scalar irbc_h(real colvector x, real scalar x0,
                   real scalar h, real scalar bwcheck)
{
    real colvector distance
    real scalar j
    if (bwcheck == 0) return(h)
    distance = sort(abs(x:-x0), 1)
    j = min((rows(x), bwcheck))
    if (j == 0) irbc_fail("Observations are required on both sides of the cutoff.")
    return(max((h, distance[j])))
}

real colvector irbc_kernel(real colvector u, string scalar kernel)
{
    real colvector w, at
    w = J(rows(u), 1, 0)
    at = selectindex(abs(u):<=1)
    if (kernel == "tri") w[at] = 1:-abs(u[at])
    else if (kernel == "epa") w[at] = 0.75:*(1:-u[at]:^2)
    else if (kernel == "uni") w[at] = J(rows(at), 1, 0.5)
    else irbc_fail("Unknown kernel.")
    return(w)
}

real matrix irbc_basis(real colvector u, real scalar p)
{
    real matrix R
    real scalar j
    R = J(rows(u), p+1, 1)
    for (j=1; j<=p; j++) R[.,j+1] = u:^j
    return(R)
}

struct irbc_localfit scalar irbc_local(real colvector x, real scalar x0,
    real scalar h, real scalar p, string scalar kernel, real scalar bwcheck)
{
    struct irbc_localfit scalar f
    real matrix R, G
    real colvector w
    f.h = irbc_h(x, x0, h, bwcheck)
    if (f.h <= 0 | f.h >= .) irbc_fail("A local bandwidth is not positive and finite.")
    R = irbc_basis((x:-x0)/f.h, p)
    w = irbc_kernel((x:-x0)/f.h, kernel)/f.h
    f.nh = sum(w:>0)
    f.active = selectindex(w:>0)
    if (f.nh < p+1) irbc_fail("Too few positive-kernel observations for a local regression.")
    G = irbc_inverse(cross(R, w, R))
    f.coefficient_weights = (w:*R)*G
    f.weight = f.coefficient_weights[.,1]
    f.leverage = rowsum((R*G):*(w:*R))
    if (hasmissing(f.weight)) irbc_fail("Nonfinite local-polynomial weights.")
    return(f)
}

real scalar irbc_Q(string scalar kernel)
{
    if (kernel == "tri") return(1.4082)
    if (kernel == "epa") return(1.3571)
    return(1.2)
}

real matrix irbc_hc(real matrix raw, real colvector leverage,
                    real colvector nh, real scalar df, real scalar hc)
{
    real colvector adjust
    if (hc == 0) return(raw)
    if (hc == 1) adjust = (nh:-df):/nh
    else adjust = 1:-leverage
    if (hasmissing(adjust) | min(adjust)<=0) {
        irbc_fail("HC adjustment is undefined: insufficient support or leverage at least one.")
    }
    if (hc == 1 | hc == 2) adjust = sqrt(adjust)
    return(raw:/adjust)
}

struct irbc_side scalar irbc_build_side(real colvector x, real matrix Y,
    real scalar h, string scalar kernel, struct irbc_options scalar o)
{
    struct irbc_side scalar s
    struct irbc_localfit scalar f0, fi, fq
    real scalar n, k, j, hc, denominator, factor
    real colvector bias_active, residual_active, needed, at
    real colvector C, lev, nh, rbc_weight
    real matrix bias_fitted, weighted

    n = rows(x)
    k = cols(Y)
    s.h = h
    f0 = irbc_local(x, o.cutoff, h, o.p, kernel, o.bwcheck)
    s.hfit = f0.h
    s.a = f0.weight
    s.nh = f0.nh
    s.point = s.a'*Y
    s.fitted = J(n,k,0)
    C = J(n,1,0)
    lev = nh = J(n,1,.)
    bias_active = abs(x:-o.cutoff):<2*h
    residual_active = abs(x:-o.cutoff):<=2*s.hfit
    needed = bias_active :| (abs(x:-o.cutoff):<=s.hfit)
    if (substr(o.res,1,5) == "irbc-") needed = needed :| residual_active
    at = selectindex(needed)

    for (j=1; j<=rows(at); j++) {
        fi = irbc_local(x, x[at[j]], h, o.p, kernel, o.bwcheck)
        s.fitted[at[j],.] = fi.weight'*Y
        lev[at[j]] = fi.weight[at[j]]
        nh[at[j]] = fi.nh
        if (bias_active[at[j]]) {
            if (o.q_method == "sample") {
                C[at[j]] = fi.weight'*(((x:-x[at[j]])/h):^(o.p+1))
            }
        }
    }

    if (o.q_method == "sample") {
        denominator = s.a'*C
        if (denominator == 0 | denominator >= .) irbc_fail("The sample Q denominator is zero or nonfinite.")
        s.Q = (s.a'*(((x:-o.cutoff)/h):^(o.p+1)))/denominator
    }
    else s.Q = irbc_Q(kernel)
    if (missing(s.Q)) irbc_fail("The Q adjustment is not finite.")

    bias_fitted = s.fitted:*bias_active
    s.bias = s.Q*(s.a'*(bias_fitted:-s.point))

    if (o.res == "loo") s.residuals = Y-bias_fitted
    else {
        hc = strtoreal(substr(o.res,strlen(o.res),1))
        if (substr(o.res,1,4) == "cct-") {
            // CCT residuals use the reported cutoff h, without another enlargement.
            fq = irbc_local(x, o.cutoff, h, o.p+1, kernel, 0)
            weighted = irbc_basis((x:-o.cutoff)/h,o.p+1)*(fq.coefficient_weights'*Y)
            s.residuals = irbc_hc(Y-weighted, fq.leverage,
                                  J(n,1,fq.nh),o.p+2,hc)
        }
        else {
            s.residuals = J(n,k,0)
            at = selectindex(residual_active)
            s.residuals[at,.] = irbc_hc(Y[at,.]-s.fitted[at,.],
                                       lev[at],nh[at],o.p+1,hc)
        }
    }
    if (hasmissing(s.residuals)) irbc_fail("Nonfinite residuals.")

    // Preserve R's level-RD auxiliary-bandwidth scaling in the variance weights.
    s.omega = (1+s.Q)*s.a
    at = selectindex(abs(x:-o.cutoff):<=s.hfit)
    for (j=1; j<=rows(at); j++) {
        fi = irbc_local(x, x[at[j]], s.hfit, o.p, kernel, o.bwcheck)
        s.omega = s.omega-s.Q*s.a[at[j]]*(fi.h/s.hfit)*fi.weight
    }
    s.omega = s.omega:*(abs(x:-o.cutoff):<=2*s.hfit)
    s.omega_us = s.Q*s.a
    weighted = s.residuals:*s.omega
    s.cov_irbc = cross(weighted,weighted)
    weighted = s.residuals:*s.omega_us
    s.cov_us = cross(weighted,weighted)
    s.fast_variance = .
    if (o.fast & k == 1) {
        fq = irbc_local(x,o.cutoff,s.hfit,o.p+1,kernel,0)
        rbc_weight = s.a-(s.a'*(((x:-o.cutoff)/s.hfit):^(o.p+1)))*
                     fq.coefficient_weights[.,o.p+2]
        factor = 0.86
        if (kernel == "tri") factor = 0.84
        if (kernel == "epa") factor = 0.83
        s.fast_variance = factor^2*sum((rbc_weight:*s.residuals):^2)
    }
    return(s)
}

struct irbc_localfit scalar irbc_kink_local(real colvector x, real scalar x0,
    real scalar h, real scalar p, string scalar kernel, real scalar bwcheck,
    real scalar derivative)
{
    struct irbc_localfit scalar f
    real colvector w, sw
    real rowvector tau, pivot
    real matrix R, H, R1, Q1, map
    f.h = irbc_h(x,x0,h,bwcheck)
    if (f.h<=0 | f.h>=.) irbc_fail("A kink bandwidth is not positive and finite.")
    w = irbc_kernel((x:-x0)/f.h,kernel)
    f.active = selectindex(w:>0)
    f.nh = rows(f.active)
    if (f.nh<p+1) irbc_fail("Too few positive-weight observations for a kink local fit.")
    R = irbc_basis((x[f.active]:-x0)/f.h,p)
    sw = sqrt(w[f.active])
    pivot = .
    hqrdp(R:*sw,H,tau,R1,pivot)
    if (hasmissing(R1) | min(abs(diagonal(R1)))<=1e-10*max(abs(diagonal(R1)))) {
        irbc_fail("A kink local-polynomial fit is rank deficient; inspect ties or increase h.")
    }
    Q1 = hqrdq1(H,tau)
    map = solveupper(R1,Q1'):*sw'
    map = map[invorder(pivot),.]
    f.coefficient_weights = J(rows(x),p+1,0)
    f.coefficient_weights[f.active,.] = map'
    f.weight = f.coefficient_weights[.,derivative+1]/f.h^derivative
    f.leverage = J(rows(x),1,0)
    f.leverage[f.active] = rowsum(Q1:^2)
    if (hasmissing(map)) irbc_fail("Nonfinite kink local-polynomial weights.")
    return(f)
}

real matrix irbc_kink_moments(real colvector t, real scalar order,
                             string scalar kernel)
{
    real rowvector coefficient
    real matrix ans
    real scalar j, k, power
    coefficient = (1,-1)
    if (kernel=="epa") coefficient = (.75,0,-.75)
    if (kernel=="uni") coefficient = .5
    ans = J(rows(t),order+1,0)
    for (j=0; j<=order; j++) for (k=1; k<=cols(coefficient); k++) {
        power = j+k
        ans[.,j+1] = ans[.,j+1]+coefficient[k]*(1:+(-1)^j*t:^power)/power
    }
    return(ans)
}

real matrix irbc_moment_gram(real rowvector moments, real scalar p)
{
    real matrix G
    real scalar i, j
    G = J(p+1,p+1,.)
    for (i=0; i<=p; i++) for (j=0; j<=p; j++) G[i+1,j+1] = moments[i+j+1]
    return(G)
}

real matrix irbc_kink_pilot_beta(real colvector t, real scalar p, string scalar kernel)
{
    real matrix moments, beta
    real colvector e0
    real scalar j
    moments = irbc_kink_moments(t,2*p,kernel)
    e0 = J(p+1,1,0)
    e0[1] = 1
    beta = J(rows(t),p+1,.)
    for (j=1; j<=rows(t); j++) beta[j,.] = (irbc_inverse(irbc_moment_gram(moments[j,.],p))*e0)'
    return(beta)
}

real colvector irbc_kink_equivalent(real colvector u, real colvector beta,
                                   real scalar p, string scalar kernel)
{
    return((irbc_basis(u,p)*beta):*irbc_kernel(u,kernel):*(u:>=0):*(u:<=1))
}

irbc_kink_constant_cache = J(0,5,.)

real rowvector irbc_kink_constants(string scalar kernel, real scalar p, real scalar want_ratio)
{
    external real matrix irbc_kink_constant_cache
    real scalar code, j, i, a, b, C, Clp, Q, ratio, point, convolution_value
    real matrix Jq, vectors, rule, moments, pilot, beta_pilot
    real rowvector eigenvalues, m0
    real colvector hit, e1, beta, betaq, x01, w01, u, uw, convolution, cuts, t, v, tw, corrected, rb
    code = 1
    if (kernel=="epa") code = 2
    if (kernel=="uni") code = 3
    hit = selectindex((irbc_kink_constant_cache[.,1]:==code):&
                     (irbc_kink_constant_cache[.,2]:==p):&
                     (irbc_kink_constant_cache[.,3]:==want_ratio))
    if (length(hit)) return(irbc_kink_constant_cache[hit[1],4..5])

    // The same 64-point Gauss-Legendre rule and split convolution as R 2.1.
    Jq = J(64,64,0)
    for (j=1; j<64; j++) Jq[j,j+1] = Jq[j+1,j] = j/sqrt(4*j^2-1)
    symeigensystem(Jq,vectors,eigenvalues)
    rule = (eigenvalues',vectors[1,.]':^2)
    x01 = (1:+rule[.,1])/2
    w01 = rule[.,2]
    m0 = irbc_kink_moments(0,2*p+2,kernel)
    e1 = J(p+1,1,0)
    e1[2] = 1
    beta = irbc_inverse(irbc_moment_gram(m0,p))*e1
    C = sum(beta:*m0[(p+2)..(2*p+2)]')
    moments = irbc_kink_moments(x01,2*p+1,kernel)
    pilot = irbc_kink_pilot_beta(x01,p,kernel)
    Clp = sum(irbc_kink_equivalent(x01,beta,p,kernel):*w01:*
               rowsum(pilot:*moments[.,(p+2)..(2*p+2)]))
    if (abs(Clp)<1e-12 | Clp>=.) irbc_fail("The population kink bias constant is numerically zero.")
    Q = C/Clp
    ratio = .
    if (want_ratio) {
        u = x01 \ (1:+x01)
        uw = w01 \ w01
        convolution = J(rows(u),1,0)
        for (i=1; i<=rows(u); i++) {
            point = u[i]
            cuts = uniqrows(sort((max((0,point-1)) \ min((1,point)) \ 1),1))
            convolution_value = 0
            for (j=1; j<rows(cuts); j++) {
                a = cuts[j]
                b = cuts[j+1]
                t = (a+b)/2:+(b-a)*rule[.,1]/2
                tw = (b-a)*rule[.,2]
                v = point:-t
                beta_pilot = irbc_kink_pilot_beta(t,p,kernel)
                convolution_value = convolution_value+
                    sum(irbc_kink_equivalent(t,beta,p,kernel):*tw:*
                        rowsum(beta_pilot:*irbc_basis(v,p)):*irbc_kernel(v,kernel))
            }
            convolution[i] = convolution_value
        }
        corrected = (1+Q)*irbc_kink_equivalent(u,beta,p,kernel)-Q*convolution
        e1 = J(p+2,1,0)
        e1[2] = 1
        betaq = irbc_inverse(irbc_moment_gram(m0,p+1))*e1
        rb = irbc_kink_equivalent(x01,betaq,p+1,kernel)
        ratio = sqrt(sum(corrected:^2:*uw)/sum(rb:^2:*w01))
    }
    irbc_kink_constant_cache = irbc_kink_constant_cache \ (code,p,want_ratio,Q,ratio)
    return((Q,ratio))
}

struct irbc_side scalar irbc_build_kink_side(real colvector x, real matrix Y,
    real scalar h, string scalar kernel, struct irbc_options scalar o)
{
    struct irbc_side scalar s
    struct irbc_localfit scalar f0, fi, fq
    real scalar n, k, j, at, C, Clp, hc
    real colvector convolution, leading, active
    real rowvector constants
    real matrix weighted, prediction
    n = rows(x)
    k = cols(Y)
    f0 = irbc_kink_local(x,o.cutoff,h,o.p,kernel,o.bwcheck,1)
    s.h = s.hfit = h = f0.h
    s.a = f0.weight
    s.nh = f0.nh
    s.boot_active = f0.active
    s.pilot_h = J(n,1,.)
    s.fitted = J(n,k,0)
    convolution = J(n,1,0)
    for (j=1; j<=rows(f0.active); j++) {
        at = f0.active[j]
        fi = irbc_kink_local(x,x[at],h,o.p,kernel,o.bwcheck,0)
        convolution = convolution+s.a[at]*fi.weight
        s.fitted[at,.] = fi.weight'*Y
        s.pilot_h[at] = fi.h
    }
    s.bias_weights = convolution-s.a
    leading = ((x:-o.cutoff)/h):^(o.p+1)
    C = sum(s.a:*leading)
    Clp = sum(s.bias_weights:*leading)
    if (o.q_method=="sample") {
        if (Clp>=. | abs(Clp)<=1e-10*max((sum(abs(s.bias_weights:*leading)),2.220446049250313e-16))) {
            irbc_fail("The sample kink bias constant is numerically zero; inspect the design or bandwidth.")
        }
        s.Q = C/Clp
    }
    else {
        constants = irbc_kink_constants(kernel,o.p,o.fast & k==1)
        s.Q = constants[1]
    }
    s.point = s.a'*Y
    s.bias = s.Q*s.bias_weights'*Y
    s.omega = s.a-s.Q*s.bias_weights
    s.omega_us = s.Q*s.a
    active = selectindex((s.omega:!=0):|(s.a:!=0))
    s.residuals = J(n,k,0)
    hc = strtoreal(substr(o.res,strlen(o.res),1))
    if (substr(o.res,1,4)=="cct-") {
        fq = irbc_kink_local(x,o.cutoff,h,o.p+1,kernel,0,0)
        prediction = irbc_basis((x[active]:-o.cutoff)/h,o.p+1)*(fq.coefficient_weights'*Y)
        s.residuals[active,.] = irbc_hc(Y[active,.]-prediction,
            fq.leverage[active],J(rows(active),1,fq.nh),o.p+2,hc)
    }
    else for (j=1; j<=rows(active); j++) {
        at = active[j]
        fi = irbc_kink_local(x,x[at],h,o.p,kernel,o.bwcheck,0)
        weighted = Y[at,.]-fi.weight'*Y
        if (o.res!="loo") weighted = irbc_hc(weighted,fi.leverage[at],fi.nh,o.p+1,hc)
        s.residuals[at,.] = weighted
    }
    if (hasmissing(s.residuals)) irbc_fail("Kink residuals contain nonfinite values.")
    weighted = s.residuals:*s.omega
    s.cov_irbc = cross(weighted,weighted)
    weighted = s.residuals:*s.omega_us
    s.cov_us = cross(weighted,weighted)
    s.fast_variance = .
    if (o.fast & k==1) {
        fq = irbc_kink_local(x,o.cutoff,h,o.p+1,kernel,0,1)
        s.fast_variance = sum((fq.weight:*s.residuals):^2)*constants[2]^2
        s.cov_irbc = s.fast_variance
    }
    return(s)
}

real matrix irbc_gamma_terms(real colvector x, real matrix Y, real matrix Z,
    real scalar h, string scalar kernel, struct irbc_options scalar o)
{
    real colvector w, at
    real matrix R, G, UZ, UY, zz, zy
    w = irbc_kernel((x:-o.cutoff)/h,kernel)/h
    at = selectindex(w:>0)
    if (rows(at)<=o.p+1) irbc_fail("Insufficient support for common-slope covariate adjustment.")
    R = irbc_basis((x[at]:-o.cutoff)/h,o.p)
    G = irbc_inverse(cross(R,w[at],R))
    UZ = cross(R,w[at],Z[at,.])
    UY = cross(R,w[at],Y[at,.])
    zz = cross(Z[at,.],w[at],Z[at,.])-UZ'*G*UZ
    zy = cross(Z[at,.],w[at],Y[at,.])-UZ'*G*UY
    return((zz,zy))
}

real scalar irbc_se(real matrix V, real rowvector w)
{
    real scalar v
    v = w*V*w'
    if (v<0 & v > -1e-12) v = 0
    if (v<0 | v>=.) irbc_fail("A variance could not be computed.")
    return(sqrt(v))
}

real matrix irbc_gamma_refit(real colvector x, real matrix Y,
    real colvector il, real colvector ir, real scalar hl, real scalar hr,
    struct irbc_options scalar o)
{
    real scalar nf, nz
    real matrix terms, A, inverse, gamma
    nf = 1+o.fuzzy
    nz = cols(Y)-nf
    terms = irbc_gamma_terms(x[il],Y[il,1..nf],Y[il,(nf+1)..cols(Y)],hl,o.kernel[1],o)+
            irbc_gamma_terms(x[ir],Y[ir,1..nf],Y[ir,(nf+1)..cols(Y)],hr,o.kernel[2],o)
    A = terms[.,1..nz]
    inverse = cholinv((A+A')/2)
    if (hasmissing(inverse)) return(J(nz,nf,.))
    gamma = inverse*terms[.,(nz+1)..(nz+nf)]
    return(gamma)
}

real scalar irbc_quantile(real colvector values, real scalar probability)
{
    real colvector v
    real scalar index, lo, hi
    v = sort(select(values,values:<.),1)
    if (rows(v)<2) return(.)
    index = 1+(rows(v)-1)*probability
    lo = max((1,floor(index)))
    hi = min((rows(v),lo+1))
    return(v[lo]+(index-lo)*(v[hi]-v[lo]))
}

real colvector irbc_wild(real scalar n, string scalar wild)
{
    real scalar a, b, pa
    if (wild == "normal") return(rnormal(n,1,0,1))
    if (wild == "rademacher") return(2*(runiform(n,1):>=0.5):-1)
    a = (1-sqrt(5))/2
    b = (1+sqrt(5))/2
    pa = (sqrt(5)+1)/(2*sqrt(5))
    return(a:+(b-a)*(runiform(n,1):>=pa))
}

struct irbc_result scalar irbc_compute(real colvector x, real matrix Y,
    struct irbc_options scalar o, real matrix drawmatrix)
{
    struct irbc_result scalar r
    struct irbc_side scalar L, R
    real colvector il, ir, boot_local, at, multipliers
    real matrix Z, U, A, gamma_terms, delta, centered, gamma_boot
    real rowvector t, w, td, wy, wd, wy_use, wd_use, w_use, fw, fw_use
    real scalar n, k, nz, nf, hl, hr, bb, yl, dl, dboot, critical

    n = rows(x)
    k = cols(Y)
    nf = 1+o.fuzzy
    nz = k-nf
    if (n<1 | rows(Y)!=n | k<nf | hasmissing(x) | hasmissing(Y)) {
        irbc_fail("Data must be conformable, finite, and nonempty.")
    }
    il = selectindex(x:<o.cutoff)
    ir = selectindex(x:>=o.cutoff)
    if (!rows(il) | !rows(ir)) irbc_fail("Observations are required on both sides of the cutoff.")
    if (o.pooled & !o.kink) hl = hr = irbc_h(x,o.cutoff,o.h[1],o.bwcheck)
    else {
        hl = irbc_h(x[il],o.cutoff,o.h[1],o.bwcheck)
        hr = irbc_h(x[ir],o.cutoff,o.h[2],o.bwcheck)
    }
    if (o.kink) {
        L = irbc_build_kink_side(x[il],Y[il,.],hl,o.kernel[1],o)
        R = irbc_build_kink_side(x[ir],Y[ir,.],hr,o.kernel[2],o)
        hl = L.h
        hr = R.h
    }
    else {
        L = irbc_build_side(x[il],Y[il,.],hl,o.kernel[1],o)
        R = irbc_build_side(x[ir],Y[ir,.],hr,o.kernel[2],o)
    }
    r.n = n
    r.index_minus = il
    r.index_plus = ir
    r.kink = o.kink
    r.h = (hl,hr)
    r.hfit = (L.hfit,R.hfit)
    r.Q = (L.Q,R.Q)
    r.nh = (L.nh,R.nh)
    r.components = R.point-L.point
    r.component_bias = R.bias-L.bias
    r.gamma = J(0,nf,.)
    wy = (1,J(1,k-1,0))
    wd = J(1,k,0)
    if (o.fuzzy) wd[2] = 1
    if (nz>0) {
        Z = Y[.,(nf+1)..k]
        U = Y[.,1..nf]
        gamma_terms = irbc_gamma_terms(x[il],U[il,.],Z[il,.],hl,o.kernel[1],o)+
                      irbc_gamma_terms(x[ir],U[ir,.],Z[ir,.],hr,o.kernel[2],o)
        A = gamma_terms[.,1..nz]
        r.gamma = irbc_inverse(A)*gamma_terms[.,(nz+1)..(nz+nf)]
        wy[(nf+1)..k] = -r.gamma[.,1]'
        if (o.fuzzy) wd[(nf+1)..k] = -r.gamma[.,2]'
    }
    yl = wy*r.components'
    r.first_stage = .
    if (o.fuzzy) {
        dl = wd*r.components'
        if (abs(dl)<=1.4901161193847656e-8 | abs(dl)>=.) {
            irbc_fail("The adjusted first-stage discontinuity is too close to zero.")
        }
        r.first_stage = dl
        r.uncorrected = yl/dl
        fw = (1/dl,-yl/(dl^2))
        w = fw[1]*wy+fw[2]*wd
        r.design = "fuzzy"
        if (nz>0) r.design = "covariate-adjusted fuzzy"
    }
    else {
        r.uncorrected = yl
        w = wy
        r.design = "sharp"
        if (nz>0) r.design = "covariate-adjusted sharp"
    }
    if (o.kink) r.design = r.design+" kink"
    r.weights = w
    r.bias = w*r.component_bias'
    r.estimate = r.uncorrected-r.bias
    r.cov_irbc = L.cov_irbc+R.cov_irbc
    r.cov_us = L.cov_us+R.cov_us
    r.se = irbc_se(r.cov_irbc,w)
    // Level sharp RD divides by reported h after the side bandwidth recheck.
    if (!o.kink & !o.fast & k==1) r.se = sqrt(L.cov_irbc[1,1]*L.hfit/hl+R.cov_irbc[1,1]*R.hfit/hr)
    if (o.fast & k==1) r.se = sqrt(L.fast_variance+R.fast_variance)
    r.se_us = irbc_se(r.cov_us,w)
    critical = invnormal(1-o.alpha/2)
    r.ci = r.estimate:+(-critical,critical)*r.se
    r.residuals = r.fitted = J(n,k,0)
    r.residuals[il,.] = L.residuals
    r.residuals[ir,.] = R.residuals
    r.fitted[il,.] = L.fitted
    r.fitted[ir,.] = R.fitted
    r.boot_t = r.boot_first_stage = J(0,1,.)
    r.boot_components = J(0,k,.)
    r.boot_gamma_y = r.boot_gamma_d = J(0,nz,.)
    r.boot_linear_weights = J(0,k,.)
    r.boot_fuzzy_weights = J(0,2,.)
    r.kink_weights_minus = r.kink_weights_plus = J(0,3,.)
    r.pilot_h_minus = r.pilot_h_plus = J(0,1,.)
    if (o.kink) {
        r.kink_weights_minus = (L.a,L.bias_weights,L.omega)
        r.kink_weights_plus = (R.a,R.bias_weights,R.omega)
        r.pilot_h_minus = L.pilot_h
        r.pilot_h_plus = R.pilot_h
    }
    r.ci_boot = r.probs = J(1,2,.)
    r.mhat = .
    r.boot_success = 0
    if (!o.bootstrap) return(r)

    if (r.se_us<=0 | r.se_us>=. | r.se<=0 | r.se>=.) {
        irbc_fail("Bootstrap calibration requires positive finite standard errors.")
    }
    r.mhat = r.se/r.se_us
    r.probs = normal(r.mhat*(-critical,critical))
    // The R sharp routine rechecks side bandwidths; joint routines use reported h.
    boot_local = J(n,1,0)
    if (o.kink) {
        boot_local[il[L.boot_active]] = J(rows(L.boot_active),1,1)
        boot_local[ir[R.boot_active]] = J(rows(R.boot_active),1,1)
    }
    else if (k==1) {
        boot_local[il] = abs(x[il]:-o.cutoff):<=L.hfit
        boot_local[ir] = abs(x[ir]:-o.cutoff):<=R.hfit
    }
    else {
        boot_local[il] = abs(x[il]:-o.cutoff):<=hl
        boot_local[ir] = abs(x[ir]:-o.cutoff):<=hr
    }
    if (!sum(boot_local[il]) | !sum(boot_local[ir])) irbc_fail("No bootstrap observations on one side.")
    at = selectindex(boot_local)
    if (rows(drawmatrix)>0) {
        if (rows(drawmatrix)!=n | cols(drawmatrix)!=o.reps | hasmissing(drawmatrix)) {
            irbc_fail("drawmatrix must have one row per selected observation and reps columns, all finite.")
        }
    }
    r.boot_t = r.boot_first_stage = J(o.reps,1,.)
    r.boot_components = J(o.reps,k,.)
    if (o.keep) {
        r.boot_linear_weights = J(o.reps,k,.)
        if (nz>0) r.boot_gamma_y = r.boot_gamma_d = J(o.reps,nz,.)
        if (o.fuzzy) r.boot_fuzzy_weights = J(o.reps,2,.)
    }
    centered = r.fitted-Y
    for (bb=1; bb<=o.reps; bb++) {
        if (rows(drawmatrix)>0) multipliers = drawmatrix[at,bb]
        else multipliers = irbc_wild(rows(at),o.boot_wild)
        delta = J(n,k,0)
        delta[at,.] = centered[at,.]+r.residuals[at,.]:*multipliers
        td = R.a'*delta[ir,.]-L.a'*delta[il,.]
        t = R.Q*(R.a'*delta[ir,.])-L.Q*(L.a'*delta[il,.])
        r.boot_components[bb,.] = t
        wy_use = wy
        wd_use = wd
        if (nz>0 & o.gamma_boot_weights=="bootstrap") {
            gamma_boot = irbc_gamma_refit(x,Y+delta,il,ir,hl,hr,o)
            if (hasmissing(gamma_boot)) continue
            wy_use[(nf+1)..k] = -gamma_boot[.,1]'
            if (o.fuzzy) wd_use[(nf+1)..k] = -gamma_boot[.,2]'
        }
        w_use = wy_use
        if (o.fuzzy) {
            fw_use = fw
            dboot = wd_use*(r.components+td)'
            r.boot_first_stage[bb] = dboot
            if (o.fuzzy_boot_weights=="bootstrap") {
                if (abs(dboot)<=1.4901161193847656e-8 | abs(dboot)>=.) continue
                // Retain the original ratio; only the starred denominator changes.
                fw_use = (1/dboot,-yl/(dl*dboot))
            }
            w_use = fw_use[1]*wy_use+fw_use[2]*wd_use
        }
        if (hasmissing(t) | hasmissing(w_use)) continue
        r.boot_t[bb] = t*w_use'
        if (o.keep) {
            r.boot_linear_weights[bb,.] = w_use
            if (o.fuzzy) r.boot_fuzzy_weights[bb,.] = fw_use
            if (nz>0) {
                r.boot_gamma_y[bb,.] = -wy_use[(nf+1)..k]
                if (o.fuzzy) r.boot_gamma_d[bb,.] = -wd_use[(nf+1)..k]
            }
        }
    }
    r.boot_success = sum(r.boot_t:<.)
    if (r.boot_success>=2) {
        r.ci_boot = (r.uncorrected-irbc_quantile(r.boot_t,r.probs[2]),
                     r.uncorrected-irbc_quantile(r.boot_t,r.probs[1]))
    }
    if (!o.keep) {
        r.boot_t = r.boot_first_stage = J(0,1,.)
        r.boot_components = J(0,k,.)
    }
    return(r)
}

void irbc_stata(string scalar yname, string scalar xname,
    string scalar dname, string scalar znames, string scalar touse,
    string scalar bname, string scalar vname)
{
    external struct irbc_result scalar irbc_last
    struct irbc_options scalar o
    real colvector x
    real matrix Y, D
    string rowvector names
    o.cutoff = strtoreal(st_local("c"))
    o.p = strtoreal(st_local("p"))
    o.alpha = strtoreal(st_local("alpha"))
    o.bwcheck = strtoreal(st_local("bwcheck"))
    o.pooled = strtoreal(st_local("pooled"))
    o.fast = st_local("fast")!=""
    o.kink = st_local("kink")!=""
    o.fuzzy = dname!=""
    o.bootstrap = st_local("boot_ci")!=""
    o.reps = strtoreal(st_local("boot_b"))
    o.keep = st_local("boot_keep")!=""
    o.h = (strtoreal(st_local("hl")),strtoreal(st_local("hr")))
    o.kernel = (st_local("kl"),st_local("kr"))
    o.res = st_local("res")
    o.q_method = st_local("q_method")
    o.boot_wild = st_local("boot_wild")
    o.fuzzy_boot_weights = st_local("fuzzy_boot_weights")
    o.gamma_boot_weights = st_local("gamma_boot_weights")
    names = tokens(yname+" "+dname+" "+znames)
    x = st_data(.,xname,touse)
    Y = st_data(.,names,touse)
    D = J(0,0,.)
    irbc_last = irbc_compute(x,Y,o,D)
    st_matrix(bname,irbc_last.estimate)
    st_matrix(vname,irbc_last.se^2)
}

void irbc_post()
{
    external struct irbc_result scalar irbc_last
    real matrix table
    real scalar fuzzy, nz
    string colvector rn, components, z_names
    components = tokens(st_local("y")+" "+st_local("fuzzy")+" "+st_local("covs"))'
    z_names = tokens(st_local("covs"))'
    fuzzy = st_local("fuzzy")!=""
    nz = rows(z_names)
    st_numscalar("e(estimate_irbc)",irbc_last.estimate)
    if (fuzzy) {
        st_numscalar("e(zeta_hat)",irbc_last.uncorrected)
        st_numscalar("e(zeta_hat_irbc)",irbc_last.estimate)
        st_numscalar("e(first_stage)",irbc_last.first_stage)
    }
    else {
        st_numscalar("e(tau_hat)",irbc_last.uncorrected)
        st_numscalar("e(tau_hat_irbc)",irbc_last.estimate)
    }
    st_numscalar("e(bias_irbc)",irbc_last.bias)
    st_numscalar("e(se_irbc)",irbc_last.se)
    st_numscalar("e(se_us)",irbc_last.se_us)
    st_matrix("e(ci_irbc)",irbc_last.ci)
    st_numscalar("e(h_minus)",irbc_last.h[1])
    st_numscalar("e(h_plus)",irbc_last.h[2])
    st_matrix("e(N_h)",irbc_last.nh)
    st_matrix("e(component_estimates)",irbc_last.components)
    st_matrix("e(component_bias)",irbc_last.component_bias)
    st_matrix("e(component_estimates_irbc)",irbc_last.components-irbc_last.component_bias)
    st_matrix("e(linear_weights)",irbc_last.weights)
    st_matrix("e(cov_irbc)",irbc_last.cov_irbc)
    st_matrix("e(cov_us)",irbc_last.cov_us)
    st_matrix("e(epshat_minus)",irbc_last.residuals[irbc_last.index_minus,.])
    st_matrix("e(epshat_plus)",irbc_last.residuals[irbc_last.index_plus,.])
    st_matrixcolstripe("e(component_estimates)",(J(rows(components),1,""),components))
    st_matrixcolstripe("e(component_estimates_irbc)",(J(rows(components),1,""),components))
    st_matrixcolstripe("e(component_bias)",(J(rows(components),1,""),components))
    st_matrixcolstripe("e(linear_weights)",(J(rows(components),1,""),components))
    st_matrixcolstripe("e(cov_irbc)",(J(rows(components),1,""),components))
    st_matrixrowstripe("e(cov_irbc)",(J(rows(components),1,""),components))
    st_matrixcolstripe("e(cov_us)",(J(rows(components),1,""),components))
    st_matrixrowstripe("e(cov_us)",(J(rows(components),1,""),components))
    st_matrixcolstripe("e(epshat_minus)",(J(rows(components),1,""),components))
    st_matrixcolstripe("e(epshat_plus)",(J(rows(components),1,""),components))
    if (nz) {
        if (fuzzy) {
            st_matrix("e(gamma_y_hat)",irbc_last.gamma[.,1]')
            st_matrix("e(gamma_d_hat)",irbc_last.gamma[.,2]')
            st_matrixcolstripe("e(gamma_y_hat)",(J(nz,1,""),z_names))
            st_matrixcolstripe("e(gamma_d_hat)",(J(nz,1,""),z_names))
        }
        else {
            st_matrix("e(gamma_hat)",irbc_last.gamma')
            st_matrixcolstripe("e(gamma_hat)",(J(nz,1,""),z_names))
        }
    }
    if (irbc_last.kink) {
        st_matrix("e(kink_weights_minus)",irbc_last.kink_weights_minus)
        st_matrix("e(kink_weights_plus)",irbc_last.kink_weights_plus)
        st_matrix("e(pilot_h_minus)",irbc_last.pilot_h_minus)
        st_matrix("e(pilot_h_plus)",irbc_last.pilot_h_plus)
        st_matrixcolstripe("e(kink_weights_minus)",(J(3,1,""),("slope"\"bias"\"corrected")))
        st_matrixcolstripe("e(kink_weights_plus)",(J(3,1,""),("slope"\"bias"\"corrected")))
    }
    st_global("e(design)",irbc_last.design)
    table = (irbc_last.estimate,irbc_last.se,irbc_last.ci)
    rn = "iRBC"
    if (st_local("boot_ci")!="") {
        st_numscalar("e(estimate_irbc_boot)",irbc_last.estimate)
        st_matrix("e(ci_irbc_boot)",irbc_last.ci_boot)
        st_local("boot_insufficient",strofreal(irbc_last.boot_success<2))
        if (st_local("boot_keep")!="") {
            st_matrix("e(boot_t)",irbc_last.boot_t)
            st_matrix("e(boot_t_components)",irbc_last.boot_components)
            st_matrix("e(boot_linear_weights)",irbc_last.boot_linear_weights)
            st_matrixcolstripe("e(boot_t_components)",(J(rows(components),1,""),components))
            st_matrixcolstripe("e(boot_linear_weights)",(J(rows(components),1,""),components))
            if (fuzzy) {
                st_matrix("e(boot_adjusted_first_stage)",irbc_last.boot_first_stage)
                st_matrix("e(boot_fuzzy_weights)",irbc_last.boot_fuzzy_weights)
                st_matrixcolstripe("e(boot_fuzzy_weights)",(J(2,1,""),("reduced_form"\"first_stage")))
            }
            if (nz) {
                if (fuzzy) {
                    st_matrix("e(boot_gamma_y)",irbc_last.boot_gamma_y)
                    st_matrix("e(boot_gamma_d)",irbc_last.boot_gamma_d)
                    st_matrixcolstripe("e(boot_gamma_y)",(J(nz,1,""),z_names))
                    st_matrixcolstripe("e(boot_gamma_d)",(J(nz,1,""),z_names))
                }
                else {
                    st_matrix("e(boot_gamma)",irbc_last.boot_gamma_y)
                    st_matrixcolstripe("e(boot_gamma)",(J(nz,1,""),z_names))
                }
            }
        }
        table = table \ (irbc_last.estimate,.,irbc_last.ci_boot)
        rn = rn \ "iRBC_boot"
    }
    st_matrix("e(table_irbc)",table)
    st_matrixrowstripe("e(table_irbc)",(J(rows(rn),1,""),rn))
    st_matrixcolstripe("e(table_irbc)",(J(4,1,""),("Estimate"\"Analytic_SE"\"CI_lower"\"CI_upper")))
}

end
