# Package the local source only. Do not invoke Stata or publish to the website.
main <- function() {
  arg <- grep("^--file=", commandArgs(), value = TRUE)
  root <- if (length(arg)) dirname(normalizePath(sub("^--file=", "", arg[1]))) else normalizePath(".")
  old <- setwd(root)
  on.exit(setwd(old), add = TRUE)
  manifest <- readLines("irbcrd.pkg", warn = FALSE)
  files <- c(sub("^f +", "", manifest[grepl("^f +", manifest)]), "irbcrd.pkg", "stata.toc",
             "prepare_download.R", "tests/README.txt", "tests/check_source.R", "tests/run_tests.do",
             "tests/prepare_reference.R", "tests/compare_R.mata", "tests/compare_R.do",
             "tests/summarize_validation.R")
  if (file.exists("tests/SOURCE_CHECK.txt")) files <- c(files, "tests/SOURCE_CHECK.txt")
  if (file.exists("tests/VALIDATION.txt")) files <- c(files, "tests/VALIDATION.txt")
  stopifnot(all(file.exists(files)))
  dir.create("release", showWarnings = FALSE)
  archive <- file.path("release", "iRBCrd_Stata_2.1.zip")
  if (file.exists(archive)) unlink(archive)
  utils::zip(archive, files = files, flags = "-9q")
  stopifnot(file.exists(archive))
  members <- utils::unzip(archive, list = TRUE)$Name
  stopifnot(setequal(members, files))
  cat("Created local archive:", normalizePath(archive), "\n")
}
main()
